#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Sauvegarde des fichiers modifies"
mkdir -p archive/before_fix
for f in grader reasoner critic aggregator graph; do
  [ -f "agents/$f.py" ] && cp "agents/$f.py" "archive/before_fix/$f.py"
done
echo "  copies dans archive/before_fix/"

echo "==> Installation du controle de couverture"
cp "$P/coverage.py" agents/coverage.py

echo "==> Application des correctifs"
python3 "$P/apply_fix.py"

echo "==> Verification des imports"
python -c "from agents.graph import evaluate_answer; print('  imports OK')"

echo ""
echo "============================================================"
echo " Correctifs appliques. Relancez l'API."
echo " Test :  python scripts/test_scoring.py"
echo "============================================================"
