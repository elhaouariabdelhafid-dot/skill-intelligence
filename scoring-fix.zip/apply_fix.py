"""Applique trois correctifs a la chaine d'evaluation.

1. ECHECS VISIBLES — les agents ne renvoient plus un score de repli de 2.0
   quand le LLM echoue. Ils levent une erreur, la reponse reste "non evaluee"
   et peut etre relancee. Mieux vaut une absence de note qu'une note fausse.

2. NON-REPONSES — detectees avant tout appel LLM, score 0 deterministe.

3. PONDERATIONS DYNAMIQUES — l'agregation lit les poids depuis la base
   (modifiables par l'administrateur) au lieu de constantes en dur, et le
   terme du Critic ne peut plus ajouter de points a une reponse nulle.
"""
from pathlib import Path
import re
import sys

ROOT = Path.cwd()
if not (ROOT / "agents").exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

# ─────────── 1. Supprimer les replis silencieux ───────────
FALLBACK = re.compile(
    r"    except RuntimeError:\n"
    r"(?:\s*#[^\n]*\n)*"
    r"\s*return \{\"(\w+)\": AgentResult\(score=2\.0,\n"
    r"[^\n]*justification=\"[^\"]*\",\n"
    r"[^\n]*citations=\[\]\)\}",
    re.M)

for name in ("grader", "reasoner", "critic"):
    p = ROOT / "agents" / f"{name}.py"
    if not p.exists():
        print(f"  {name}.py absent, ignore"); continue
    s = p.read_text(encoding="utf-8")
    if "EvaluationFailed" in s:
        print(f"  {name}.py deja corrige"); continue

    new_except = (
        "    except RuntimeError as exc:\n"
        "        # Un echec LLM ne doit pas devenir une note moyenne : on le\n"
        "        # signale pour que la reponse reste non evaluee et relancable.\n"
        "        raise EvaluationFailed(\n"
        f"            f\"Agent {name} indisponible : {{exc}}\") from exc")

    s2, n = FALLBACK.subn(new_except, s)
    if n == 0:
        # Repli generique si la mise en forme differe
        s2, n = re.subn(r"    except RuntimeError:", new_except.split("\n")[0], s)
        if n:
            print(f"  {name}.py : bloc except adapte (verifiez le fichier)")
    if n:
        # Importer l'exception
        s2 = s2.replace(
            "from agents.state import AgentResult, EvaluationState",
            "from agents.state import AgentResult, EvaluationState\n"
            "from agents.failures import EvaluationFailed")
        p.write_text(s2, encoding="utf-8")
        print(f"  {name}.py : repli a 2.0 supprime")
    else:
        print(f"  {name}.py : motif non trouve, a verifier manuellement")

# ─────────── 2. Module d'exception ───────────
fail = ROOT / "agents" / "failures.py"
if not fail.exists():
    fail.write_text(
        '"""Exception levee quand un agent ne peut pas evaluer.\n\n'
        'Permet de distinguer une note basse (jugement) d\'une absence de note\n'
        '(panne). La reponse concernee reste marquee non evaluee.\n"""\n\n\n'
        'class EvaluationFailed(RuntimeError):\n'
        '    """Un agent n\'a pas pu produire de jugement."""\n',
        encoding="utf-8")
    print("  agents/failures.py cree")

# ─────────── 3. Agregation : poids dynamiques + plancher ───────────
agg = ROOT / "agents" / "aggregator.py"
s = agg.read_text(encoding="utf-8")
if "get_float" not in s:
    s = s.replace(
        "W_GRADER = 0.45\nW_REASONER = 0.45\nW_CRITIC = 0.10\nVETO_CAP = 1.5",
        "# Valeurs de repli ; les valeurs effectives viennent de la base et sont\n"
        "# modifiables par l'administrateur sans redemarrage.\n"
        "W_GRADER = 0.45\nW_REASONER = 0.45\nW_CRITIC = 0.10\nVETO_CAP = 1.5\n\n\n"
        "def _weights() -> tuple[float, float, float, float]:\n"
        "    try:\n"
        "        from api.settings_models import get_float\n"
        "        return (get_float(\"weight_grader\"), get_float(\"weight_reasoner\"),\n"
        "                get_float(\"weight_critic\"), get_float(\"veto_cap\"))\n"
        "    except Exception:\n"
        "        return W_GRADER, W_REASONER, W_CRITIC, VETO_CAP")

    s = s.replace(
        "    # Critic : score = sévérité des problèmes (0 bon, 4 mauvais) -> on inverse\n"
        "    critic_positive = 4.0 - critic[\"score\"]\n\n"
        "    base = (W_GRADER * grader[\"score\"]\n"
        "            + W_REASONER * reasoner[\"score\"]\n"
        "            + W_CRITIC * critic_positive)",
        "    w_g, w_r, w_c, veto_cap = _weights()\n\n"
        "    # Le Critic ne peut que penaliser : une reponse sans erreur ne gagne\n"
        "    # pas de points parce qu'elle est vide. On part du score de contenu\n"
        "    # et on retranche la severite constatee.\n"
        "    content = w_g * grader[\"score\"] + w_r * reasoner[\"score\"]\n"
        "    penalty = w_c * critic[\"score\"]\n"
        "    base = content - penalty\n\n"
        "    # Plancher : sans exactitude ni raisonnement, le score est nul.\n"
        "    if grader[\"score\"] <= 0 and reasoner[\"score\"] <= 0:\n"
        "        base = 0.0")

    s = s.replace(
        "    final = min(base, VETO_CAP) if veto else base",
        "    final = min(base, veto_cap) if veto else base")
    agg.write_text(s, encoding="utf-8")
    print("  aggregator.py : ponderations dynamiques + plancher")
else:
    print("  aggregator.py deja corrige")

# ─────────── 4. Court-circuit dans le graphe ───────────
graph = ROOT / "agents" / "graph.py"
s = graph.read_text(encoding="utf-8")
if "is_non_answer" not in s:
    s = s.replace(
        'def evaluate_answer(question: str, expected_answer: str, key_points: list[str],',
        'def evaluate_answer(question: str, expected_answer: str, key_points: list[str],')
    # Inserer le controle en tete de fonction
    m = re.search(r'(def evaluate_answer\([^)]*\) -> dict:\n    """[^"]*"""\n)', s, re.S)
    if m:
        s = s[:m.end()] + (
            "    # Controle de couverture : une non-reponse est traitee sans appel LLM,\n"
            "    # ce qui garantit un score stable et evite un jugement arbitraire.\n"
            "    from agents.coverage import is_non_answer, zero_result\n"
            "    empty, reason = is_non_answer(candidate_answer)\n"
            "    if empty:\n"
            "        return zero_result(reason)\n\n"
        ) + s[m.end():]
        graph.write_text(s, encoding="utf-8")
        print("  graph.py : controle de couverture ajoute")
    else:
        print("  graph.py : point d'insertion non trouve")
else:
    print("  graph.py deja corrige")

print("\nCorrectifs appliques.")
