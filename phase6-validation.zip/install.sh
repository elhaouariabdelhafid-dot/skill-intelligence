#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(dirname "${BASH_SOURCE[0]}")"

echo "==> Dépendances"
pip install -q scipy numpy

echo "==> Copie des outils de validation"
cp "$P/human_rating.py"      evaluation/human_rating.py
cp "$P/human_correlation.py" evaluation/human_correlation.py

echo "==> Vérification"
python -c "import ast; [ast.parse(open(f'evaluation/{f}').read()) for f in ['human_rating.py','human_correlation.py']]; print('  OK')"

echo ""
echo "============================================================"
echo " Validation humain/IA installée."
echo ""
echo " ÉTAPE 1 — Noter les réponses à la main (sans voir le score IA) :"
echo "   python evaluation/human_rating.py"
echo ""
echo " ÉTAPE 2 — Calculer la corrélation :"
echo "   python evaluation/human_correlation.py"
echo "============================================================"
