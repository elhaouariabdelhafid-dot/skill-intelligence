#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(dirname "${BASH_SOURCE[0]}")"

echo "==> Dépendance Neo4j"
pip install -q neo4j

echo "==> Copie du module ontologie"
cp "$P/ontology.py" skills/ontology.py

echo "==> Vérification config Neo4j"
python -c "from config import settings; print('  URI:', settings.neo4j_uri)" || {
  echo "  ATTENTION : config Neo4j manquante dans config.py/.env"; }

echo "==> Test connexion Neo4j"
python -c "from skills.ontology import get_driver; d=get_driver(); d.verify_connectivity(); d.close(); print('  Neo4j OK')" || \
  echo "  ATTENTION : Neo4j inaccessible. Lance : docker start ski-neo4j"

echo ""
echo "============================================================"
echo " Ontologie installée. Utilisation :"
echo "   # 1. Construire le graphe de compétences AWS"
echo "   python skills/ontology.py --build"
echo "   # 2. Projeter un collaborateur et voir ses prérequis faibles"
echo "   python skills/ontology.py --project 4"
echo ""
echo " Visualiser dans le navigateur :"
echo "   http://localhost:7474  (user: neo4j, pass: password123)"
echo "   Requête : MATCH (n) RETURN n"
echo "============================================================"
