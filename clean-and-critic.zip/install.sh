#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Sauvegarde"
cp agents/critic.py archive/before_fix/critic_before_prompt.py 2>/dev/null || \
  { mkdir -p archive/before_fix; cp agents/critic.py archive/before_fix/critic_before_prompt.py; }

echo "==> Correctif du Critic"
python3 "$P/fix_critic.py"

echo "==> Scripts de nettoyage"
cp "$P/inspect_evals.py" scripts/inspect_evals.py
cp "$P/clean_evals.py"   scripts/clean_evals.py
cp "$P/test_critic.py"   scripts/test_critic.py

echo ""
echo "============================================================"
echo " 1. Voir les evaluations   :  python scripts/inspect_evals.py"
echo " 2. Simuler le nettoyage   :  python scripts/clean_evals.py --auto"
echo " 3. Appliquer              :  python scripts/clean_evals.py --auto --apply"
echo " 4. Tester le Critic       :  python scripts/test_critic.py"
echo ""
echo " Relancez l'API apres le correctif du Critic."
echo "============================================================"
