"""Renforce l'agent Critic pour detecter les entites absentes du corpus.

LE CONSTAT : une reponse citant un service inexistant ("AWS S3 IPGuard") a
recu un Critic a 0.0 — aucune anomalie signalee. Le prompt cherchait des
contradictions internes, or une invention est coherente avec elle-meme.

LA CORRECTION : demander explicitement de verifier que chaque service,
fonctionnalite ou parametre cite APPARAIT dans le contexte documentaire.
Une entite absente du contexte est une hallucination, meme si elle sonne juste.
"""
from pathlib import Path
import re
import sys

p = Path("agents/critic.py")
if not p.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

s = p.read_text(encoding="utf-8")
if "INVENTED ENTITIES" in s:
    print("Deja corrige."); sys.exit(0)

# ── 1. Systeme : role elargi ──
old_sys = re.search(r'CRITIC_SYSTEM = """(.*?)"""', s, re.S)
if old_sys:
    new_sys = '''CRITIC_SYSTEM = """You are a rigorous verifier of AWS technical answers. Your
single most important job is to detect INVENTED ENTITIES: any AWS service,
feature, API operation, parameter or limit that the candidate names but that
does NOT appear in the documentation context you are given.

An invented entity is a hallucination even when the name sounds plausible and
the sentence around it is internally coherent. Plausibility is not evidence.
If the context does not mention it, treat it as unverified and report it.

You also report factual contradictions, unsupported claims and dangerous advice.
You do not judge writing quality or completeness — other agents handle that."""'''
    s = s[:old_sys.start()] + new_sys + s[old_sys.end():]
    print("1. instruction systeme renforcee")

# ── 2. Prompt : demarche explicite ──
m = re.search(r'(    prompt = f""")(.*?)("""\n)', s, re.S)
if m:
    new_prompt = '''    prompt = f"""Verify the candidate's answer against the AWS documentation context.

QUESTION: {state['question']}

DOCUMENTATION CONTEXT (the only source of truth):
{state['context']}

CANDIDATE'S ANSWER:
{state['candidate_answer']}

STEP 1 — INVENTED ENTITIES (most important)
List every AWS service, feature, API call, parameter or numeric limit named in
the answer. For each one, check whether it appears in the documentation context
above. Any name that does NOT appear there is an invented entity.
Do not excuse a name because it sounds like a real AWS product.

STEP 2 — CONTRADICTIONS
Claims that contradict the documentation context.

STEP 3 — UNSUPPORTED CLAIMS
Assertions the context neither confirms nor denies.

SEVERITY 0-4 (0 = no problem at all, 4 = severe):
- 4: an invented service or feature is presented as real, or advice that would
     break security
- 3: an invented API operation, parameter or limit
- 2: a claim that contradicts the documentation
- 1: minor unsupported statements
- 0: everything named is present in the context and consistent with it

Set has_major_hallucination to true whenever you found at least one invented
entity, whatever the rest of the answer is worth."""
'''
    s = s[:m.start()] + new_prompt + s[m.end():]
    print("2. demarche de verification explicitee")

# ── 3. Champ dedie dans la sortie structuree ──
if "invented_entities" not in s:
    s = re.sub(
        r'(class CriticOutput\(BaseModel\):\n)',
        r'\1    invented_entities: list[str] = Field(default_factory=list,\n'
        r'        description="Services, features or parameters named but absent from the context")\n',
        s)
    print("3. champ invented_entities ajoute")

# ── 4. Le veto se declenche aussi sur une entite inventee ──
s = s.replace(
    'if out.has_major_hallucination:',
    'if out.has_major_hallucination or getattr(out, "invented_entities", []):')
if "invented_entities" in s:
    # Reporter les entites dans la justification
    s = s.replace(
        'justification = out.justification',
        'justification = out.justification\n'
        '    if getattr(out, "invented_entities", []):\n'
        '        justification += (" | Entites absentes du corpus : "\n'
        '                          + ", ".join(out.invented_entities))')
    print("4. veto declenche par une entite inventee")

p.write_text(s, encoding="utf-8")

import ast
ast.parse(s)
print("\nagents/critic.py corrige et valide.")
