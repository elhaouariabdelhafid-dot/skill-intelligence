"""Raccourcit le prompt du Critic pour qu'il cesse de recopier la consigne.

LE SYMPTOME : sur 17 des 19 reponses evaluees, le Critic a renvoye severite 2
avec, dans le champ "hallucinations", le texte meme de la consigne :
"AWS services, features, API operations or limits that DO NOT EXIST..."
Il ne jugeait pas, il recopiait la definition du champ. Meme mode d'echec que
le schema JSON recopie au lieu d'etre rempli.

LA CAUSE : un modele de 8 milliards de parametres decroche quand la consigne
d'un champ est longue et descriptive. Les trois tentatives precedentes ont
enrichi le prompt ; celle-ci fait l'inverse.

LE PRINCIPE : une question courte par champ, un exemple de sortie, et
l'instruction explicite de laisser les listes vides plutot que de les remplir
avec la consigne.
"""
from pathlib import Path
import re
import sys

p = Path("agents/critic.py")
if not p.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

s = p.read_text(encoding="utf-8")

# ── Systeme : court et directif ──
m_sys = re.search(r'CRITIC_SYSTEM = """(.*?)"""', s, re.S)
if m_sys:
    new_sys = ('CRITIC_SYSTEM = """You check AWS answers for invented facts.\n'
               'You report only what you actually find. When you find nothing, '
               'you return empty lists and severity 0.\n'
               'You never repeat the instructions back — you write findings, '
               'or nothing."""')
    s = s[:m_sys.start()] + new_sys + s[m_sys.end():]
    print("1. instruction systeme raccourcie")

# ── Prompt : questions courtes, exemple de sortie ──
m_prompt = re.search(r'(    prompt = f""")(.*?)(""")', s, re.S)
if m_prompt:
    new_prompt = '''    prompt = f"""QUESTION: {state['question']}

REFERENCE ANSWER: {state['expected_answer']}

KEY POINTS: {state['key_points']}

DOCUMENTATION EXCERPT: {state['context']}

CANDIDATE'S ANSWER: {state['candidate_answer']}

Answer three questions about the candidate's answer.

1. Does it name any AWS service, feature or API that does not exist?
   List those names in `hallucinations`. Nothing invented -> empty list.
   Anything appearing in the reference answer or the key points is real:
   never list it.

2. Does it contradict itself, or contradict the excerpt?
   List those statements in `contradictions`. None -> empty list.

3. How serious is what you found?
   0 = nothing invented, nothing contradicted (usual case)
   1 = minor claims beyond the excerpt
   2 = contradicts the excerpt
   3 = invented API operation or parameter
   4 = invented service, or dangerous advice

Being absent from the excerpt is not a problem: the excerpt is partial.
A correct answer normally scores 0.

Example when nothing is wrong:
{{"problem_severity": 0, "hallucinations": [], "contradictions": [], "has_major_hallucination": false}}

Write findings only. Never copy this instruction text into the lists."""'''
    s = s[:m_prompt.start()] + new_prompt + s[m_prompt.end():]
    print("2. prompt raccourci, exemple de sortie ajoute")

# ── Garde-fou : rejeter une sortie qui recopie la consigne ──
if "_is_echo" not in s:
    guard = '''

def _is_echo(item: str) -> bool:
    """Detecte un element de liste qui reprend la consigne au lieu d'un constat."""
    low = (item or "").lower()
    markers = ("do not exist", "does not exist", "contradict the context",
               "list those", "empty list", "api operations or limits",
               "aws services, features")
    return any(m in low for m in markers)
'''
    anchor = "\ndef criticize("
    s = s.replace(anchor, guard + anchor, 1)

    # Filtrer les elements recopies avant de construire la justification
    s = s.replace(
        "    problems = []",
        "    # Un modele de petite taille recopie parfois la consigne dans les\n"
        "    # listes. Ces elements ne sont pas des constats : on les ecarte.\n"
        "    out.hallucinations = [h for h in (out.hallucinations or [])\n"
        "                          if h and not _is_echo(h)]\n"
        "    out.contradictions = [c for c in (out.contradictions or [])\n"
        "                          if c and not _is_echo(c)]\n\n"
        "    problems = []", 1)
    print("3. garde-fou contre la recopie de consigne")

p.write_text(s, encoding="utf-8")
import ast; ast.parse(s)
print("\nagents/critic.py corrige et valide.")
