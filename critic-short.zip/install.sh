#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p archive/before_fix
cp agents/critic.py archive/before_fix/critic_before_short.py
echo "Sauvegarde : archive/before_fix/critic_before_short.py"
python3 "$P/fix_critic_short.py"
cp "$P/test_critic_batch.py" scripts/test_critic_batch.py
echo ""
echo "Test :  python scripts/test_critic_batch.py"
