import { useState, useEffect, useRef, useCallback, useMemo, createContext, useContext } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Cell,
} from "recharts";
import {
  Mail, Lock, Eye, EyeOff, ArrowRight, Loader2, Check, Moon, Sun, Sparkles,
  Brain, GraduationCap, BookOpen, Bot, ShieldCheck, Users, Presentation, User,
  LogOut, Target, Grid3x3, UserCircle, AlertTriangle, Share2, Database,
  Gauge as GaugeIcon, FileQuestion, Play, ListChecks, Route, ClipboardList,
  RefreshCw, WifiOff, Settings,
} from "lucide-react";

/* ══════════════════════════════════════════════════════════
   EvaSmart — frontend connecté à l'API FastAPI
   Toutes les données proviennent de PostgreSQL / Qdrant / Neo4j
   ══════════════════════════════════════════════════════════ */

const DEFAULT_API = import.meta.env.VITE_API_BASE || "http://localhost:8010";

const Ctx = createContext({ dark: false, token: null, api: DEFAULT_API });
const useCtx = () => useContext(Ctx);

const ROLE_META = {
  admin:         { label: "Administration",      icon: ShieldCheck,  tint: "violet" },
  rh:            { label: "Ressources humaines", icon: Users,        tint: "blue" },
  manager:       { label: "Management",          icon: Target,       tint: "teal" },
  formateur:     { label: "Formation",           icon: Presentation, tint: "amber" },
  collaborateur: { label: "Collaborateur",       icon: User,         tint: "indigo" },
};

const DEMO = [
  { email: "admin@cmh.ma", password: "Admin@2026", role: "admin" },
  { email: "rh@cmh.ma", password: "Rh@2026", role: "rh" },
  { email: "manager@cmh.ma", password: "Manager@2026", role: "manager" },
  { email: "formateur@cmh.ma", password: "Formateur@2026", role: "formateur" },
  { email: "hafid@cmh.ma", password: "Hafid@2026", role: "collaborateur" },
];

const THRESHOLD = 60;
const band = (v) => (v >= 75 ? "high" : v >= THRESHOLD ? "mid" : v >= 45 ? "low" : "critical");
const BAND_COLOR = { high: "#0EA47C", mid: "#4F46E5", low: "#E8930C", critical: "#E0455E", none: "#94A3C4" };
const BAND_LABEL = { high: "Maîtrisé", mid: "Acquis", low: "Fragile", critical: "À renforcer" };
const short = (s) => (s === "Well-Architected" ? "Well-Arch." : s === "Security Groups" ? "Sec. Groups" : s);

/* ─────────── accès API ─────────── */
async function apiFetch(api, path, token, options = {}) {
  const res = await fetch(api + path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    let detail = `${res.status}`;
    try { const j = await res.json(); detail = j.detail || detail; } catch { /* ignore */ }
    throw new Error(detail);
  }
  return res.json();
}

function useApi(path, deps = []) {
  const { api, token } = useCtx();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!path) return;
    let alive = true;
    setLoading(true); setError(null);
    apiFetch(api, path, token)
      .then((d) => { if (alive) { setData(d); setLoading(false); } })
      .catch((e) => { if (alive) { setError(e.message); setLoading(false); } });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, api, token, tick, ...deps]);

  return { data, error, loading, reload: () => setTick((t) => t + 1) };
}

/* ─────────── états de chargement ─────────── */
function Loading({ label = "Chargement…" }) {
  return <div className="state"><Loader2 size={17} className="spin" strokeWidth={2.4} />{label}</div>;
}
function ErrorState({ message, onRetry }) {
  return (
    <div className="state state-err">
      <WifiOff size={17} strokeWidth={2.2} />
      <div><strong>Impossible de charger ces données</strong><span>{message}</span></div>
      {onRetry && <button className="btn-mini" onClick={onRetry}><RefreshCw size={13} strokeWidth={2.4} />Réessayer</button>}
    </div>
  );
}
function Empty({ children }) {
  return <div className="state"><Check size={17} strokeWidth={2.4} />{children}</div>;
}

/* ─────────── effets visuels ─────────── */
function useTyping(text, speed = 62, startDelay = 380) {
  const [out, setOut] = useState(""); const [done, setDone] = useState(false);
  useEffect(() => {
    let i = 0, tick;
    const s = setTimeout(() => {
      tick = setInterval(() => {
        i += 1; setOut(text.slice(0, i));
        if (i >= text.length) { clearInterval(tick); setDone(true); }
      }, speed);
    }, startDelay);
    return () => { clearTimeout(s); clearInterval(tick); };
  }, [text, speed, startDelay]);
  return { out, done };
}

function Particles({ count = 24 }) {
  const dots = useRef(Array.from({ length: count }, (_, i) => ({
    id: i, left: Math.random() * 100, top: Math.random() * 100, size: 2 + Math.random() * 4,
    dur: 12 + Math.random() * 16, delay: Math.random() * 10, op: 0.15 + Math.random() * 0.4,
  }))).current;
  return (
    <div className="particles" aria-hidden="true">
      {dots.map((d) => (
        <span key={d.id} style={{ left: `${d.left}%`, top: `${d.top}%`, width: d.size, height: d.size,
          animationDuration: `${d.dur}s`, animationDelay: `${d.delay}s`, opacity: d.op }} />
      ))}
    </div>
  );
}

/* ─────────── composants ─────────── */
function Gauge({ value, size = 128 }) {
  const r = size / 2 - 10, c = 2 * Math.PI * r;
  return (
    <div className="gauge" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} className="gauge-bg" />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={BAND_COLOR[band(value)]}
          strokeWidth="9" strokeLinecap="round" strokeDasharray={c}
          strokeDashoffset={c * (1 - value / 100)} className="gauge-fg" />
      </svg>
      <div className="gauge-mid"><span className="gauge-val">{value.toFixed(1)}</span><span className="gauge-unit">%</span></div>
    </div>
  );
}

function Meter({ label, value, delay = 0 }) {
  return (
    <div className="meter">
      <div className="meter-head"><span>{label}</span><span className="mono">{value.toFixed(0)}%</span></div>
      <div className="meter-rail">
        <div className="meter-fill" style={{ width: `${value}%`, background: BAND_COLOR[band(value)], animationDelay: `${delay}s` }} />
      </div>
    </div>
  );
}

function Stat({ label, value, sub, tone, delay = 0 }) {
  return (
    <div className="stat rise" style={{ animationDelay: `${delay}s` }}>
      <span className="stat-label">{label}</span>
      <span className="stat-value" style={tone ? { color: tone } : undefined}>{value}</span>
      {sub && <span className="stat-sub">{sub}</span>}
    </div>
  );
}

function Panel({ title, note, children, delay = 0, action }) {
  return (
    <section className="panel rise" style={{ animationDelay: `${delay}s` }}>
      <header className="panel-head">
        <h2>{title}</h2>
        <div className="panel-right">{note && <span className="panel-note">{note}</span>}{action}</div>
      </header>
      {children}
    </section>
  );
}

/* Graphe de compétences construit depuis /api/ontology/graph */
function SkillTopology({ graph, scores, compact = false }) {
  const layout = useMemo(() => {
    if (!graph?.skills) return null;
    const byName = Object.fromEntries(graph.skills.map((s) => [s.name, s]));
    const depthOf = (name, seen = new Set()) => {
      if (seen.has(name)) return 0;
      seen.add(name);
      const req = byName[name]?.requires || [];
      return req.length === 0 ? 0 : 1 + Math.max(...req.map((r) => depthOf(r, seen)));
    };
    const layers = {};
    graph.skills.forEach((s) => {
      const d = depthOf(s.name);
      (layers[d] = layers[d] || []).push(s.name);
    });
    const keys = Object.keys(layers).map(Number).sort((a, b) => a - b);
    const W = 660, H = compact ? 220 : 300, pos = {};
    keys.forEach((d, li) => {
      const y = 46 + (keys.length === 1 ? 0 : li * ((H - 96) / (keys.length - 1)));
      layers[d].forEach((n, i) => { pos[n] = { x: (W / (layers[d].length + 1)) * (i + 1), y }; });
    });
    return { pos, W, H, byName };
  }, [graph, compact]);

  if (!layout) return null;
  const { pos, W, H, byName } = layout;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="topology" role="img" aria-label="Graphe des dépendances">
      {Object.values(byName).flatMap((s) => (s.requires || []).map((d) => {
        const a = pos[s.name], b = pos[d];
        if (!a || !b) return null;
        const sa = scores?.[s.name], sb = scores?.[d];
        const blocked = sa != null && sb != null && sa < THRESHOLD && sb < THRESHOLD;
        return <line key={`${s.name}-${d}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y}
          className={blocked ? "topo-link blocked" : "topo-link"} />;
      }))}
      {Object.entries(pos).map(([name, p]) => {
        const v = scores?.[name];
        const col = v == null ? BAND_COLOR.none : BAND_COLOR[band(v)];
        return (
          <g key={name}>
            <circle cx={p.x} cy={p.y} r={compact ? 17 : 21} className="topo-node" stroke={col} strokeWidth="2.5" />
            {v != null && <text x={p.x} y={p.y + 4} textAnchor="middle" className="topo-score" fill={col}>{Math.round(v)}</text>}
            <text x={p.x} y={p.y + (compact ? 33 : 39)} textAnchor="middle" className="topo-label">{short(name)}</text>
          </g>
        );
      })}
    </svg>
  );
}

const chartTheme = (dark) => ({
  grid: dark ? "#1E2739" : "#E6EAF2", tick: dark ? "#77839B" : "#8892A6",
  tip: { borderRadius: 12, border: `1px solid ${dark ? "#2A354B" : "#E6EAF2"}`,
    background: dark ? "#0F1522" : "#fff", color: dark ? "#EEF2FA" : "#0F1729", fontSize: 12 },
});

/* ═══════════════ CONNEXION ═══════════════ */
function Login({ onSuccess, dark, toggleDark, api, setApi }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [status, setStatus] = useState("idle");
  const [msg, setMsg] = useState("");
  const [ripples, setRipples] = useState([]);
  const [cfg, setCfg] = useState(false);
  const { out: typed, done } = useTyping("Bienvenue sur EvaSmart");

  const submit = useCallback(async (e) => {
    if (e?.clientX && e.currentTarget) {
      const r = e.currentTarget.getBoundingClientRect(), id = Date.now();
      setRipples((p) => [...p, { id, x: e.clientX - r.left, y: e.clientY - r.top }]);
      setTimeout(() => setRipples((p) => p.filter((x) => x.id !== id)), 650);
    }
    if (status === "loading") return;
    if (!email || !password) { setMsg("Saisissez votre email et votre mot de passe."); setStatus("error"); setTimeout(() => setStatus("idle"), 2400); return; }
    setStatus("loading");
    try {
      const data = await apiFetch(api, "/auth/login", null, {
        method: "POST", body: JSON.stringify({ email: email.trim().toLowerCase(), password }),
      });
      setStatus("success");
      setTimeout(() => onSuccess({ token: data.access_token, role: data.role, name: data.full_name, email: email.trim().toLowerCase() }), 850);
    } catch (err) {
      const network = err.message === "Failed to fetch" || err.message.includes("NetworkError");
      setMsg(network ? "API injoignable. Vérifiez qu'uvicorn tourne et l'adresse configurée." : "Email ou mot de passe incorrect");
      setStatus("error");
      setTimeout(() => setStatus("idle"), 3200);
    }
  }, [email, password, status, api, onSuccess]);

  return (
    <div className="login">
      <aside className="hero">
        <div className="orb orb-1" /><div className="orb orb-2" /><div className="orb orb-3" />
        <Particles />
        {[["📚","12%","8%","0s","7s"],["🤖","22%","72%","1.1s","8.5s"],["🧠","58%","12%","2.3s","9s"],
          ["🎓","70%","66%",".6s","7.8s"],["✨","40%","84%","1.8s","6.5s"]].map(([e,t,l,d,u],i)=>(
          <span key={i} className="float-icon" aria-hidden="true"
            style={{ top: t, left: l, animationDelay: d, animationDuration: u }}>{e}</span>
        ))}
        <div className="hero-inner">
          <div className="hero-badge"><Sparkles size={13} strokeWidth={2.4} /><span>Évaluation assistée par IA</span></div>
          <p className="hero-greet"><span className="wave" role="img" aria-label="salut">👋</span> Bonjour !</p>
          <h1 className="hero-title">{typed}<span className={`caret${done ? " caret-done" : ""}`} aria-hidden="true" /></h1>
          <p className="hero-sub">
            Plateforme d'évaluation des compétences Cloud. Chaque réponse est notée par
            trois agents spécialisés, rapportée à la documentation AWS, puis replacée dans
            le graphe des prérequis pour bâtir un parcours qui suit un ordre logique.
          </p>
          <ul className="hero-points">
            <li><span className="hp-ico"><Brain size={15} strokeWidth={2.2} /></span>Trois agents évaluateurs avec veto anti-hallucination</li>
            <li><span className="hp-ico"><BookOpen size={15} strokeWidth={2.2} /></span>Réponses ancrées dans la documentation indexée</li>
            <li><span className="hp-ico"><GraduationCap size={15} strokeWidth={2.2} /></span>Parcours ordonnés par dépendances entre compétences</li>
          </ul>
        </div>
      </aside>

      <main className="pane">
        <button className="theme-toggle" onClick={toggleDark} aria-label={dark ? "Mode clair" : "Mode sombre"}>
          <span className="tt-track"><span className={`tt-thumb${dark ? " tt-on" : ""}`}>
            {dark ? <Moon size={12} strokeWidth={2.4} /> : <Sun size={12} strokeWidth={2.4} />}</span></span>
        </button>

        <div className="card rise">
          <header className="card-head">
            <div className="logo"><span className="logo-mark"><Bot size={19} strokeWidth={2.2} /></span>
              <span className="logo-word">EvaSmart</span></div>
            <h2>Content de vous revoir.</h2>
            <p>Connectez-vous pour continuer.</p>
          </header>

          <div className="fields">
            <label className="field">
              <span className="field-label">Email</span>
              <span className="input-wrap">
                <Mail className="input-ico" size={16} strokeWidth={2} />
                <input type="email" value={email} autoComplete="username" placeholder="prenom@cmh.ma"
                  onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit(e)} />
              </span>
            </label>
            <label className="field">
              <span className="field-label">Mot de passe</span>
              <span className="input-wrap">
                <Lock className="input-ico" size={16} strokeWidth={2} />
                <input type={show ? "text" : "password"} value={password} autoComplete="current-password"
                  placeholder="••••••••••" onChange={(e) => setPassword(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && submit(e)} />
                <button type="button" className="input-btn" onClick={() => setShow(!show)}
                  aria-label={show ? "Masquer" : "Afficher"}>
                  {show ? <EyeOff size={16} strokeWidth={2} /> : <Eye size={16} strokeWidth={2} />}
                </button>
              </span>
            </label>

            <div className="row-between">
              <label className="check">
                <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
                <span className="check-box"><Check size={11} strokeWidth={3.2} /></span>
                <span className="check-text">Se souvenir de moi</span>
              </label>
              <button type="button" className="link" onClick={() => setCfg(!cfg)}>
                <Settings size={12} strokeWidth={2.2} /> API
              </button>
            </div>

            {cfg && (
              <label className="field pop">
                <span className="field-label">Adresse de l'API</span>
                <span className="input-wrap">
                  <input value={api} onChange={(e) => setApi(e.target.value)} placeholder="http://localhost:8010" />
                </span>
              </label>
            )}

            <div aria-live="polite">
              {status === "error" && <div className="alert alert-error shake"><span aria-hidden="true">❌</span> {msg}</div>}
              {status === "success" && <div className="alert alert-success pop"><span aria-hidden="true">✅</span> Connexion réussie !</div>}
            </div>

            <button className="btn-signin" onClick={submit} disabled={status === "loading" || status === "success"}>
              {ripples.map((r) => <span key={r.id} className="ripple" style={{ left: r.x, top: r.y }} />)}
              {status === "loading" ? <><Loader2 className="spin" size={17} strokeWidth={2.4} /> Connexion…</>
                : status === "success" ? <><Check size={17} strokeWidth={2.6} /> Connecté</>
                : <>Se connecter <ArrowRight size={17} strokeWidth={2.4} className="btn-arrow" /></>}
            </button>

            <div className="demo">
              <div className="demo-head"><span>Comptes de démonstration</span><span className="demo-hint">connexion en un clic</span></div>
              <div className="demo-grid">
                {DEMO.map((a, i) => {
                  const meta = ROLE_META[a.role], Ico = meta.icon;
                  return (
                    <div key={a.email} className={`demo-card tint-${meta.tint} rise`} style={{ animationDelay: `${0.16 + i * 0.05}s` }}>
                      <span className="demo-av"><Ico size={15} strokeWidth={2.2} /></span>
                      <div className="demo-meta"><strong>{meta.label}</strong><span>{a.email}</span></div>
                      <button className="demo-go" onClick={() => { setEmail(a.email); setPassword(a.password); setStatus("idle"); }}>
                        Connexion</button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
        <p className="pane-foot">bcrypt + JWT · API : <span className="mono">{api}</span></p>
      </main>
    </div>
  );
}

/* ═══════════════ CHARGEMENT ═══════════════ */
const STEPS = [
  "Préparation de votre espace de travail…",
  "Chargement du profil utilisateur…",
  "Initialisation des services IA…",
  "Connexion à la base de connaissances…",
  "Chargement du tableau de bord…",
];

function Boot({ user, onDone }) {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setPct((p) => (p + 100 / 48 >= 100 ? 100 : p + 100 / 48)), 40);
    return () => clearInterval(t);
  }, []);
  useEffect(() => { if (pct >= 100) { const t = setTimeout(onDone, 520); return () => clearTimeout(t); } }, [pct, onDone]);
  const step = Math.min(STEPS.length - 1, Math.floor((pct / 100) * STEPS.length));
  const R = 52, C = 2 * Math.PI * R;
  return (
    <div className="boot">
      <div className="orb orb-1" /><div className="orb orb-2" /><Particles count={16} />
      <div className="boot-inner">
        <div className="boot-ring">
          <svg width="132" height="132" viewBox="0 0 132 132">
            <circle cx="66" cy="66" r={R} className="ring-bg" />
            <circle cx="66" cy="66" r={R} className="ring-fg" strokeDasharray={C}
              strokeDashoffset={C * (1 - pct / 100)} transform="rotate(-90 66 66)" />
          </svg>
          <span className="boot-logo"><Bot size={34} strokeWidth={1.9} /></span>
        </div>
        <h2 className="boot-word">EvaSmart</h2>
        <div className="boot-steps">
          {STEPS.map((s, i) => (
            <p key={s} className={`boot-step${i === step ? " on" : ""}${i < step ? " done" : ""}`}>
              {i < step ? <Check size={13} strokeWidth={3} />
                : i === step ? <Loader2 size={13} strokeWidth={2.6} className="spin" />
                : <span className="dot-idle" />}{s}
            </p>
          ))}
        </div>
        <div className="boot-bar"><div className="boot-fill" style={{ width: `${pct}%` }} /></div>
        <span className="boot-pct">{Math.round(pct)}%</span>
        <p className="boot-user">Connecté en tant que {user.name} · {ROLE_META[user.role].label}</p>
      </div>
    </div>
  );
}

/* ═══════════════ VUES COLLABORATEUR ═══════════════ */
function MonProfil() {
  const { dark } = useCtx();
  const ct = chartTheme(dark);
  const { data, error, loading, reload } = useApi("/api/me/profile");
  if (loading) return <Loading label="Chargement de votre profil…" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;

  const services = data.services || {};
  const names = Object.keys(services);
  const radar = names.map((s) => ({ skill: short(s), value: services[s] }));
  const best = names.reduce((a, s) => (services[s] > services[a] ? s : a), names[0]);
  const worst = names.reduce((a, s) => (services[s] < services[a] ? s : a), names[0]);

  return (
    <>
      <div className="stat-row">
        <Stat label="Niveau global" value={`${data.overall.toFixed(1)}%`} sub={BAND_LABEL[band(data.overall)]} tone={BAND_COLOR[band(data.overall)]} />
        <Stat label="Réponses évaluées" value={data.n_evaluations} sub="par 3 agents" delay={.06} />
        <Stat label="Point fort" value={short(best)} sub={`${services[best].toFixed(0)}%`} tone={BAND_COLOR.high} delay={.12} />
        <Stat label="À renforcer" value={short(worst)} sub={`${services[worst].toFixed(0)}%`} tone={BAND_COLOR.critical} delay={.18} />
      </div>
      <div className="grid-2">
        <Panel title="Mon niveau" note={`${data.n_evaluations} réponses`} delay={.24}>
          <div className="profile-row">
            <Gauge value={data.overall} />
            <div className="profile-meta">
              <span className={`pill pill-${band(data.overall)}`}>{BAND_LABEL[band(data.overall)]}</span>
              <p>Votre point fort est <strong>{best}</strong>. La compétence à renforcer en priorité
                est <strong>{worst}</strong>.</p>
            </div>
          </div>
        </Panel>
        <Panel title="Répartition par service" delay={.3}>
          <ResponsiveContainer width="100%" height={252}>
            <RadarChart data={radar} outerRadius="72%">
              <PolarGrid stroke={ct.grid} />
              <PolarAngleAxis dataKey="skill" tick={{ fill: ct.tick, fontSize: 11 }} />
              <PolarRadiusAxis domain={[0, 100]} tick={{ fill: ct.tick, fontSize: 9 }} />
              <Radar dataKey="value" stroke="#4F46E5" fill="#4F46E5" fillOpacity={0.24} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </Panel>
      </div>
      <Panel title="Détail par compétence" delay={.36}>
        <div className="meters-2col">
          {names.sort((a, b) => services[b] - services[a]).map((s, i) => (
            <Meter key={s} label={s} value={services[s]} delay={0.4 + i * 0.05} />
          ))}
        </div>
      </Panel>
    </>
  );
}

function MonParcours() {
  const plan = useApi("/api/me/plan");
  const profile = useApi("/api/me/profile");
  const graph = useApi("/api/ontology/graph");

  if (plan.loading || profile.loading) return <Loading label="Construction de votre parcours…" />;
  if (plan.error) return <ErrorState message={plan.error} onRetry={plan.reload} />;

  const gaps = plan.data?.gaps || plan.data?.plan || [];
  const scores = profile.data?.services || {};

  return (
    <>
      <Panel title="Mon parcours de formation" note="lacunes détectées et ressources" delay={0}>
        <p className="panel-lead">
          Chaque lacune est associée aux passages du corpus qui la couvrent, retrouvés
          par recherche documentaire.
        </p>
        {(!Array.isArray(gaps) || gaps.length === 0) ? (
          <Empty>Aucune compétence sous le seuil. Rien à renforcer pour l'instant.</Empty>
        ) : (
          <ol className="path">
            {gaps.map((g, i) => (
              <li key={g.service || i} className="rise" style={{ animationDelay: `${0.08 + i * 0.06}s` }}>
                <span className="path-rank">{i + 1}</span>
                <div className="path-body">
                  <div className="path-head">
                    <strong>{g.service || g.skill}</strong>
                    <span className="mono" style={{ color: BAND_COLOR[band(g.score ?? 0)] }}>
                      {(g.score ?? 0).toFixed(0)}%</span>
                  </div>
                  {g.priority && <p className="path-note">
                    <AlertTriangle size={12} strokeWidth={2.4} />Priorité {g.priority}
                    {g.gap != null && ` · ${g.gap.toFixed(1)} points sous le seuil`}
                  </p>}
                  {Array.isArray(g.resources) && g.resources.length > 0 && (
                    <ul className="res-list">
                      {g.resources.slice(0, 3).map((r, k) => (
                        <li key={k}><BookOpen size={12} strokeWidth={2.2} />
                          <span>{r.source || r.title || r.doc || "Ressource"}</span>
                          {r.page && <span className="mono dim">p. {r.page}</span>}</li>
                      ))}
                    </ul>
                  )}
                </div>
              </li>
            ))}
          </ol>
        )}
      </Panel>
      <Panel title="Mon graphe de compétences" note="les liens rouges signalent un prérequis faible" delay={.2}>
        {graph.loading ? <Loading /> : graph.error ? <ErrorState message={graph.error} onRetry={graph.reload} />
          : <SkillTopology graph={graph.data} scores={scores} />}
      </Panel>
    </>
  );
}

function MesEvaluations() {
  const { data, error, loading, reload } = useApi("/api/me/evaluations");
  if (loading) return <Loading label="Chargement de vos évaluations…" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  return (
    <Panel title="Mes évaluations" note={`${data.length} enregistrées`} delay={0}>
      <p className="panel-lead">
        Chaque réponse est jugée sous trois angles puis agrégée. Un veto s'applique
        si une hallucination majeure est détectée.
      </p>
      {data.length === 0 ? <Empty>Aucune évaluation enregistrée.</Empty> : (
        <table className="table">
          <thead><tr><th>Date</th><th>Service</th><th>Exactitude</th><th>Raisonnement</th><th>Vérification</th><th>Score</th></tr></thead>
          <tbody>
            {data.map((e) => (
              <tr key={e.id} className={e.veto ? "row-veto" : ""}>
                <td className="mono dim">{e.date}</td><td><strong>{short(e.service)}</strong></td>
                <td className="mono">{e.grader?.toFixed(1)}/4</td><td className="mono">{e.reasoner?.toFixed(1)}/4</td>
                <td className="mono">{e.critic?.toFixed(1)}/4</td>
                <td className="mono strong" style={{ color: e.final >= 3 ? BAND_COLOR.high : e.final >= 2 ? BAND_COLOR.mid : BAND_COLOR.critical }}>
                  {e.final?.toFixed(2)}/4{e.veto && <span className="tag tag-danger">veto</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Panel>
  );
}

/* ═══════════════ VUES ÉQUIPE ═══════════════ */
function EquipeVue() {
  const { dark } = useCtx();
  const ct = chartTheme(dark);
  const { data, error, loading, reload } = useApi("/api/people");
  if (loading) return <Loading label="Chargement de l'équipe…" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!data.length) return <Empty>Aucun collaborateur évalué pour l'instant.</Empty>;

  const chart = data.map((p) => ({ name: p.name, niveau: p.overall }));
  const allServices = [...new Set(data.flatMap((p) => Object.keys(p.services || {})))];
  const avgByService = allServices.map((s) => {
    const vals = data.map((p) => p.services?.[s]).filter((v) => v != null);
    return { service: short(s), moyenne: +(vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) };
  }).sort((a, b) => a.moyenne - b.moyenne);
  const worst = avgByService[0];
  const avg = data.reduce((a, p) => a + p.overall, 0) / data.length;

  return (
    <>
      <div className="stat-row">
        <Stat label="Collaborateurs suivis" value={data.length} />
        <Stat label="Niveau moyen" value={`${avg.toFixed(1)}%`} delay={.06} />
        <Stat label="Compétence la plus faible" value={worst.service} sub={`${worst.moyenne}% en moyenne`} tone={BAND_COLOR.critical} delay={.12} />
        <Stat label="Évaluations" value={data.reduce((a, p) => a + (p.n_evaluations || 0), 0)} delay={.18} />
      </div>
      <div className="grid-2">
        <Panel title="Niveau par collaborateur" delay={.24}>
          <ResponsiveContainer width="100%" height={228}>
            <BarChart data={chart} margin={{ top: 8, right: 8, left: -18, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={ct.grid} vertical={false} />
              <XAxis dataKey="name" tick={{ fill: ct.tick, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fill: ct.tick, fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: "rgba(79,70,229,.07)" }} contentStyle={ct.tip} />
              <Bar dataKey="niveau" radius={[7, 7, 0, 0]}>
                {chart.map((d, i) => <Cell key={i} fill={BAND_COLOR[band(d.niveau)]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Moyenne par service" delay={.3}>
          <ResponsiveContainer width="100%" height={228}>
            <BarChart data={avgByService} layout="vertical" margin={{ top: 4, right: 16, left: 4, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={ct.grid} horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={{ fill: ct.tick, fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="service" width={88} tick={{ fill: ct.tick, fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: "rgba(79,70,229,.07)" }} contentStyle={ct.tip} />
              <Bar dataKey="moyenne" radius={[0, 7, 7, 0]}>
                {avgByService.map((d, i) => <Cell key={i} fill={BAND_COLOR[band(d.moyenne)]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>
    </>
  );
}

function DetailCollaborateur() {
  const people = useApi("/api/people");
  const graph = useApi("/api/ontology/graph");
  const [sel, setSel] = useState(null);
  const person = people.data?.find((p) => p.user_id === sel) || people.data?.[0];
  const prereq = useApi(person ? `/api/people/${person.user_id}/prerequisites` : null, [person?.user_id]);

  if (people.loading) return <Loading label="Chargement des collaborateurs…" />;
  if (people.error) return <ErrorState message={people.error} onRetry={people.reload} />;
  if (!person) return <Empty>Aucun collaborateur évalué.</Empty>;

  const services = person.services || {};
  return (
    <>
      <Panel title="Choisir un collaborateur" delay={0}>
        <div className="chip-row">
          {people.data.map((p) => (
            <button key={p.user_id} className={`chip${p.user_id === person.user_id ? " chip-on" : ""}`}
              onClick={() => setSel(p.user_id)}>{p.name} <span className="mono">{p.overall.toFixed(1)}%</span></button>
          ))}
        </div>
        <div className="detail-split">
          <div>{Object.keys(services).sort((a, b) => services[b] - services[a])
            .map((s, i) => <Meter key={s} label={s} value={services[s]} delay={i * 0.05} />)}</div>
          <div className="detail-topo">
            {graph.data && <SkillTopology graph={graph.data} scores={services} />}
            <p className="topo-caption">Les liens rouges pointillés signalent un prérequis lui-même insuffisant.</p>
          </div>
        </div>
      </Panel>
      <Panel title={`Prérequis à traiter pour ${person.name}`} note="calculé par le graphe Neo4j" delay={.15}>
        {prereq.loading ? <Loading /> : prereq.error ? <ErrorState message={prereq.error} onRetry={prereq.reload} />
          : !prereq.data?.length ? <Empty>Aucune compétence sous le seuil.</Empty> : (
          <ol className="path">
            {prereq.data.map((item, i) => (
              <li key={item.skill}><span className="path-rank">{i + 1}</span>
                <div className="path-body">
                  <div className="path-head"><strong>{item.skill}</strong>
                    <span className="mono" style={{ color: BAND_COLOR[band(item.score)] }}>{item.score?.toFixed(0)}%</span></div>
                  {item.weak_prerequisites?.length > 0
                    ? <p className="path-note warn"><AlertTriangle size={12} strokeWidth={2.4} />
                        Prérequis faibles : {item.weak_prerequisites.map((p) => `${p.name} (${p.score?.toFixed(0)}%)`).join(", ")} — à revoir d'abord</p>
                    : <p className="path-note">Compétence de base, aucun prérequis bloquant.</p>}
                </div></li>
            ))}
          </ol>
        )}
      </Panel>
    </>
  );
}

/* ═══════════════ VUES RH ═══════════════ */
function Cartographie() {
  const { data, error, loading, reload } = useApi("/api/people");
  if (loading) return <Loading label="Chargement de la cartographie…" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!data.length) return <Empty>Aucune donnée à cartographier.</Empty>;

  const services = [...new Set(data.flatMap((p) => Object.keys(p.services || {})))];
  const avg = data.reduce((a, p) => a + p.overall, 0) / data.length;

  return (
    <>
      <div className="stat-row">
        <Stat label="Collaborateurs évalués" value={data.length} />
        <Stat label="Niveau moyen" value={`${avg.toFixed(1)}%`} delay={.06} />
        <Stat label="Services couverts" value={services.length} delay={.12} />
        <Stat label="Réponses évaluées" value={data.reduce((a, p) => a + (p.n_evaluations || 0), 0)} delay={.18} />
      </div>
      <Panel title="Cartographie des compétences" note="collaborateurs × services" delay={.24}>
        <div className="hm-scroll">
          <div className="heatmap" style={{ gridTemplateColumns: `132px repeat(${services.length}, minmax(56px,1fr))` }}>
            <div />
            {services.map((s) => <div key={s} className="hm-col">{short(s)}</div>)}
            {data.map((p) => (
              <div key={p.user_id} style={{ display: "contents" }}>
                <div className="hm-row">{p.name}</div>
                {services.map((s) => {
                  const v = p.services?.[s];
                  return v == null
                    ? <div key={s} className="hm-cell hm-na">—</div>
                    : <div key={s} className="hm-cell" title={`${p.name} — ${s} : ${v}%`}
                        style={{ background: BAND_COLOR[band(v)], opacity: 0.2 + (v / 100) * 0.7 }}>{Math.round(v)}</div>;
                })}
              </div>
            ))}
          </div>
        </div>
        <div className="hm-legend">
          {Object.entries(BAND_LABEL).map(([k, v]) => <span key={k}><i style={{ background: BAND_COLOR[k] }} />{v}</span>)}
        </div>
      </Panel>
    </>
  );
}

function Profils() {
  const { data, error, loading, reload } = useApi("/api/people");
  if (loading) return <Loading />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  return (
    <Panel title="Profils individuels" note={`${data.length} collaborateurs`} delay={0}>
      {data.map((p, i) => (
        <div key={p.user_id} className="person-row rise" style={{ animationDelay: `${0.06 * i}s` }}>
          <div className="person-id">
            <span className="avatar">{p.name.charAt(0)}</span>
            <div><strong>{p.name}</strong><span className="dim">{p.n_evaluations} évaluations</span></div>
          </div>
          <div className="person-bar">
            <div className="meter-rail"><div className="meter-fill"
              style={{ width: `${p.overall}%`, background: BAND_COLOR[band(p.overall)], animationDelay: `${0.2 + i * 0.08}s` }} /></div>
          </div>
          <span className={`pill pill-${band(p.overall)}`}>{BAND_LABEL[band(p.overall)]}</span>
          <span className="mono strong">{p.overall.toFixed(1)}%</span>
        </div>
      ))}
    </Panel>
  );
}

function Besoins() {
  const { data, error, loading, reload } = useApi("/api/people");
  if (loading) return <Loading />;
  if (error) return <ErrorState message={error} onRetry={reload} />;

  const services = [...new Set(data.flatMap((p) => Object.keys(p.services || {})))];
  const rows = services.map((s) => {
    const vals = data.map((p) => p.services?.[s]).filter((v) => v != null);
    return { service: s, avg: vals.reduce((a, b) => a + b, 0) / vals.length,
      count: vals.filter((v) => v < THRESHOLD).length, total: vals.length };
  }).sort((a, b) => a.avg - b.avg);

  return (
    <Panel title="Besoins de formation prioritaires" note={`seuil à ${THRESHOLD} %`} delay={0}>
      <table className="table">
        <thead><tr><th>Compétence</th><th>Moyenne équipe</th><th>Collaborateurs concernés</th></tr></thead>
        <tbody>
          {rows.map((g) => (
            <tr key={g.service}>
              <td><strong>{g.service}</strong></td>
              <td className="mono" style={{ color: BAND_COLOR[band(g.avg)] }}>{g.avg.toFixed(1)}%</td>
              <td>{g.count > 0 ? <span className="tag tag-warn">{g.count} / {g.total}</span> : <span className="tag tag-ok">aucun</span>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  );
}

/* ═══════════════ ONTOLOGIE ═══════════════ */
function Ontologie() {
  const graph = useApi("/api/ontology/graph");
  const people = useApi("/api/people");
  const [sel, setSel] = useState(null);
  const person = people.data?.find((p) => p.user_id === sel) || people.data?.[0];

  if (graph.loading) return <Loading label="Chargement du graphe…" />;
  if (graph.error) return <ErrorState message={graph.error} onRetry={graph.reload} />;

  return (
    <>
      <Panel title="Graphe des compétences"
        note={`${graph.data.skills.length} compétences · ${graph.data.skills.reduce((a, s) => a + s.requires.length, 0)} dépendances`} delay={0}>
        {people.data?.length > 0 && (
          <div className="chip-row">
            {people.data.map((p) => (
              <button key={p.user_id} className={`chip${p.user_id === person?.user_id ? " chip-on" : ""}`}
                onClick={() => setSel(p.user_id)}>{p.name}</button>
            ))}
          </div>
        )}
        <SkillTopology graph={graph.data} scores={person?.services} />
        <p className="topo-caption">
          Chaque flèche exprime un prérequis. En rouge pointillé : une dépendance dont
          le prérequis est lui-même sous le seuil. En gris : compétence non encore évaluée.
        </p>
      </Panel>
      <Panel title="Dépendances déclarées" delay={.15}>
        <table className="table">
          <thead><tr><th>Compétence</th><th>Domaine</th><th>Requiert</th>{person && <th>Niveau de {person.name}</th>}</tr></thead>
          <tbody>
            {graph.data.skills.map((s) => {
              const v = person?.services?.[s.name];
              return (
                <tr key={s.name}>
                  <td><strong>{s.name}</strong></td>
                  <td className="dim">{s.domain}</td>
                  <td>{s.requires.length ? s.requires.map((r) => {
                    const rv = person?.services?.[r];
                    return <span key={r} className={`tag ${rv != null && rv < THRESHOLD ? "tag-warn" : "tag-ok"}`}
                      style={{ marginRight: 5 }}>{r}</span>;
                  }) : <span className="dim">compétence de base</span>}</td>
                  {person && <td className="mono" style={{ color: v == null ? BAND_COLOR.none : BAND_COLOR[band(v)] }}>
                    {v == null ? "—" : `${v.toFixed(0)}%`}</td>}
                </tr>
              );
            })}
          </tbody>
        </table>
      </Panel>
    </>
  );
}

/* ═══════════════ VUES FORMATEUR ═══════════════ */
function BanqueQuestions() {
  const [service, setService] = useState("");
  const [level, setLevel] = useState("");
  const qs = new URLSearchParams();
  if (service) qs.set("service", service);
  if (level) qs.set("level", level);
  const path = `/api/questions${qs.toString() ? `?${qs}` : ""}`;
  const { data, error, loading, reload } = useApi(path, [service, level]);
  const all = useApi("/api/questions");

  const services = useMemo(() => [...new Set((all.data || []).map((q) => q.service))].filter(Boolean), [all.data]);
  const levels = useMemo(() => [...new Set((all.data || []).map((q) => q.level))].filter(Boolean), [all.data]);

  return (
    <>
      <div className="stat-row">
        <Stat label="Questions retenues" value={all.data?.length ?? "…"} sub="après filtrage F1–F4" tone={BAND_COLOR.high} />
        <Stat label="Services couverts" value={services.length || "…"} delay={.06} />
        <Stat label="Niveaux de difficulté" value={levels.length || "…"} delay={.12} />
        <Stat label="Affichées" value={data?.length ?? "…"} delay={.18} />
      </div>
      <Panel title="Banque de questions" note="source : questions_accepted.jsonl" delay={.24}>
        <div className="chip-row">
          <button className={`chip${!service ? " chip-on" : ""}`} onClick={() => setService("")}>Tous les services</button>
          {services.map((s) => (
            <button key={s} className={`chip${service === s ? " chip-on" : ""}`} onClick={() => setService(s)}>{short(s)}</button>
          ))}
        </div>
        <div className="chip-row">
          <button className={`chip chip-sm${!level ? " chip-on" : ""}`} onClick={() => setLevel("")}>Toutes difficultés</button>
          {levels.map((l) => (
            <button key={l} className={`chip chip-sm${level === l ? " chip-on" : ""}`} onClick={() => setLevel(l)}>{l}</button>
          ))}
        </div>
        {loading ? <Loading /> : error ? <ErrorState message={error} onRetry={reload} />
          : !data.length ? <Empty>Aucune question ne correspond à ces filtres.</Empty> : (
          <table className="table">
            <thead><tr><th>Question</th><th>Service</th><th>Compétence</th><th>Niveau</th><th>Difficulté</th></tr></thead>
            <tbody>
              {data.map((q) => (
                <tr key={q.id}>
                  <td className="q-text">{q.text}</td>
                  <td><strong>{short(q.service)}</strong></td>
                  <td className="dim">{q.skill}</td>
                  <td><span className="tag">{q.bloom}</span></td>
                  <td><span className={`tag tag-${q.level}`}>{q.level}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Panel>
    </>
  );
}

function LancerEvaluation() {
  const people = useApi("/api/people");
  const questions = useApi("/api/questions");
  const [sel, setSel] = useState(null);
  const [scope, setScope] = useState("lacunes");
  const [state, setState] = useState("idle");
  const [result, setResult] = useState(null);

  const person = people.data?.find((p) => p.user_id === sel) || people.data?.[0];
  const services = person?.services || {};
  const gaps = Object.keys(services).filter((s) => services[s] < THRESHOLD);
  const picked = (questions.data || []).filter((q) => scope === "complet" || gaps.includes(q.service));

  if (people.loading) return <Loading />;
  if (people.error) return <ErrorState message={people.error} onRetry={people.reload} />;
  if (!person) return <Empty>Aucun collaborateur disponible.</Empty>;

  const launch = () => {
    setState("running");
    setTimeout(() => {
      setResult({ who: person.name, count: picked.length, focus: scope === "lacunes" ? gaps : ["tous les services"] });
      setState("done");
    }, 1100);
  };

  return (
    <>
      <Panel title="Lancer une évaluation" note="ciblée sur les lacunes détectées" delay={0}>
        <div className="launch">
          <label className="field field-inline">
            <span className="field-label">Collaborateur</span>
            <select value={person.user_id} onChange={(e) => { setSel(Number(e.target.value)); setResult(null); setState("idle"); }}>
              {people.data.map((p) => <option key={p.user_id} value={p.user_id}>{p.name} — {p.overall.toFixed(1)}%</option>)}
            </select>
          </label>
          <label className="field field-inline">
            <span className="field-label">Périmètre</span>
            <select value={scope} onChange={(e) => { setScope(e.target.value); setResult(null); setState("idle"); }}>
              <option value="lacunes">Compétences sous le seuil</option>
              <option value="complet">Tous les services</option>
            </select>
          </label>
          <button className="btn-signin btn-inline" onClick={launch} disabled={state === "running"}>
            {state === "running" ? <><Loader2 size={16} strokeWidth={2.4} className="spin" />Préparation…</>
              : <><Play size={15} strokeWidth={2.4} />Préparer l'évaluation</>}
          </button>
        </div>
        <div className="launch-info">
          <span>{gaps.length} compétence{gaps.length > 1 ? "s" : ""} sous le seuil</span>
          {gaps.length > 0 && <span className="dim">· {gaps.join(", ")}</span>}
        </div>
        {result && (
          <div className="notice pop"><Check size={15} strokeWidth={2.6} />
            <div>Sélection prête pour <strong>{result.who}</strong> — {result.count} question(s)
              sur {result.focus.join(", ")}.</div></div>
        )}
      </Panel>
      <Panel title="Questions sélectionnées" note={`${picked.length} correspondance(s)`} delay={.15}>
        {questions.loading ? <Loading /> : picked.length === 0 ? <Empty>Aucune question sur ce périmètre.</Empty> : (
          <table className="table">
            <thead><tr><th>Question</th><th>Service</th><th>Difficulté</th></tr></thead>
            <tbody>
              {picked.slice(0, 10).map((q) => (
                <tr key={q.id}><td className="q-text">{q.text}</td>
                  <td><strong>{short(q.service)}</strong></td>
                  <td><span className={`tag tag-${q.level}`}>{q.level}</span></td></tr>
              ))}
            </tbody>
          </table>
        )}
      </Panel>
    </>
  );
}

function Resultats() {
  const { data, error, loading, reload } = useApi("/api/evaluations?limit=50");
  const [filter, setFilter] = useState("");
  if (loading) return <Loading label="Chargement des évaluations…" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!data.length) return <Empty>Aucune évaluation enregistrée.</Empty>;

  const people = [...new Set(data.map((e) => e.person))];
  const rows = filter ? data.filter((e) => e.person === filter) : data;
  const avg = data.reduce((a, e) => a + (e.final || 0), 0) / data.length;

  return (
    <>
      <div className="stat-row">
        <Stat label="Évaluations" value={data.length} />
        <Stat label="Score moyen" value={`${avg.toFixed(2)}/4`} delay={.06} />
        <Stat label="Vetos appliqués" value={data.filter((e) => e.veto).length} sub="hallucination détectée" tone={BAND_COLOR.critical} delay={.12} />
        <Stat label="Collaborateurs" value={people.length} delay={.18} />
      </div>
      <Panel title="Évaluations récentes" note="score détaillé par agent" delay={.24}>
        <div className="chip-row">
          <button className={`chip${!filter ? " chip-on" : ""}`} onClick={() => setFilter("")}>Tous</button>
          {people.map((p) => (
            <button key={p} className={`chip${filter === p ? " chip-on" : ""}`} onClick={() => setFilter(p)}>{p}</button>
          ))}
        </div>
        <table className="table">
          <thead><tr><th>Date</th><th>Collaborateur</th><th>Service</th><th>Difficulté</th>
            <th>Exactitude</th><th>Raisonnement</th><th>Vérification</th><th>Score</th></tr></thead>
          <tbody>
            {rows.map((e) => (
              <tr key={e.id} className={e.veto ? "row-veto" : ""}>
                <td className="mono dim">{e.date}</td><td>{e.person}</td>
                <td><strong>{short(e.service)}</strong></td>
                <td><span className={`tag tag-${e.difficulty}`}>{e.difficulty}</span></td>
                <td className="mono">{e.grader?.toFixed(1)}</td><td className="mono">{e.reasoner?.toFixed(1)}</td>
                <td className="mono">{e.critic?.toFixed(1)}</td>
                <td className="mono strong">{e.final?.toFixed(2)}{e.veto && <span className="tag tag-danger">veto</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </>
  );
}

/* ═══════════════ VUES ADMIN ═══════════════ */
function Comptes() {
  const { data, error, loading, reload } = useApi("/api/users");
  const { api, token } = useCtx();
  const [form, setForm] = useState({ full_name: "", email: "", password: "", role: "collaborateur" });
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const create = async () => {
    if (!form.full_name || !form.email || !form.password) {
      setMsg({ ok: false, t: "Renseignez un nom, un email et un mot de passe." }); return;
    }
    setBusy(true);
    try {
      await apiFetch(api, "/auth/register", token, { method: "POST", body: JSON.stringify({ ...form, org_name: "CMH" }) });
      setMsg({ ok: true, t: `Compte créé pour ${form.full_name}.` });
      setForm({ full_name: "", email: "", password: "", role: "collaborateur" });
      reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(false);
  };

  return (
    <>
      <div className="stat-row">
        <Stat label="Comptes actifs" value={data?.length ?? "…"} />
        <Stat label="Rôles distincts" value={5} delay={.06} />
        <Stat label="Sécurité" value="bcrypt" sub="+ JWT signé" tone={BAND_COLOR.high} delay={.12} />
        <Stat label="Organisation" value="CMH" delay={.18} />
      </div>
      <Panel title="Créer un compte" note="le mot de passe est hashé côté serveur" delay={.24}>
        <div className="launch">
          <label className="field field-inline"><span className="field-label">Nom complet</span>
            <input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} placeholder="Prénom Nom" /></label>
          <label className="field field-inline"><span className="field-label">Email</span>
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="prenom@cmh.ma" /></label>
          <label className="field field-inline"><span className="field-label">Mot de passe</span>
            <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" /></label>
          <label className="field field-inline"><span className="field-label">Rôle</span>
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              {Object.entries(ROLE_META).map(([k, m]) => <option key={k} value={k}>{m.label}</option>)}
            </select></label>
          <button className="btn-signin btn-inline" onClick={create} disabled={busy}>
            {busy ? <><Loader2 size={15} className="spin" strokeWidth={2.4} />Création…</> : "Créer le compte"}</button>
        </div>
        {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
          {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}<div>{msg.t}</div></div>}
      </Panel>
      <Panel title="Comptes et rôles" note="contrôle d'accès (RBAC)" delay={.3}>
        {loading ? <Loading /> : error ? <ErrorState message={error} onRetry={reload} /> : (
          <table className="table">
            <thead><tr><th>Nom</th><th>Email</th><th>Rôle</th><th>Profil métier</th></tr></thead>
            <tbody>
              {data.map((u) => {
                const meta = ROLE_META[u.role] || ROLE_META.collaborateur;
                const Ico = meta.icon;
                return (
                  <tr key={u.id}>
                    <td><div className="cell-user"><span className={`demo-av tint-${meta.tint}`}><Ico size={13} strokeWidth={2.2} /></span>
                      <strong>{u.name}</strong></div></td>
                    <td className="mono dim">{u.email}</td>
                    <td><span className={`tag tag-role tag-${u.role}`}>{meta.label}</span></td>
                    <td className="mono dim">{u.profile_user_id ?? "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </Panel>
    </>
  );
}

function ServicesVue() {
  const { data, error, loading, reload } = useApi("/api/system");
  if (loading) return <Loading label="Interrogation des services…" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  const up = (data.services || []).filter((s) => s.state === "actif").length;
  return (
    <>
      <div className="stat-row">
        <Stat label="Fragments indexés" value={data.fragments?.toLocaleString("fr-FR") ?? "—"} sub={`${data.vector_size ?? "?"} dimensions`} />
        <Stat label="Évaluations en base" value={data.evaluations ?? "—"} delay={.06} />
        <Stat label="Questions retenues" value={data.questions ?? "—"} delay={.12} />
        <Stat label="Services actifs" value={`${up}/${data.services?.length ?? 0}`} tone={up === data.services?.length ? BAND_COLOR.high : BAND_COLOR.low} delay={.18} />
      </div>
      <Panel title="Services de la plateforme" note="état réel des conteneurs" delay={.24}
        action={<button className="btn-mini" onClick={reload}><RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
        <table className="table">
          <thead><tr><th>Service</th><th>Conteneur</th><th>État</th><th>Détail</th></tr></thead>
          <tbody>
            {(data.services || []).map((s) => (
              <tr key={s.container}>
                <td><strong>{s.name}</strong></td><td className="mono dim">{s.container}</td>
                <td><span className={`dot ${s.state === "actif" ? "dot-on" : "dot-off"}`} />{s.state}</td>
                <td className="dim">{s.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
      <Panel title="Configuration de la recherche" delay={.3}>
        <div className="kv">
          <div><span>Modèle d'embedding</span><strong className="mono">{data.embedding}</strong></div>
          <div><span>Dimensions</span><strong className="mono">{data.vector_size ?? "—"}</strong></div>
          <div><span>Recherche</span><strong>BM25 + dense (fusion RRF) puis reranking</strong></div>
          <div><span>Langues</span><strong>Français et anglais (retrieval cross-lingue)</strong></div>
        </div>
      </Panel>
    </>
  );
}

function QualiteRAG() {
  const { data, error, loading, reload } = useApi("/api/system");
  if (loading) return <Loading />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  return (
    <>
      <Panel title="Mesures RAGAS" note="résultats des campagnes d'évaluation" delay={0}>
        {data.ragas_raw ? <pre className="raw">{data.ragas_raw}</pre>
          : <Empty>Aucun fichier resultats_ragas_final.txt trouvé à la racine du projet.</Empty>}
      </Panel>
      <Panel title="Corpus et génération" delay={.15}>
        <div className="kv">
          <div><span>Fragments indexés</span><strong className="mono">{data.fragments?.toLocaleString("fr-FR") ?? "—"}</strong></div>
          <div><span>Questions retenues</span><strong className="mono">{data.questions ?? "—"}</strong></div>
          <div><span>Évaluations enregistrées</span><strong className="mono">{data.evaluations ?? "—"}</strong></div>
          <div><span>Collaborateurs</span><strong className="mono">{data.users ?? "—"}</strong></div>
        </div>
      </Panel>
    </>
  );
}

/* ═══════════════ ROUTES ═══════════════ */
const ROUTES = {
  profil:       { label: "Mon profil",            icon: UserCircle,    view: MonProfil },
  parcours:     { label: "Mon parcours",          icon: Route,         view: MonParcours },
  mesevals:     { label: "Mes évaluations",       icon: ClipboardList, view: MesEvaluations },
  equipe:       { label: "Mon équipe",            icon: Users,         view: EquipeVue },
  detail:       { label: "Détail collaborateur",  icon: UserCircle,    view: DetailCollaborateur },
  cartographie: { label: "Cartographie",          icon: Grid3x3,       view: Cartographie },
  profils:      { label: "Profils",               icon: Users,         view: Profils },
  besoins:      { label: "Besoins de formation",  icon: Target,        view: Besoins },
  ontologie:    { label: "Ontologie",             icon: Share2,        view: Ontologie },
  questions:    { label: "Banque de questions",   icon: FileQuestion,  view: BanqueQuestions },
  lancer:       { label: "Lancer une évaluation", icon: Play,          view: LancerEvaluation },
  resultats:    { label: "Résultats",             icon: ListChecks,    view: Resultats },
  comptes:      { label: "Comptes et rôles",      icon: Users,         view: Comptes },
  services:     { label: "Services",              icon: Database,      view: ServicesVue },
  ragas:        { label: "Qualité du RAG",        icon: GaugeIcon,     view: QualiteRAG },
};

const NAV = {
  collaborateur: ["profil", "parcours", "mesevals"],
  manager:       ["equipe", "detail", "ontologie"],
  rh:            ["cartographie", "profils", "besoins", "ontologie"],
  formateur:     ["questions", "lancer", "resultats"],
  admin:         ["comptes", "services", "ragas", "cartographie", "ontologie"],
};

/* ═══════════════ ESPACE DE TRAVAIL ═══════════════ */
function Workspace({ user, dark, toggleDark, onSignOut }) {
  const keys = NAV[user.role] || ["profil"];
  const [route, setRoute] = useState(keys[0]);
  const meta = ROLE_META[user.role];
  const Ico = meta.icon;
  const Current = ROUTES[route].view;

  return (
    <div className="dash fade-in">
      <aside className="dash-side">
        <div className="logo logo-sm">
          <span className="logo-mark"><Bot size={16} strokeWidth={2.2} /></span>
          <span className="logo-word">EvaSmart</span>
        </div>
        <nav>
          {keys.map((k) => {
            const R = ROUTES[k], I = R.icon;
            return (
              <button key={k} className={`dnav${route === k ? " on" : ""}`} onClick={() => setRoute(k)}
                aria-current={route === k ? "page" : undefined}>
                <I size={15} strokeWidth={2.1} />{R.label}
              </button>
            );
          })}
        </nav>
        <div className="side-tools">
          <button className="theme-inline" onClick={toggleDark}>
            {dark ? <Sun size={14} strokeWidth={2.2} /> : <Moon size={14} strokeWidth={2.2} />}
            {dark ? "Mode clair" : "Mode sombre"}
          </button>
        </div>
        <div className="dash-who">
          <span className={`demo-av tint-${meta.tint}`}><Ico size={15} strokeWidth={2.2} /></span>
          <div><strong>{user.name}</strong><span>{meta.label}</span></div>
        </div>
        <button className="dnav quiet" onClick={onSignOut}><LogOut size={15} strokeWidth={2.1} />Se déconnecter</button>
      </aside>

      <main className="dash-main">
        <header className="dash-top">
          <div>
            <span className="eyebrow">{meta.label}</span>
            <h1>{ROUTES[route].label}</h1>
          </div>
          <div className="top-right">
            <span className="chip-live"><span className="live-dot" />API connectée</span>
            <span className="org-tag">CMH</span>
          </div>
        </header>
        <div className="dash-body" key={route}><Current /></div>
      </main>
    </div>
  );
}

/* ═══════════════ APP ═══════════════ */
export default function App() {
  const [dark, setDark] = useState(false);
  const [stage, setStage] = useState("login");
  const [session, setSession] = useState(null);
  const [api, setApi] = useState(DEFAULT_API);

  useEffect(() => {
    document.body.className = dark ? "dark" : "";
  }, [dark]);

  return (
    <Ctx.Provider value={{ dark, token: session?.token, api }}>
      <div className={`app${dark ? " dark" : ""}`}>
        {stage === "login" && (
          <Login dark={dark} toggleDark={() => setDark(!dark)} api={api} setApi={setApi}
            onSuccess={(s) => { setSession(s); setStage("boot"); }} />
        )}
        {stage === "boot" && <Boot user={session} onDone={() => setStage("app")} />}
        {stage === "app" && (
          <Workspace user={session} dark={dark} toggleDark={() => setDark(!dark)}
            onSignOut={() => { setSession(null); setStage("login"); }} />
        )}
      </div>
    </Ctx.Provider>
  );
}
