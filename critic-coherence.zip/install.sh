#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p archive/before_fix
cp agents/critic.py archive/before_fix/critic_v5_before_coherence.py
echo "Sauvegarde : archive/before_fix/critic_v5_before_coherence.py"
python3 "$P/fix_coherence.py"
echo ""
echo "Test :  python scripts/test_critic_v5.py"
