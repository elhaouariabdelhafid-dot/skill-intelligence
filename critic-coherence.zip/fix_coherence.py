"""Separe la detection du barème.

PRINCIPE : le modele identifie les problemes et remplit les listes ; le code
decide de la note. Un modele de petite taille sait souvent reperer une anomalie
sans savoir la ponderer — la preuve : sur la recommandation dangereuse, il a
correctement rempli `contradictions` tout en renvoyant une severite de 0.

DEUX CORRECTIONS COMPLEMENTAIRES :
  1. le prompt cesse d'excuser ce qui est absent du corpus (sinon un service
     invente, absent par definition, n'est jamais signale)
  2. la severite est recalculee a partir des preuves reellement fournies
"""
from pathlib import Path
import re
import sys

p = Path("agents/critic.py")
if not p.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

s = p.read_text(encoding="utf-8")

# ── 1. Le prompt n'excuse plus l'absence du corpus ──
old_excl = "- something simply absent from the corpus but plausible"
new_excl = ("- a REAL AWS fact that this excerpt happens not to mention\n"
            "  (a name or behaviour that does not exist in AWS is still a\n"
            "   hallucination, however plausible it sounds)")
if old_excl in s:
    s = s.replace(old_excl, new_excl)
    print("1. exclusion precisee : l'absence du corpus n'excuse plus l'invention")
elif "REAL AWS fact" in s:
    print("1. exclusion deja precisee")
else:
    print("1. ATTENTION : ligne d'exclusion non trouvee")

# ── 2. Coherence entre preuves et severite ──
m = re.search(
    r'    problems = \[\].*?return \{"critic": AgentResult\(.*?\)\}',
    s, re.S)
if m is None:
    print("2. ERREUR : bloc de retour introuvable"); sys.exit(1)

new_block = '''    # Les listes sont d'abord nettoyees : un modele de petite taille y recopie
    # parfois le libelle de la consigne au lieu d'un constat.
    hallucinations = [h.strip() for h in (out.hallucinations or [])
                      if h and h.strip() and not _is_echo(h)]
    contradictions = [c.strip() for c in (out.contradictions or [])
                      if c and c.strip() and not _is_echo(c)]

    try:
        severity = int(float(out.problem_severity))
    except (TypeError, ValueError):
        severity = 0
    severity = max(0, min(4, severity))
    major = bool(out.has_major_hallucination)

    # La note decoule des preuves fournies, pas de l'appreciation du modele :
    # il sait reperer une anomalie sans savoir la ponderer.
    if not hallucinations and not contradictions:
        # Aucune preuve : une severite annoncee n'est pas exploitable
        severity, major = 0, False
    elif hallucinations:
        # Invention : le cas le plus grave, veto systematique
        severity, major = 4, True
    else:
        # Contradiction ou recommandation dangereuse : plancher a 2
        severity = max(2, severity)
        major = severity >= 4

    problems = []
    if hallucinations:
        problems.append("Hallucinations : " + "; ".join(hallucinations))
    if contradictions:
        problems.append("Contradictions : " + "; ".join(contradictions))
    justification = " | ".join(problems) if problems else "Aucun probleme detecte."

    # La severite est portee par le score, le veto par les citations.
    return {"critic": AgentResult(
        score=float(severity),
        justification=justification,
        citations=["MAJOR_HALLUCINATION"] if major else [],
    )}'''

s = s[:m.start()] + new_block + s[m.end():]
print("2. coherence preuves/severite appliquee")

# ── 3. S'assurer que le filtre d'echo existe ──
if "_is_echo" not in s.split("def criticize")[0]:
    guard = '''

def _is_echo(item: str) -> bool:
    """Ecarte un element de liste qui reprend la consigne au lieu d'un constat."""
    low = (item or "").lower()
    marqueurs = ("do not exist", "does not exist", "contrary to the evidence",
                 "empty list", "nothing found", "an aws name", "invented aws")
    return any(m in low for m in marqueurs)
'''
    s = s.replace("\ndef criticize(", guard + "\ndef criticize(", 1)
    print("3. filtre d'echo ajoute")
else:
    print("3. filtre d'echo deja present")

p.write_text(s, encoding="utf-8")
import ast; ast.parse(s)
print("\nagents/critic.py corrige et valide.")
