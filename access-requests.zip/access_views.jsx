/* ═══════════════ DEMANDES D'ACCÈS — ADMINISTRATEUR ═══════════════ */
function DemandesAcces() {
  const { api, token } = useCtx();
  const list = useApi("/api/access/requests");
  const [filter, setFilter] = useState("en_attente");
  const [choice, setChoice] = useState({});
  const [comment, setComment] = useState({});
  const [busy, setBusy] = useState(null);
  const [issued, setIssued] = useState(null);
  const [msg, setMsg] = useState(null);

  const decide = async (r, decision) => {
    setBusy(r.id); setMsg(null); setIssued(null);
    try {
      const res = await apiFetch(api, `/api/access/requests/${r.id}/decide`, token, {
        method: "POST",
        body: JSON.stringify({
          decision,
          role: choice[r.id] || r.requested_role,
          comment: comment[r.id] || "",
        }),
      });
      if (res.temp_password) {
        setIssued({ email: res.email, password: res.temp_password });
      } else {
        setMsg({ ok: true, t: `Demande de ${r.full_name} refusée.` });
      }
      setComment((c) => ({ ...c, [r.id]: "" }));
      list.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(null);
  };

  if (list.loading) return <Loading label="Chargement des demandes…" />;
  if (list.error) return <ErrorState message={list.error} onRetry={list.reload} />;

  const counts = list.data.reduce((a, r) => ({ ...a, [r.status]: (a[r.status] || 0) + 1 }), {});
  const rows = filter === "toutes" ? list.data : list.data.filter((r) => r.status === filter);

  return (
    <>
      <div className="stat-row">
        <Stat label="Demandes reçues" value={list.data.length} />
        <Stat label="En attente" value={counts.en_attente || 0}
          tone={counts.en_attente ? "#E8930C" : undefined} delay={.06} />
        <Stat label="Comptes créés" value={counts.approuvee || 0} tone="#0EA47C" delay={.12} />
        <Stat label="Refusées" value={counts.refusee || 0} delay={.18} />
      </div>

      {issued && (
        <div className="cred-box pop">
          <div className="cred-head">
            <span className="cred-ico"><Check size={17} strokeWidth={2.8} /></span>
            <div>
              <strong>Compte créé</strong>
              <span>Transmettez ces identifiants à la personne. Ils ne seront plus affichés.</span>
            </div>
            <button className="btn-mini" onClick={() => setIssued(null)}>Fermer</button>
          </div>
          <div className="cred-grid">
            <div><span>Identifiant</span><strong className="mono">{issued.email}</strong></div>
            <div><span>Mot de passe provisoire</span><strong className="mono cred-pwd">{issued.password}</strong></div>
          </div>
        </div>
      )}

      {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
        {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}
        <div>{msg.t}</div></div>}

      <Panel title="File des demandes d'accès" note="création de compte après validation" delay={.24}
        action={<button className="btn-mini" onClick={list.reload}>
          <RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
        <div className="chip-row">
          {["en_attente", "approuvee", "refusee", "toutes"].map((f) => (
            <button key={f} className={`chip chip-sm${filter === f ? " chip-on" : ""}`}
              onClick={() => setFilter(f)}>
              {f.replace("_", " ")}{f !== "toutes" && counts[f] ? ` (${counts[f]})` : ""}
            </button>
          ))}
        </div>

        {!rows.length ? <Empty>Aucune demande dans cette catégorie.</Empty> : (
          <div className="req-list">
            {rows.map((r, i) => (
              <div key={r.id} className="req-card rise" style={{ animationDelay: `${0.05 * i}s` }}>
                <div className="req-main">
                  <div className="req-head">
                    <strong>{r.full_name}</strong>
                    <div className="req-tags">
                      <span className={`tag tag-${r.requested_role}`}>
                        {ROLE_META[r.requested_role]?.label || r.requested_role}
                      </span>
                      <span className={`tag rstatus-${r.status === "en_attente" ? "en_attente"
                        : r.status === "approuvee" ? "validée" : "refusée"}`}>
                        {r.status.replace("_", " ")}
                      </span>
                    </div>
                  </div>
                  <div className="req-meta">
                    <span><Mail size={12} strokeWidth={2.2} />{r.email}</span>
                    <span className="dim mono">#{r.id} · {r.created_at}</span>
                  </div>
                  {r.reason && <p className="req-just">{r.reason}</p>}
                  {r.review_comment && (
                    <div className="req-review">
                      <MessageSquare size={12} strokeWidth={2.2} />
                      <span><strong>Décision</strong> — {r.review_comment}</span>
                    </div>
                  )}
                  {r.created_account_id && (
                    <div className="req-linked"><Check size={12} strokeWidth={2.4} />
                      Compte actif (identifiant #{r.created_account_id})</div>
                  )}
                </div>

                {r.status === "en_attente" && (
                  <div className="req-actions">
                    <label className="field field-inline" style={{ minWidth: 0 }}>
                      <span className="field-label">Rôle accordé</span>
                      <select value={choice[r.id] || r.requested_role}
                        onChange={(e) => setChoice({ ...choice, [r.id]: e.target.value })}>
                        {Object.entries(ROLE_META).map(([k, m]) =>
                          <option key={k} value={k}>{m.label}</option>)}
                      </select>
                    </label>
                    <textarea className="review-comment" placeholder="Commentaire (facultatif)"
                      value={comment[r.id] || ""}
                      onChange={(e) => setComment({ ...comment, [r.id]: e.target.value })} />
                    <div className="review-btns">
                      <button className="btn-act btn-act-ok" disabled={busy === r.id}
                        onClick={() => decide(r, "approuvee")}>
                        {busy === r.id ? <Loader2 size={14} className="spin" strokeWidth={2.4} />
                          : <Check size={14} strokeWidth={2.4} />}Créer le compte
                      </button>
                      <button className="btn-act btn-act-no" disabled={busy === r.id}
                        onClick={() => decide(r, "refusee")}>
                        <X size={14} strokeWidth={2.4} />Refuser
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </Panel>
    </>
  );
}
