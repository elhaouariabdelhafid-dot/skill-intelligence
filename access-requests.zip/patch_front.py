"""Branche le formulaire public sur l'API et ajoute l'ecran admin."""
from pathlib import Path
import sys, re

APP, CSS = Path("src/App.jsx"), Path("src/styles.css")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "DemandesAcces" in s:
    print("Deja en place."); sys.exit(0)

# ── 1. Le formulaire public envoie vraiment la demande ──
old_submit = """  const submit = () => {
    if (!form.full_name.trim() || !form.email.trim()) { setState("error"); return; }
    setState("sending");
    // La création effective revient à l'administrateur : on enregistre l'intention.
    setTimeout(() => setState("sent"), 900);
  };"""

new_submit = """  const [err, setErr] = useState("");

  const submit = async () => {
    if (!form.full_name.trim() || !form.email.trim()) {
      setErr("Renseignez au moins votre nom et votre email.");
      setState("error"); return;
    }
    setState("sending"); setErr("");
    try {
      await fetch(`${api}/api/access/request`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      }).then(async (r) => {
        if (!r.ok) {
          const j = await r.json().catch(() => ({}));
          throw new Error(j.detail || "Envoi impossible");
        }
      });
      setState("sent");
    } catch (e) {
      setErr(e.message === "Failed to fetch"
        ? "Serveur injoignable. Réessayez plus tard."
        : e.message);
      setState("error");
    }
  };"""

if old_submit in s:
    s = s.replace(old_submit, new_submit)
    print("1. formulaire public branche sur l'API")
else:
    print("1. ATTENTION : bloc submit non trouve")

# Message d'erreur dynamique
s = s.replace(
    '<span aria-hidden="true">❌</span> Renseignez au moins votre nom et votre email',
    '<span aria-hidden="true">❌</span> {err || "Renseignez au moins votre nom et votre email"}')

# ── 2. Vue admin ──
block = Path("access_views.jsx").read_text(encoding="utf-8")
anchor = "/* ═══════════════ ROUTES ═══════════════ */"
s = s.replace(anchor, block + "\n" + anchor)
print("2. vue admin inseree")

# ── 3. Route + navigation ──
s = s.replace(
    '  audit:        { label: "Journal d\'audit",       icon: ScrollText,    view: Audit },',
    '  audit:        { label: "Journal d\'audit",       icon: ScrollText,    view: Audit },\n'
    '  acces:        { label: "Demandes d\'accès",      icon: UserPlus,      view: DemandesAcces },')
s = s.replace(
    '  admin:         ["comptes", "configuration", "corpus", "services", "audit"],',
    '  admin:         ["acces", "comptes", "configuration", "corpus", "services", "audit"],')
print("3. route et navigation ajoutees")

# ── 4. Icone ──
m = re.search(r'\n\} from "lucide-react";', s)
s = s[:m.start()] + ",\n  UserPlus" + s[m.start():]

# ── 5. Badge de notification dans le menu ──
old_nav = """            return (
              <button key={k} className={`dnav${route === k ? " on" : ""}`} onClick={() => setRoute(k)}
                aria-current={route === k ? "page" : undefined}>
                <I size={15} strokeWidth={2.1} />{R.label}
              </button>
            );"""
new_nav = """            return (
              <button key={k} className={`dnav${route === k ? " on" : ""}`} onClick={() => setRoute(k)}
                aria-current={route === k ? "page" : undefined}>
                <I size={15} strokeWidth={2.1} />{R.label}
                {k === "acces" && pending > 0 && <span className="nav-badge">{pending}</span>}
              </button>
            );"""
if old_nav in s:
    s = s.replace(old_nav, new_nav)
    # Compteur dans Workspace
    s = s.replace(
        "  const Current = ROUTES[route].view;",
        "  const Current = ROUTES[route].view;\n"
        "  // Badge de notification : demandes d'acces en attente (admin seulement)\n"
        "  const [pending, setPending] = useState(0);\n"
        "  const ctx = useCtx();\n"
        "  useEffect(() => {\n"
        "    if (user.role !== \"admin\") return;\n"
        "    let alive = true;\n"
        "    const tick = () => apiFetch(ctx.api, \"/api/access/pending-count\", ctx.token)\n"
        "      .then((d) => { if (alive) setPending(d.pending); })\n"
        "      .catch(() => {});\n"
        "    tick();\n"
        "    const t = setInterval(tick, 20000);\n"
        "    return () => { alive = false; clearInterval(t); };\n"
        "  }, [user.role, route, ctx.api, ctx.token]);")
    print("4. badge de notification ajoute")

APP.write_text(s, encoding="utf-8")

c = CSS.read_text(encoding="utf-8")
if ".cred-box" not in c:
    CSS.write_text(c + Path("access.css").read_text(encoding="utf-8"), encoding="utf-8")
    print("5. styles ajoutes")

print("\nTermine. Relancez : npm run dev")
