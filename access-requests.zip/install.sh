#!/usr/bin/env bash
set -euo pipefail
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Backend"
cd "$HOME/skill-intelligence"
cp "$P/access_models.py" api/access_models.py
cp "$P/access_api.py"    api/access_api.py
python - << 'PYEOF'
from pathlib import Path
p = Path("api/main.py"); s = p.read_text()
if "access_api" not in s:
    s = s.replace(
        "from api.settings_api import router as admin_router\napp.include_router(admin_router)",
        "from api.settings_api import router as admin_router\n"
        "app.include_router(admin_router)\n\n"
        "from api.access_api import router as access_router\n"
        "app.include_router(access_router)")
    p.write_text(s); print("  routeur ajoute")
else:
    print("  routeur deja present")
PYEOF
python -c "from api.access_models import get_access_db; get_access_db().close(); print('  table access_requests prete')"

echo "==> Frontend"
D="$HOME/skill-intelligence/frontend-web"
cd "$D"
cp src/App.jsx src/App.jsx.bak5
cp src/styles.css src/styles.css.bak5
cp "$P/access_views.jsx" "$P/access.css" .
python3 "$P/patch_front.py"
rm -f access_views.jsx access.css

echo ""
echo "============================================================"
echo " Relancez l'API   :  uvicorn api.main:app --port 8010"
echo " Relancez le front:  cd $D && npm run dev"
echo "============================================================"
