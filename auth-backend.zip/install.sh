#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(dirname "${BASH_SOURCE[0]}")"

echo "==> Dépendances d'authentification"
pip install -q "bcrypt" "python-jose[cryptography]" "fastapi" "uvicorn" "email-validator" "pydantic[email]"

echo "==> Copie des modules auth"
mkdir -p auth
cp "$P/auth_models.py" auth/auth_models.py
cp "$P/security.py"    auth/security.py
cp "$P/auth_api.py"    auth/auth_api.py
cp "$P/seed_users.py"  auth/seed_users.py
touch auth/__init__.py

echo "==> Ajout de jwt_secret à config.py (si absent)"
python - << 'PYEOF'
from pathlib import Path
p = Path("config.py"); s = p.read_text()
if "jwt_secret" not in s:
    import re
    # Ajouter après database_url
    m = re.search(r"(    database_url:.*\n)", s)
    if m:
        s = s.replace(m.group(1), m.group(1) + '    jwt_secret: str = "change-me-in-production-please"\n')
        p.write_text(s)
        print("  jwt_secret ajouté")
else:
    print("  jwt_secret déjà présent")
PYEOF

echo "==> Création des comptes de démonstration"
python auth/seed_users.py

echo ""
echo "============================================================"
echo " Authentification installée."
echo " Les identifiants de démo sont affichés ci-dessus."
echo " Prochaine étape : le frontend React + le backend API complet."
echo "============================================================"
