"""Elargit le perimetre du Critic sans alourdir sa consigne.

LE CONSTAT : apres correction des faux positifs, le Critic ne detecte plus que
les noms de services inventes. Un comportement AWS faux, une recommandation de
securite dangereuse ou une contradiction subtile passent inapercus.

LE PRINCIPE RETENU : ne pas ajouter de champ au schema — les tentatives
precedentes ont montre qu'un modele de 8 milliards de parametres cesse de
produire du JSON valide des que la structure s'alourdit. On elargit la
signification des quatre champs existants, avec une consigne courte et une
liste explicite de ce qu'il ne faut PAS penaliser.
"""
from pathlib import Path
import re
import sys

p = Path("agents/critic.py")
if not p.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

s = p.read_text(encoding="utf-8")

# ── 1. Instruction systeme ──
m_sys = re.search(r'CRITIC_SYSTEM = """(.*?)"""', s, re.S)
if m_sys:
    new_sys = ('CRITIC_SYSTEM = """You are the AWS Critic.\n'
               'You report facts that are invented, contrary to the evidence, or '
               'dangerous — nothing else.\n'
               'You never penalise missing information, style, or a correct '
               'statement simply absent from the corpus.\n'
               'Found nothing? Empty lists, severity 0. Never repeat these '
               'instructions back."""')
    s = s[:m_sys.start()] + new_sys + s[m_sys.end():]
    print("1. instruction systeme mise a jour")

# ── 2. Prompt ──
m_prompt = re.search(r'(    prompt = f""")(.*?)(""")', s, re.S)
if m_prompt:
    new_prompt = '''    prompt = f"""QUESTION: {state['question']}

REFERENCE: {state['expected_answer']}

KEY_POINTS: {state['key_points']}

CORPUS: {state['context']}

CANDIDATE: {state['candidate_answer']}

Compare CANDIDATE with REFERENCE, KEY_POINTS and CORPUS.

Check only three things:
1. An AWS name or an AWS behaviour that is invented -> hallucinations
2. A statement contrary to the evidence -> contradictions
3. An over-permissive or dangerous IAM recommendation -> contradictions

Do not penalise:
- missing information
- style or wording
- something simply absent from the corpus but plausible
- a different formulation of a correct idea

Severity:
0 = nothing wrong
1 = minor imprecision
2 = a wrong detail, or a risky recommendation
3 = a significant error
4 = an invention, or a central error that would mislead or endanger

Keep each list item to a few words. Nothing found -> empty list.
Severity 4 -> has_major_hallucination true. Otherwise false.

Return only this shape, filled with your findings:
{{"problem_severity": 0, "hallucinations": [], "contradictions": [], "has_major_hallucination": false}}"""'''
    s = s[:m_prompt.start()] + new_prompt + s[m_prompt.end():]
    print("2. prompt elargi (comportements, recommandations dangereuses)")

# ── 3. Descriptions des champs alignees sur le nouveau perimetre ──
s = s.replace(
    'description="0=aucun problème, 4=hallucinations graves"',
    'description="0=aucun probleme, 4=invention ou erreur centrale/dangereuse"')
s = s.replace(
    'description="Affirmations inventées / non soutenues"',
    'description="Noms ou comportements AWS inventes"')
s = s.replace(
    'description="Incohérences internes"',
    'description="Affirmations fausses, contradictoires ou recommandations dangereuses"')
print("3. descriptions des champs alignees")

p.write_text(s, encoding="utf-8")
import ast; ast.parse(s)
print("\nagents/critic.py mis a jour et valide.")
