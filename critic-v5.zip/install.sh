#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p archive/before_fix
cp agents/critic.py archive/before_fix/critic_v4_working.py
echo "Sauvegarde : archive/before_fix/critic_v4_working.py"
echo "  (version qui passait 5/5 — restaurez-la en cas de regression)"
python3 "$P/fix_critic_v5.py"
cp "$P/test_critic_v5.py" scripts/test_critic_v5.py
echo ""
echo "Test :  python scripts/test_critic_v5.py"
