"""Remplace le panneau bleu du login par une presentation aux couleurs CMH."""
from pathlib import Path
import sys, re

APP = Path("src/App.jsx")
CSS = Path("src/styles.css")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "cmh-logo" in s:
    print("Deja applique."); sys.exit(0)

# ── Nouveau panneau gauche du login ──
new_hero = '''      <aside className="hero">
        <div className="hero-wash" />
        <div className="hero-inner">
          <img src="/cmh-logo.png" alt="Cloud Marketing Hub" className="hero-logo" />

          <div className="hero-badge"><Sparkles size={13} strokeWidth={2.4} />
            <span>Evaluation assistee par IA</span></div>

          <h1 className="hero-title">{typed}<span className={`caret${done ? " caret-done" : ""}`} aria-hidden="true" /></h1>

          <p className="hero-sub">
            Plateforme d'evaluation des competences Cloud. Chaque reponse est notee par
            trois agents specialises, rapportee a la documentation technique, puis replacee
            dans le graphe des prerequis pour batir un parcours qui suit un ordre logique.
          </p>

          <ul className="hero-points">
            <li><span className="hp-ico"><Brain size={15} strokeWidth={2.2} /></span>Trois agents evaluateurs avec veto anti-hallucination</li>
            <li><span className="hp-ico"><BookOpen size={15} strokeWidth={2.2} /></span>Reponses ancrees dans la documentation indexee</li>
            <li><span className="hp-ico"><GraduationCap size={15} strokeWidth={2.2} /></span>Parcours ordonnes par dependances entre competences</li>
          </ul>

          <div className="hero-foot">
            <span>7 services AWS · evaluation bilingue FR / EN</span>
          </div>
        </div>
      </aside>'''

# Remplacer le bloc <aside className="hero"> ... </aside> du composant Login
m = re.search(r'      <aside className="hero">.*?</aside>', s, re.S)
if not m:
    print("ERREUR : bloc hero introuvable"); sys.exit(1)
s = s[:m.start()] + new_hero + s[m.end():]
print("1. panneau du login remplace")

# La typographie machine a ecrire garde son texte, on l'ajuste
s = s.replace('useTyping("Bienvenue sur EvaSmart")',
              'useTyping("Evaluation des competences Cloud")')

APP.write_text(s, encoding="utf-8")

# ── Styles ──
c = CSS.read_text(encoding="utf-8")

# Palette reprise du logo CMH : magenta -> violet -> bleu
c = c.replace(
    "  --grad-a:#4F46E5; --grad-b:#2C6BE8; --grad-c:#7C3AED;",
    "  --grad-a:#7B2D8E; --grad-b:#1B75BC; --grad-c:#D6217A;\n"
    "  --cmh-navy:#1B3A6B;")

# Le hero devient clair
old_hero_css = re.search(r'\.hero\{[^}]*\}', c)
if old_hero_css:
    c = c[:old_hero_css.start()] + (
        ".hero{position:relative;overflow:hidden;display:flex;align-items:center;"
        "padding:48px 52px;background:#FFFFFF;border-right:1px solid var(--line);color:var(--ink)}"
    ) + c[old_hero_css.end():]

c += """

/* ===== panneau CMH (login) ===== */
body.dark .hero{background:#0B111E}
.hero-wash{position:absolute;inset:0;pointer-events:none;
  background:
    radial-gradient(560px 380px at 8% -6%, rgba(214,33,122,.10), transparent 62%),
    radial-gradient(520px 420px at 96% 108%, rgba(27,117,188,.12), transparent 60%),
    radial-gradient(420px 300px at 78% 12%, rgba(123,45,142,.07), transparent 64%)}
body.dark .hero-wash{
  background:
    radial-gradient(560px 380px at 8% -6%, rgba(214,33,122,.16), transparent 62%),
    radial-gradient(520px 420px at 96% 108%, rgba(27,117,188,.18), transparent 60%)}
.hero-logo{width:210px;height:auto;display:block;margin-bottom:30px}
body.dark .hero-logo{filter:brightness(0) invert(1) opacity(.92)}

.hero .hero-badge{background:rgba(123,45,142,.07);border:1px solid rgba(123,45,142,.18);
  color:var(--grad-a);backdrop-filter:none}
.hero .hero-title{color:var(--cmh-navy);font-size:36px;letter-spacing:-1.1px;margin-top:20px;min-height:46px}
body.dark .hero .hero-title{color:#E8EDF8}
.hero .caret{background:var(--grad-c)}
.hero .hero-sub{color:var(--ink-2);max-width:47ch;margin-top:15px}
.hero .hero-points li{color:var(--ink-2);font-size:13px}
.hero .hp-ico{background:linear-gradient(135deg,var(--grad-c),var(--grad-a) 55%,var(--grad-b));
  border:none;color:#fff;box-shadow:0 4px 12px -4px rgba(123,45,142,.45)}
.hero .hero-foot{margin-top:32px;padding-top:20px;border-top:1px solid var(--line);
  font-size:11.5px;color:var(--muted)}

/* Le bandeau de chargement reprend les couleurs du logo */
.boot{background:linear-gradient(140deg,#D6217A 0%,#7B2D8E 46%,#1B75BC 100%)}
body.dark .boot{background:linear-gradient(140deg,#7A1246 0%,#45184F 46%,#0F4470 100%)}

@media (max-width:1080px){ .hero-logo{width:170px} }
"""
CSS.write_text(c, encoding="utf-8")
print("2. styles CMH appliques")
print("\nTermine. Relancez : npm run dev")
