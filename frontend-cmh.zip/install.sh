#!/usr/bin/env bash
set -euo pipefail
D="$HOME/skill-intelligence/frontend-web"
[ -d "$D" ] || { echo "Dossier $D introuvable"; exit 1; }
[ -f "$D/public/cmh-logo.png" ] || { echo "Placez d'abord public/cmh-logo.png"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$D"
cp src/App.jsx src/App.jsx.bak2
cp src/styles.css src/styles.css.bak2
echo "Sauvegardes : src/App.jsx.bak2 · src/styles.css.bak2"
python3 "$P/patch_cmh.py"
echo ""
echo "Relancez :  cd $D && npm run dev"
