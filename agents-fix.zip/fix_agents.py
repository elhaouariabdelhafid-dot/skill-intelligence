"""Deux corrections ciblees sur les agents, sans toucher aux schemas.

CONSTAT 1 — Le Critic ne recoit ni les points cles attendus ni la reponse de
reference. Il ne peut donc pas savoir qu'une entite comme "AWS Policy Generator"
est legitime alors qu'elle figure explicitement dans les points cles. Il la
signale comme hallucination. On lui transmet ces elements.

CONSTAT 2 — Le Grader n'a aucun ancrage pour ses niveaux. Il donne 2/4 a une
reponse exacte mais concise, sans qu'on sache ce qu'il faudrait pour obtenir 3.
On decrit chaque niveau.

AUCUN CHAMP AJOUTE aux schemas Pydantic : une tentative precedente a montre
qu'un modele de 8 milliards de parametres cesse de produire du JSON valide
quand la structure demandee s'alourdit.
"""
from pathlib import Path
import re
import sys

ROOT = Path.cwd()
if not (ROOT / "agents").exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

# ══════════════ 1. Le Critic recoit les points cles et la reference ══════════════
p = ROOT / "agents" / "critic.py"
s = p.read_text(encoding="utf-8")

if "KEY POINTS EXPECTED" in s:
    print("1. Critic deja corrige")
else:
    old_ctx = '''DOCUMENTATION CONTEXT (source of truth):
{state['context']}

CANDIDATE'S ANSWER:
{state['candidate_answer']}'''
    new_ctx = '''DOCUMENTATION CONTEXT (an excerpt of the documentation):
{state['context']}

REFERENCE ANSWER (validated by the question author):
{state['expected_answer']}

KEY POINTS EXPECTED (validated by the question author):
{state['key_points']}

CANDIDATE'S ANSWER:
{state['candidate_answer']}'''
    if old_ctx in s:
        s = s.replace(old_ctx, new_ctx)
        print("1a. reference et points cles transmis au Critic")
    else:
        print("1a. ATTENTION : bloc de contexte du Critic non trouve")

    # Regle explicite : ce qui figure dans les points cles est legitime
    old_rule = "The context is an EXCERPT, not the whole documentation."
    new_rule = '''Anything named in the REFERENCE ANSWER or in the KEY POINTS is legitimate by
definition — never report it as a hallucination, whatever the excerpt says.

The context is an EXCERPT, not the whole documentation.'''
    if old_rule in s and "legitimate by" not in s:
        s = s.replace(old_rule, new_rule, 1)
        print("1b. regle ajoutee : les points cles font autorite")

    p.write_text(s, encoding="utf-8")
    import ast; ast.parse(s)

# ══════════════ 2. Ancrage des niveaux du Grader ══════════════
p = ROOT / "agents" / "grader.py"
s = p.read_text(encoding="utf-8")

if "LEVEL ANCHORS" in s:
    print("2. Grader deja corrige")
else:
    old_scale = re.search(
        r'Score 0-4 based ONLY on technical correctness:.*?(?=\n\nList|\nList)',
        s, re.S)
    if old_scale:
        new_scale = '''LEVEL ANCHORS — use them literally, do not invent stricter requirements:
- 4: every key point is covered and the claims are accurate
- 3: the answer is accurate and covers most key points; a short answer that
     names the right mechanism and explains it briefly deserves 3
- 2: accurate on the main point but several key points are missing
- 1: a few correct elements among significant errors
- 0: wrong, off-topic, or naming something that does not exist

Length is NOT a criterion. A concise answer that is correct and covers the key
points scores as high as a long one. Do not lower the score because the
candidate did not repeat the reference answer word for word.'''
        s = s[:old_scale.start()] + new_scale + s[old_scale.end():]
        p.write_text(s, encoding="utf-8")
        import ast; ast.parse(s)
        print("2. ancrage des niveaux ajoute au Grader")
    else:
        print("2. ATTENTION : echelle du Grader non trouvee")
        print("   Bloc actuel :")
        m = re.search(r'Score 0-4.*?"""', s, re.S)
        print("  ", (m.group(0)[:300] if m else "introuvable"))

print("\nCorrections appliquees.")
