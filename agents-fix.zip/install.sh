#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p archive/before_fix
cp agents/critic.py archive/before_fix/critic_before_keypoints.py
cp agents/grader.py archive/before_fix/grader_before_anchors.py
echo "Sauvegardes dans archive/before_fix/"
python3 "$P/fix_agents.py"
cp "$P/test_regression.py" scripts/test_regression.py
echo ""
echo "Test :  python scripts/test_regression.py"
