#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(dirname "${BASH_SOURCE[0]}")"

echo "==> Dépendances"
pip install -q sqlalchemy psycopg2-binary

echo "==> Copie des modules Phase 5"
cp "$P/models.py"          db/models.py
cp "$P/session.py"         db/session.py
cp "$P/profile.py"         skills/profile.py
cp "$P/recommendations.py" skills/recommendations.py
cp "$P/simulate.py"        skills/simulate.py

echo "==> Vérification"
python -c "import ast,glob; [ast.parse(open(f).read()) for f in glob.glob('db/*.py')+glob.glob('skills/*.py')]; print('  Syntaxe OK')"

echo "==> Test connexion PostgreSQL"
python -c "from db.models import get_session; s=get_session(); s.close(); print('  PostgreSQL OK — tables créées')" || \
  echo "  ATTENTION : PostgreSQL non accessible. Lance : docker start ski-postgres"

echo ""
echo "============================================================"
echo " Phase 5 installée. Démonstration :"
echo "   # 1. Simuler un collaborateur fort et un faible"
echo "   python skills/simulate.py --user-name Alice --level strong --n 6"
echo "   python skills/simulate.py --user-name Bob --level mixed --n 8"
echo "   # 2. Voir les profils"
echo "   python skills/profile.py --user 1"
echo "   python skills/profile.py --user 2"
echo "   # 3. Plan de formation"
echo "   python skills/recommendations.py --user 2"
echo "============================================================"
