#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(dirname "${BASH_SOURCE[0]}")"

echo "==> Installation de langgraph"
pip install -q langgraph

echo "==> Copie des agents"
cp "$P/state.py"           agents/state.py
cp "$P/grader.py"          agents/grader.py
cp "$P/reasoner.py"        agents/reasoner.py
cp "$P/critic.py"          agents/critic.py
cp "$P/aggregator.py"      agents/aggregator.py
cp "$P/graph.py"           agents/graph.py
cp "$P/test_evaluation.py" agents/test_evaluation.py

echo "==> Vérification syntaxe"
python -c "import ast,glob; [ast.parse(open(f).read()) for f in glob.glob('agents/*.py')]; print('  OK')"

echo ""
echo "============================================================"
echo " Phase 4 installée. Test :"
echo "   python agents/test_evaluation.py --quality good"
echo "   python agents/test_evaluation.py --quality bad"
echo "============================================================"
