"""Branche le frontend sur le seuil configure cote serveur."""
from pathlib import Path
import re, sys

APP = Path("src/App.jsx")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "useThreshold" in s:
    print("Deja branche."); sys.exit(0)

# 1) THRESHOLD devient une variable de module, alimentee au demarrage
old = "const THRESHOLD = 60;"
new = '''// Seuil de maitrise : valeur de repli, remplacee au demarrage par celle
// configuree par l'administrateur (GET /api/config/public).
let THRESHOLD = 60;

function useThreshold(api) {
  const [threshold, setThreshold] = useState(THRESHOLD);
  useEffect(() => {
    let alive = true;
    fetch(`${api}/api/config/public`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (alive && d && typeof d.skill_threshold === "number") {
          THRESHOLD = d.skill_threshold;   // les helpers band() s'y referent
          setThreshold(d.skill_threshold);
        }
      })
      .catch(() => {});
    return () => { alive = false; };
  }, [api]);
  return threshold;
}'''
if old in s:
    s = s.replace(old, new)
    print("1. THRESHOLD devient dynamique")
else:
    print("1. ERREUR : constante THRESHOLD non trouvee"); sys.exit(1)

# 2) L'App charge le seuil au demarrage
s = s.replace(
    "  const [api, setApi] = useState(DEFAULT_API);",
    "  const [api, setApi] = useState(DEFAULT_API);\n"
    "  const threshold = useThreshold(api);   // aligne l'affichage sur la config serveur")
print("2. chargement au demarrage")

# 3) Le contexte transporte le seuil, pour forcer le rendu a jour
s = s.replace(
    'value={{ dark, token: session?.token, api }}',
    'value={{ dark, token: session?.token, api, threshold }}')
print("3. seuil place dans le contexte")

APP.write_text(s, encoding="utf-8")
print("\nTermine. Relancez : npm run dev")
