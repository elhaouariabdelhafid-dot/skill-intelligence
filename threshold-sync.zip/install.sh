#!/usr/bin/env bash
set -euo pipefail
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Backend"
cd "$HOME/skill-intelligence"
cp "$P/threshold_api.py" api/config_api.py
python - << 'PYEOF'
from pathlib import Path
p = Path("api/main.py"); s = p.read_text()
if "config_api" not in s:
    s = s.rstrip() + "\n\nfrom api.config_api import router as config_router\napp.include_router(config_router)\n"
    p.write_text(s); print("  routeur config ajoute")
else:
    print("  routeur deja present")
PYEOF
python -c "from api.main import app; print('  imports OK')"

echo ""
echo "==> Frontend"
D="$HOME/skill-intelligence/frontend-web"
cd "$D"
cp src/App.jsx src/App.jsx.bak8
python3 "$P/patch_front.py"

echo ""
echo "============================================================"
echo " Relancez l'API   :  uvicorn api.main:app --port 8010"
echo " Relancez le front:  cd $D && npm run dev"
echo ""
echo " Verification :"
echo "   curl -s http://localhost:8010/api/config/public"
echo "   puis changez le seuil dans Configuration et rechargez l'interface"
echo "============================================================"
