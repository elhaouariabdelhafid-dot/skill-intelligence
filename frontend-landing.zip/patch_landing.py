"""Ajoute la page d'accueil publique comme point d'entrée."""
from pathlib import Path
import sys, re

APP = Path("src/App.jsx")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "function Landing(" in s:
    print("Page d'accueil déjà présente."); sys.exit(0)

block = Path("landing.jsx").read_text(encoding="utf-8")

# 1) Insérer les composants avant la section CONNEXION
anchor = "/* ═══════════════ CONNEXION ═══════════════ */"
if anchor not in s:
    print("ERREUR : ancre CONNEXION introuvable"); sys.exit(1)
s = s.replace(anchor, block + "\n" + anchor)
print("1. composants insérés")

# 2) Le login reçoit un bouton retour
s = s.replace(
    'function Login({ onSuccess, dark, toggleDark, api, setApi }) {',
    'function Login({ onSuccess, dark, toggleDark, api, setApi, onBack }) {')
s = s.replace(
    '      <main className="pane">\n        <button className="theme-toggle"',
    '      <main className="pane">\n'
    '        {onBack && <button className="btn-mini back-abs" onClick={onBack}>'
    '<ChevronLeft size={13} strokeWidth={2.4} />Accueil</button>}\n'
    '        <button className="theme-toggle"')
print("2. bouton retour ajouté au login")

# 3) App : nouvelle étape "landing" au démarrage
s = s.replace('  const [stage, setStage] = useState("login");',
              '  const [stage, setStage] = useState("landing");')
s = s.replace(
    '        {stage === "login" && (\n'
    '          <Login dark={dark} toggleDark={() => setDark(!dark)} api={api} setApi={setApi}\n'
    '            onSuccess={(s) => { setSession(s); setStage("boot"); }} />\n'
    '        )}',
    '        {stage === "landing" && (\n'
    '          <Landing dark={dark} toggleDark={() => setDark(!dark)}\n'
    '            onLogin={() => setStage("login")} onSignup={() => setStage("signup")} />\n'
    '        )}\n'
    '        {stage === "signup" && (\n'
    '          <SignupRequest api={api} onBack={() => setStage("landing")} />\n'
    '        )}\n'
    '        {stage === "login" && (\n'
    '          <Login dark={dark} toggleDark={() => setDark(!dark)} api={api} setApi={setApi}\n'
    '            onBack={() => setStage("landing")}\n'
    '            onSuccess={(s) => { setSession(s); setStage("boot"); }} />\n'
    '        )}')
print("3. étapes landing / signup ajoutées")

# 4) Déconnexion -> retour à l'accueil
s = s.replace('onSignOut={() => { setSession(null); setStage("login"); }}',
              'onSignOut={() => { setSession(null); setStage("landing"); }}')
print("4. déconnexion vers l'accueil")

APP.write_text(s, encoding="utf-8")

css = Path("src/styles.css")
c = css.read_text(encoding="utf-8")
if "lp-hero" not in c:
    css.write_text(c + "\n\n" + Path("landing.css").read_text(encoding="utf-8"), encoding="utf-8")
    print("5. styles ajoutés")

print("\nTerminé. Relancez : npm run dev")
