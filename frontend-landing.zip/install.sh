#!/usr/bin/env bash
set -euo pipefail
D="$HOME/skill-intelligence/frontend-web"
[ -d "$D" ] || { echo "Dossier $D introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$D"
cp "$D/src/App.jsx" "$D/src/App.jsx.bak"
echo "Sauvegarde : src/App.jsx.bak"
cp "$P/landing.jsx" "$P/landing.css" .
python3 "$P/patch_landing.py"
rm -f landing.jsx landing.css
echo ""
echo "Relancez :  cd $D && npm run dev"
