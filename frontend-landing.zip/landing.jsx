/* ═══════════════ PAGE D'ACCUEIL PUBLIQUE ═══════════════ */
function Landing({ dark, toggleDark, onLogin, onSignup }) {
  const [section, setSection] = useState("accueil");
  const { out: typed, done } = useTyping("Mesurer les compétences Cloud, vraiment.");

  const go = (s) => {
    setSection(s);
    const el = document.getElementById(`sec-${s}`);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="landing">
      <header className="nav">
        <div className="nav-brand">
          <span className="logo-mark"><Bot size={19} strokeWidth={2.2} /></span>
          <div>
            <strong>EvaSmart</strong>
            <span>Évaluation intelligente</span>
          </div>
        </div>
        <nav className="nav-links">
          {[["accueil", "Accueil"], ["apropos", "À propos"], ["contact", "Contact"]].map(([k, l]) => (
            <button key={k} className={`nav-link${section === k ? " on" : ""}`} onClick={() => go(k)}>{l}</button>
          ))}
        </nav>
        <div className="nav-actions">
          <button className="nav-icon" onClick={toggleDark} aria-label={dark ? "Mode clair" : "Mode sombre"}>
            {dark ? <Sun size={17} strokeWidth={2} /> : <Moon size={17} strokeWidth={2} />}
          </button>
          <button className="nav-ghost" onClick={onLogin}>Connexion</button>
          <button className="nav-cta" onClick={onSignup}>Demander un accès</button>
        </div>
      </header>

      {/* ── Hero ── */}
      <section id="sec-accueil" className="lp-hero">
        <div className="lp-orb lp-orb-1" /><div className="lp-orb lp-orb-2" />
        <div className="lp-hero-inner">
          <div className="lp-badge">
            <Sparkles size={13} strokeWidth={2.4} />
            <span>Trois agents évaluateurs · documentation AWS · graphe de prérequis</span>
          </div>
          <h1 className="lp-title">
            {typed}<span className={`caret${done ? " caret-done" : ""}`} aria-hidden="true" />
          </h1>
          <p className="lp-sub">
            EvaSmart évalue les réponses de vos collaborateurs en les confrontant à
            la documentation technique, puis replace chaque lacune dans le graphe
            des dépendances pour construire un parcours qui suit un ordre logique.
          </p>
          <div className="lp-cta-row">
            <button className="btn-signin btn-inline" onClick={onLogin}>
              Se connecter <ArrowRight size={17} strokeWidth={2.4} className="btn-arrow" />
            </button>
            <button className="btn-social lp-btn2" onClick={() => go("apropos")}>
              Comment ça fonctionne
            </button>
          </div>
          <div className="lp-figures">
            <div><strong>25 490</strong><span>fragments indexés</span></div>
            <div><strong>3</strong><span>agents évaluateurs</span></div>
            <div><strong>FR / EN</strong><span>évaluation bilingue</span></div>
          </div>
        </div>
      </section>

      {/* ── Le problème ── */}
      <section className="lp-section">
        <div className="lp-narrow">
          <span className="lp-eyebrow">Le constat</span>
          <h2 className="lp-h2">Un QCM mesure la mémoire, pas la compétence.</h2>
          <p className="lp-text">
            Les évaluations classiques valident des réponses attendues. Elles ne
            disent rien du raisonnement, ne détectent pas une affirmation inventée,
            et se périment au rythme des technologies. Résultat : des plans de
            formation construits sur des impressions plutôt que sur des mesures.
          </p>
        </div>
      </section>

      {/* ── Fonctionnement ── */}
      <section id="sec-apropos" className="lp-section lp-alt">
        <div className="lp-narrow">
          <span className="lp-eyebrow">Fonctionnement</span>
          <h2 className="lp-h2">De la réponse au parcours de formation</h2>
        </div>
        <div className="lp-steps">
          {[
            { n: "01", icon: BookOpen, t: "Ancrage documentaire",
              d: "La question et la réponse attendue proviennent de la documentation officielle, découpée et indexée. Rien n'est inventé." },
            { n: "02", icon: Brain, t: "Trois regards distincts",
              d: "Un agent vérifie l'exactitude, un second le raisonnement, un troisième traque les affirmations non fondées." },
            { n: "03", icon: ShieldCheck, t: "Veto sur l'invention",
              d: "Une réponse bien écrite mais inventée ne peut pas obtenir une bonne note : le score est plafonné." },
            { n: "04", icon: Share2, t: "Ordre des prérequis",
              d: "Une compétence faible dont les fondations manquent n'est pas recommandée en premier. Le graphe décide de l'ordre." },
          ].map((s, i) => {
            const I = s.icon;
            return (
              <div key={s.n} className="lp-step rise" style={{ animationDelay: `${0.06 * i}s` }}>
                <span className="lp-step-n">{s.n}</span>
                <span className="lp-step-ico"><I size={18} strokeWidth={2} /></span>
                <strong>{s.t}</strong>
                <p>{s.d}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* ── Rôles ── */}
      <section className="lp-section">
        <div className="lp-narrow">
          <span className="lp-eyebrow">Organisation</span>
          <h2 className="lp-h2">Chaque rôle a sa place dans le circuit</h2>
          <p className="lp-text">
            Le besoin remonte du terrain, il est arbitré, puis exécuté — comme
            dans une organisation réelle.
          </p>
        </div>
        <div className="lp-flow">
          {[
            { icon: Target, r: "Manager", d: "Identifie les lacunes de son équipe et soumet une demande d'évaluation." },
            { icon: Users, r: "Ressources humaines", d: "Arbitre les demandes au regard des priorités et du plan de formation." },
            { icon: Presentation, r: "Formateur", d: "Prépare le sujet, l'administre, déclenche l'évaluation." },
            { icon: User, r: "Collaborateur", d: "Répond, consulte son niveau et son parcours de progression." },
          ].map((x, i) => {
            const I = x.icon;
            return (
              <div key={x.r} className="lp-role rise" style={{ animationDelay: `${0.05 * i}s` }}>
                <span className="lp-role-ico"><I size={17} strokeWidth={2.1} /></span>
                <div><strong>{x.r}</strong><p>{x.d}</p></div>
                {i < 3 && <ChevronRight className="lp-role-arrow" size={16} strokeWidth={2.2} />}
              </div>
            );
          })}
        </div>
      </section>

      {/* ── Contact ── */}
      <section id="sec-contact" className="lp-section lp-alt">
        <div className="lp-narrow lp-contact">
          <span className="lp-eyebrow">Contact</span>
          <h2 className="lp-h2">Accéder à la plateforme</h2>
          <p className="lp-text">
            L'accès est réservé aux collaborateurs de l'organisation. Si vous
            disposez d'un compte, connectez-vous. Sinon, demandez un accès à
            l'administrateur.
          </p>
          <div className="lp-cta-row" style={{ justifyContent: "center" }}>
            <button className="btn-signin btn-inline" onClick={onLogin}>
              Se connecter <ArrowRight size={17} strokeWidth={2.4} className="btn-arrow" />
            </button>
            <button className="btn-social lp-btn2" onClick={onSignup}>Demander un accès</button>
          </div>
        </div>
      </section>

      <footer className="lp-footer">
        <div className="nav-brand">
          <span className="logo-mark"><Bot size={16} strokeWidth={2.2} /></span>
          <div><strong>EvaSmart</strong><span>Évaluation intelligente des compétences</span></div>
        </div>
        <span className="lp-foot-note">
          Mots de passe hashés · sessions signées · accès contrôlé par rôle
        </span>
      </footer>
    </div>
  );
}

/* ═══════════════ DEMANDE D'ACCÈS ═══════════════ */
function SignupRequest({ onBack, api }) {
  const [form, setForm] = useState({ full_name: "", email: "", role: "collaborateur", reason: "" });
  const [state, setState] = useState("idle");

  const submit = () => {
    if (!form.full_name.trim() || !form.email.trim()) { setState("error"); return; }
    setState("sending");
    // La création effective revient à l'administrateur : on enregistre l'intention.
    setTimeout(() => setState("sent"), 900);
  };

  if (state === "sent") {
    return (
      <div className="pane pane-full">
        <div className="card rise" style={{ textAlign: "center" }}>
          <span className="ok-badge"><Check size={26} strokeWidth={2.6} /></span>
          <h2 style={{ marginTop: 16 }}>Demande enregistrée</h2>
          <p className="form-lead" style={{ marginBottom: 22 }}>
            L'administrateur examinera votre demande et créera votre compte.
            Vous recevrez vos identifiants par courriel.
          </p>
          <button className="btn-signin" onClick={onBack}>Retour à l'accueil</button>
        </div>
      </div>
    );
  }

  return (
    <div className="pane pane-full">
      <button className="btn-mini back-abs" onClick={onBack}>
        <ChevronLeft size={13} strokeWidth={2.4} />Retour
      </button>
      <div className="card rise">
        <header className="card-head">
          <div className="logo">
            <span className="logo-mark"><Bot size={19} strokeWidth={2.2} /></span>
            <span className="logo-word">EvaSmart</span>
          </div>
          <h2>Demander un accès</h2>
          <p>L'administrateur créera votre compte après validation.</p>
        </header>
        <div className="fields">
          <label className="field">
            <span className="field-label">Nom complet</span>
            <span className="input-wrap">
              <input value={form.full_name} placeholder="Prénom Nom"
                onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
            </span>
          </label>
          <label className="field">
            <span className="field-label">Email professionnel</span>
            <span className="input-wrap">
              <Mail className="input-ico" size={16} strokeWidth={2} />
              <input type="email" value={form.email} placeholder="prenom@cmh.ma"
                onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </span>
          </label>
          <label className="field">
            <span className="field-label">Rôle souhaité</span>
            <span className="input-wrap">
              <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                {Object.entries(ROLE_META).map(([k, m]) => <option key={k} value={k}>{m.label}</option>)}
              </select>
            </span>
          </label>
          <label className="field">
            <span className="field-label">Motif de la demande</span>
            <textarea className="answer-area" style={{ minHeight: 92 }} value={form.reason}
              placeholder="Précisez votre service et l'usage attendu."
              onChange={(e) => setForm({ ...form, reason: e.target.value })} />
          </label>
          {state === "error" && (
            <div className="alert alert-error shake">
              <span aria-hidden="true">❌</span> Renseignez au moins votre nom et votre email
            </div>
          )}
          <button className="btn-signin" onClick={submit} disabled={state === "sending"}>
            {state === "sending"
              ? <><Loader2 className="spin" size={17} strokeWidth={2.4} />Envoi…</>
              : <><Send size={16} strokeWidth={2.2} />Envoyer la demande</>}
          </button>
        </div>
      </div>
    </div>
  );
}
