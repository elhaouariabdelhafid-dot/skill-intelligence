#!/usr/bin/env bash
set -euo pipefail
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Backend"
cd "$HOME/skill-intelligence"
cp api/sessions_api.py api/sessions_api.py.bak
python3 "$P/patch_delete.py"
python -c "from api.main import app; print('  imports OK')"

echo ""
echo "==> Frontend"
D="$HOME/skill-intelligence/frontend-web"
cd "$D"
cp src/App.jsx src/App.jsx.bak7
python3 "$P/patch_front.py"

echo ""
echo "============================================================"
echo " Relancez l'API   :  uvicorn api.main:app --port 8010"
echo " Relancez le front:  cd $D && npm run dev"
echo "============================================================"
