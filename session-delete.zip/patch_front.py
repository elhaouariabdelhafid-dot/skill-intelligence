"""Ajoute le bouton de suppression dans la carte de session."""
from pathlib import Path
import re, sys

APP, CSS = Path("src/App.jsx"), Path("src/styles.css")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "confirmDelete" in s:
    print("Deja en place."); sys.exit(0)

# ── 1. La carte recoit la fonction de suppression ──
s = s.replace(
    "function SessionCard({ s, expanded, onToggle, onAction, onPdf, busy, reload }) {\n"
    "  const { api, token } = useCtx();\n"
    "  const [live, setLive] = useState(s);",
    "function SessionCard({ s, expanded, onToggle, onAction, onPdf, busy, reload, onDelete }) {\n"
    "  const { api, token } = useCtx();\n"
    "  const [live, setLive] = useState(s);\n"
    "  const [confirmDelete, setConfirmDelete] = useState(false);")

# ── 2. Bouton dans la barre d'actions ──
old_btn = """            <button className="btn-act btn-act-primary" disabled={!live.answers || st === "évaluation en cours"}
              onClick={() => onAction(`/api/sessions/${live.id}/evaluate`, { method: "POST" }, "eval")}>
              <Brain size={14} strokeWidth={2.2} />Lancer les agents
            </button>
          </div>"""
new_btn = """            <button className="btn-act btn-act-primary" disabled={!live.answers || st === "évaluation en cours"}
              onClick={() => onAction(`/api/sessions/${live.id}/evaluate`, { method: "POST" }, "eval")}>
              <Brain size={14} strokeWidth={2.2} />Lancer les agents
            </button>
            <button className="btn-act btn-act-no sess-del" disabled={st === "évaluation en cours"}
              onClick={() => setConfirmDelete(true)}>
              <Trash2 size={14} strokeWidth={2.2} />Supprimer
            </button>
          </div>

          {confirmDelete && (
            <div className="notice notice-err pop">
              <AlertTriangle size={15} strokeWidth={2.4} />
              <div style={{ flex: 1 }}>
                <strong>Supprimer « {live.title} » ?</strong>
                <div style={{ marginTop: 3 }}>
                  Le sujet et les {live.answers} réponse(s) seront effacés.
                  {live.evaluated > 0 && ` Les ${live.evaluated} évaluation(s) déjà produites restent dans l'historique des collaborateurs.`}
                </div>
                <div className="review-btns" style={{ marginTop: 10, maxWidth: 280 }}>
                  <button className="btn-act btn-act-no" disabled={busy === `del-${live.id}`}
                    onClick={() => { onDelete(live.id); setConfirmDelete(false); }}>
                    {busy === `del-${live.id}` ? <Loader2 size={13} className="spin" strokeWidth={2.4} />
                      : <Trash2 size={13} strokeWidth={2.4} />}Confirmer
                  </button>
                  <button className="btn-act" onClick={() => setConfirmDelete(false)}>Annuler</button>
                </div>
              </div>
            </div>
          )}"""

if old_btn in s:
    s = s.replace(old_btn, new_btn)
    print("2. bouton et confirmation ajoutes")
else:
    print("2. ATTENTION : barre d'actions non trouvee")

# ── 3. Handler dans SessionsFormateur ──
s = s.replace(
    "  const downloadPdf = async (sid, title) => {",
    """  const removeSession = async (sid) => {
    setBusy(`del-${sid}`); setMsg(null);
    try {
      const r = await apiFetch(api, `/api/sessions/${sid}`, token, { method: "DELETE" });
      setMsg({ ok: true, t: r.evaluations_kept
        ? `Session supprimée. ${r.evaluations_kept} évaluation(s) conservée(s) dans l'historique.`
        : "Session supprimée." });
      setOpen(null); sessions.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy("");
  };

  const downloadPdf = async (sid, title) => {""")

# ── 4. Passer la fonction a la carte ──
s = s.replace(
    "onAction={act} onPdf={downloadPdf} busy={busy} reload={sessions.reload} />",
    "onAction={act} onPdf={downloadPdf} busy={busy} reload={sessions.reload}\n"
    "                onDelete={removeSession} />")
print("3. handler branche")

# ── 5. Icone ──
if "Trash2" not in s.split('from "lucide-react"')[0]:
    m = re.search(r'\n\} from "lucide-react";', s)
    s = s[:m.start()] + ",\n  Trash2" + s[m.start():]

APP.write_text(s, encoding="utf-8")

c = CSS.read_text(encoding="utf-8")
if ".sess-del" not in c:
    c += """
.sess-del{margin-left:auto}
@media (max-width:700px){ .sess-del{margin-left:0} }
"""
    CSS.write_text(c, encoding="utf-8")
    print("4. style ajoute")

print("\nTermine. Relancez : npm run dev")
