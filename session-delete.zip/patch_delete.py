"""Ajoute la suppression d'une session (formateur et administrateur)."""
from pathlib import Path
import sys

ROOT = Path.cwd()
if not (ROOT / "api").exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

p = ROOT / "api" / "sessions_api.py"
s = p.read_text(encoding="utf-8")

if "def delete_session" in s:
    print("Endpoint deja present."); sys.exit(0)

endpoint = '''

@router.delete("/{sid}")
def delete_session(sid: int, user: dict = Depends(require_role("formateur", "admin"))):
    """Supprime une session, son sujet et ses reponses.

    CE QUI EST CONSERVE : les evaluations deja produites restent dans
    l'historique du collaborateur et continuent d'alimenter son profil. Une
    session est un contenant ; supprimer le contenant n'efface pas la mesure.
    """
    db = get_sessions_db()
    sess = db.query(EvalSession).filter(EvalSession.id == sid).first()
    if sess is None:
        db.close(); raise HTTPException(404, "Session introuvable")
    if sess.status == "évaluation en cours":
        db.close(); raise HTTPException(400,
            "Une evaluation est en cours : attendez la fin avant de supprimer")

    n_answers = db.query(SessionAnswer).filter(SessionAnswer.session_id == sid).count()
    evaluated = db.query(SessionAnswer).filter(
        SessionAnswer.session_id == sid,
        SessionAnswer.submission_id.isnot(None)).count()

    db.query(SessionAnswer).filter(SessionAnswer.session_id == sid).delete()
    db.query(SessionQuestion).filter(SessionQuestion.session_id == sid).delete()
    db.delete(sess)
    db.commit()
    db.close()

    # Detacher la demande d'evaluation eventuellement liee
    try:
        from api.requests_models import EvalRequest, get_requests_db
        rdb = get_requests_db()
        for r in rdb.query(EvalRequest).filter(EvalRequest.session_id == sid).all():
            r.session_id = None
            r.status = "validée"      # redevient planifiable
        rdb.commit(); rdb.close()
    except Exception:
        pass

    return {"deleted": sid, "answers_removed": n_answers,
            "evaluations_kept": evaluated}
'''

s = s.rstrip() + endpoint
p.write_text(s, encoding="utf-8")
print("1. endpoint DELETE /api/sessions/{id} ajoute")
print("   les evaluations produites sont conservees")
