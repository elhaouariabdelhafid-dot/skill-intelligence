/* ═══════════════ CONFIGURATION — ADMINISTRATEUR ═══════════════ */
function Configuration() {
  const { api, token } = useCtx();
  const list = useApi("/api/admin/settings");
  const [draft, setDraft] = useState({});
  const [busy, setBusy] = useState(null);
  const [msg, setMsg] = useState(null);

  const save = async (key, value) => {
    setBusy(key); setMsg(null);
    try {
      const r = await apiFetch(api, "/api/admin/settings", token, {
        method: "PUT", body: JSON.stringify({ key, value: String(value) }),
      });
      setMsg(r.warning ? { ok: false, t: r.warning } : { ok: true, t: "Paramètre enregistré." });
      setDraft((d) => { const n = { ...d }; delete n[key]; return n; });
      list.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(null);
  };

  const resetAll = async () => {
    setBusy("reset");
    try {
      const r = await apiFetch(api, "/api/admin/settings/reset", token, { method: "POST" });
      setMsg({ ok: true, t: `${r.reset} paramètre(s) restauré(s) à leur valeur d'origine.` });
      setDraft({}); list.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(null);
  };

  if (list.loading) return <Loading label="Chargement des paramètres…" />;
  if (list.error) return <ErrorState message={list.error} onRetry={list.reload} />;

  const groups = {
    "Évaluation": ["skill_threshold", "retrieval_top_k"],
    "Pondération des agents": ["weight_grader", "weight_reasoner", "weight_critic", "veto_cap"],
    "Modèle de langage": ["llm_provider", "llm_model"],
  };
  const byKey = Object.fromEntries(list.data.map((p) => [p.key, p]));
  const weightSum = ["weight_grader", "weight_reasoner", "weight_critic"]
    .reduce((a, k) => a + parseFloat(draft[k] ?? byKey[k]?.value ?? 0), 0);
  const modified = list.data.filter((p) => p.modified).length;

  return (
    <>
      <div className="stat-row">
        <Stat label="Paramètres" value={list.data.length} />
        <Stat label="Modifiés" value={modified} tone={modified ? "#E8930C" : undefined} delay={.06} />
        <Stat label="Somme des pondérations" value={weightSum.toFixed(2)}
          sub="doit valoir 1.00" tone={Math.abs(weightSum - 1) > 0.01 ? "#E0455E" : "#0EA47C"} delay={.12} />
        <Stat label="Prise en compte" value="immédiate" sub="sans redémarrage" delay={.18} />
      </div>

      {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
        {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}
        <div>{msg.t}</div></div>}

      {Object.entries(groups).map(([title, keys], gi) => (
        <Panel key={title} title={title} delay={.24 + gi * 0.06}
          action={gi === 0 ? (
            <button className="btn-mini" onClick={resetAll} disabled={busy === "reset"}>
              <RefreshCw size={13} strokeWidth={2.4} />Valeurs d'origine
            </button>) : null}>
          <div className="cfg-list">
            {keys.filter((k) => byKey[k]).map((k) => {
              const p = byKey[k];
              const cur = draft[k] ?? p.value;
              const dirty = String(cur) !== String(p.value);
              return (
                <div key={k} className="cfg-row">
                  <div className="cfg-info">
                    <strong>{p.label}{p.modified && <span className="tag tag-warn">modifié</span>}</strong>
                    <span>{p.help}</span>
                    {p.updated_by && (
                      <span className="cfg-meta">
                        Dernière modification : {p.updated_by.split("@")[0]} · {p.updated_at}
                      </span>
                    )}
                  </div>
                  <div className="cfg-input">
                    {p.type === "select" ? (
                      <select value={cur} onChange={(e) => setDraft({ ...draft, [k]: e.target.value })}>
                        {p.options.map((o) => <option key={o} value={o}>{o}</option>)}
                      </select>
                    ) : p.type === "number" ? (
                      <input type="number" value={cur} min={p.min} max={p.max} step={p.step || 1}
                        onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} />
                    ) : (
                      <input value={cur} onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} />
                    )}
                    <button className={`btn-act${dirty ? " btn-act-primary" : ""}`}
                      disabled={!dirty || busy === k} onClick={() => save(k, cur)}>
                      {busy === k ? <Loader2 size={13} className="spin" strokeWidth={2.4} />
                        : <Check size={13} strokeWidth={2.4} />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>
      ))}
    </>
  );
}

/* ═══════════════ CORPUS ═══════════════ */
function Corpus() {
  const { data, error, loading, reload } = useApi("/api/admin/corpus");
  if (loading) return <Loading label="Interrogation de l'index…" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  return (
    <>
      <div className="stat-row">
        <Stat label="Vecteurs indexés" value={data.points?.toLocaleString("fr-FR") ?? "—"} />
        <Stat label="Dimensions" value={data.vector_size ?? "—"} delay={.06} />
        <Stat label="Fragments source" value={data.chunks_file?.toLocaleString("fr-FR") ?? "—"} delay={.12} />
        <Stat label="État" value={data.error ? "hors ligne" : (data.status || "actif")}
          tone={data.error ? "#E0455E" : "#0EA47C"} delay={.18} />
      </div>
      <Panel title="Index documentaire" note="source des évaluations" delay={.24}
        action={<button className="btn-mini" onClick={reload}><RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
        <div className="kv">
          <div><span>Collection</span><strong className="mono">{data.collection}</strong></div>
          <div><span>Modèle d'embedding</span><strong className="mono">{data.embedding}</strong></div>
          <div><span>Dimensions du vecteur</span><strong className="mono">{data.vector_size ?? "—"}</strong></div>
          <div><span>Points indexés</span><strong className="mono">{data.points?.toLocaleString("fr-FR") ?? "—"}</strong></div>
          {data.error && <div><span>Erreur</span><strong style={{ color: "#E0455E" }}>{data.error}</strong></div>}
        </div>
      </Panel>
      <Panel title="Réindexation" delay={.3}>
        <p className="panel-lead" style={{ marginBottom: 12 }}>
          Une réindexation complète est nécessaire après un changement de modèle
          d'embedding ou l'ajout de documents. L'opération se lance en ligne de
          commande, hors de l'application, car elle mobilise longuement la machine.
        </p>
        <pre className="raw">python ingestion/indexer.py --rebuild</pre>
      </Panel>
    </>
  );
}

/* ═══════════════ JOURNAL D'AUDIT ═══════════════ */
function Audit() {
  const { data, error, loading, reload } = useApi("/api/admin/audit?limit=60");
  if (loading) return <Loading />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  return (
    <Panel title="Journal d'administration" note={`${data.length} entrée(s)`} delay={0}
      action={<button className="btn-mini" onClick={reload}><RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
      <p className="panel-lead">
        Chaque modification de configuration est tracée : auteur, action, valeurs
        avant et après.
      </p>
      {!data.length ? <Empty>Aucune action enregistrée.</Empty> : (
        <table className="table">
          <thead><tr><th>Date</th><th>Auteur</th><th>Action</th><th>Détail</th></tr></thead>
          <tbody>
            {data.map((r) => (
              <tr key={r.id}>
                <td className="mono dim">{r.at}</td>
                <td>{r.actor?.split("@")[0]}</td>
                <td><span className="tag">{r.action}</span></td>
                <td className="mono dim">{r.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Panel>
  );
}
