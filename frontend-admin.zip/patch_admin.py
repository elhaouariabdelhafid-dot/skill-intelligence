"""Ajoute les vues d'administration et resserre le perimetre du role admin."""
from pathlib import Path
import sys, re

APP, CSS = Path("src/App.jsx"), Path("src/styles.css")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "function Configuration(" in s:
    print("Vues deja presentes."); sys.exit(0)

block = Path("admin_views.jsx").read_text(encoding="utf-8")

# 1) Icones
m = re.search(r'\n\} from "lucide-react";', s)
s = s[:m.start()] + ",\n  SlidersHorizontal, ScrollText, Library" + s[m.start():]
print("1. icones ajoutees")

# 2) Composants
anchor = "/* ═══════════════ ROUTES ═══════════════ */"
if anchor not in s:
    print("ERREUR : ancre ROUTES introuvable"); sys.exit(1)
s = s.replace(anchor, block + "\n" + anchor)
print("2. composants inseres")

# 3) Routes
s = s.replace(
    '  services:     { label: "Services",              icon: Database,      view: ServicesVue },',
    '  services:     { label: "Services",              icon: Database,      view: ServicesVue },\n'
    '  configuration:{ label: "Configuration",         icon: SlidersHorizontal, view: Configuration },\n'
    '  corpus:       { label: "Corpus documentaire",   icon: Library,       view: Corpus },\n'
    '  audit:        { label: "Journal d\'audit",       icon: ScrollText,    view: Audit },')
print("3. routes declarees")

# 4) Perimetre resserre : l'admin gere l'outil, pas les competences
old_nav = re.search(r'  admin:\s+\[[^\]]*\],', s)
if old_nav:
    s = s[:old_nav.start()] + \
        '  admin:         ["comptes", "configuration", "corpus", "services", "audit"],' + \
        s[old_nav.end():]
    print("4. perimetre admin resserre (metier retire)")

APP.write_text(s, encoding="utf-8")

c = CSS.read_text(encoding="utf-8")
if ".cfg-row" not in c:
    CSS.write_text(c + Path("admin.css").read_text(encoding="utf-8"), encoding="utf-8")
    print("5. styles ajoutes")

print("\nTermine. Relancez : npm run dev")
