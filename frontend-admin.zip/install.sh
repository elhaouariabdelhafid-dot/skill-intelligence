#!/usr/bin/env bash
set -euo pipefail
D="$HOME/skill-intelligence/frontend-web"
[ -d "$D" ] || { echo "Dossier $D introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$D"
cp src/App.jsx src/App.jsx.bak4
cp src/styles.css src/styles.css.bak4
echo "Sauvegardes : .bak4"
cp "$P/admin_views.jsx" "$P/admin.css" .
python3 "$P/patch_admin.py"
rm -f admin_views.jsx admin.css
echo ""
echo "Relancez :  cd $D && npm run dev"
