#!/usr/bin/env bash
set -euo pipefail
D="$HOME/skill-intelligence/frontend-web"
[ -d "$D" ] || { echo "Dossier $D introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$D"
cp "$P/views_block.jsx" .
cp "$P/extra.css" .
python3 "$P/patch_frontend.py" views_block.jsx
rm -f views_block.jsx extra.css
echo ""
echo "Relancez le frontend :  cd $D && npm run dev"
