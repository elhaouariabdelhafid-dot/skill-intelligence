"""Ajoute les vues Sessions (formateur) et Examens (collaborateur) au frontend."""
from pathlib import Path
import sys, re

APP = Path("src/App.jsx")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
block = Path(sys.argv[1] if len(sys.argv) > 1 else "views_block.jsx").read_text(encoding="utf-8")

if "SessionsFormateur" in s:
    print("Les vues sont déjà présentes — rien à faire."); sys.exit(0)

# 1) Icônes supplémentaires
old_icons = "  RefreshCw, WifiOff, Settings,\n} from \"lucide-react\";"
new_icons = ("  RefreshCw, WifiOff, Settings, Plus, FileDown, Send, ChevronLeft,\n"
             "  ChevronRight, Award, Wand2, CalendarClock,\n} from \"lucide-react\";")
if old_icons in s:
    s = s.replace(old_icons, new_icons); print("1. icônes ajoutées")
else:
    m = re.search(r'(\n\} from "lucide-react";)', s)
    s = s[:m.start()] + ",\n  Plus, FileDown, Send, ChevronLeft, ChevronRight, Award, Wand2" + s[m.start():]
    print("1. icônes ajoutées (repli)")

# 2) Insérer les composants avant la table des routes
anchor = "/* ═══════════════ ROUTES ═══════════════ */"
if anchor not in s:
    print("ERREUR : ancre ROUTES introuvable"); sys.exit(1)
s = s.replace(anchor, block + "\n" + anchor)
print("2. composants insérés")

# 3) Déclarer les routes
s = s.replace(
    '  ragas:        { label: "Qualité du RAG",        icon: GaugeIcon,     view: QualiteRAG },',
    '  ragas:        { label: "Qualité du RAG",        icon: GaugeIcon,     view: QualiteRAG },\n'
    '  evalsessions: { label: "Sessions d\'évaluation", icon: CalendarClock, view: SessionsFormateur },\n'
    '  mesexamens:   { label: "Mes examens",           icon: Award,         view: MesExamens },')
print("3. routes déclarées")

# 4) Navigation par rôle
s = s.replace('collaborateur: ["profil", "parcours", "mesevals"],',
              'collaborateur: ["profil", "mesexamens", "parcours", "mesevals"],')
s = s.replace('formateur:     ["questions", "lancer", "resultats"],',
              'formateur:     ["evalsessions", "questions", "resultats"],')
s = s.replace('admin:         ["comptes", "services", "ragas", "cartographie", "ontologie"],',
              'admin:         ["comptes", "evalsessions", "services", "ragas", "cartographie", "ontologie"],')
print("4. navigation mise à jour")

APP.write_text(s, encoding="utf-8")

# 5) Styles
css = Path("src/styles.css")
extra = Path("extra.css").read_text(encoding="utf-8")
c = css.read_text(encoding="utf-8")
if "sess-card" not in c:
    css.write_text(c + "\n\n/* ===== sessions & examens ===== */\n" + extra, encoding="utf-8")
    print("5. styles ajoutés")
else:
    print("5. styles déjà présents")

print("\nTerminé. Relancez : npm run dev")
