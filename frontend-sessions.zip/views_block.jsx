/* ═══════════════ SESSIONS — FORMATEUR ═══════════════ */
function SessionsFormateur() {
  const { api, token } = useCtx();
  const sessions = useApi("/api/sessions");
  const people = useApi("/api/people");
  const questions = useApi("/api/questions");
  const [open, setOpen] = useState(null);
  const [form, setForm] = useState({ title: "", services: [], participants: [] });
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState(null);

  const services = useMemo(
    () => [...new Set((questions.data || []).map((q) => q.service))].filter(Boolean),
    [questions.data]);

  const act = async (path, opts, label) => {
    setBusy(label); setMsg(null);
    try {
      const r = await apiFetch(api, path, token, opts);
      setMsg({ ok: true, t: r.note || r.message || "Opération effectuée." });
      sessions.reload();
      return r;
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    finally { setBusy(""); }
  };

  const create = async () => {
    if (!form.title.trim()) { setMsg({ ok: false, t: "Donnez un titre à la session." }); return; }
    if (!form.participants.length) { setMsg({ ok: false, t: "Choisissez au moins un participant." }); return; }
    const r = await act("/api/sessions", { method: "POST", body: JSON.stringify(form) }, "create");
    if (r) { setForm({ title: "", services: [], participants: [] }); setOpen(r.id); }
  };

  const downloadPdf = async (sid, title) => {
    setBusy(`pdf-${sid}`);
    try {
      const res = await fetch(`${api}/api/sessions/${sid}/pdf`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error(`${res.status}`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `sujet_${title.replace(/\s+/g, "_")}.pdf`;
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
      setMsg({ ok: true, t: "Sujet téléchargé." });
    } catch (e) { setMsg({ ok: false, t: `Export impossible : ${e.message}` }); }
    finally { setBusy(""); }
  };

  const toggle = (key, v) => setForm((f) => ({
    ...f, [key]: f[key].includes(v) ? f[key].filter((x) => x !== v) : [...f[key], v],
  }));

  return (
    <>
      <div className="stat-row">
        <Stat label="Sessions créées" value={sessions.data?.length ?? "…"} />
        <Stat label="Ouvertes" value={sessions.data?.filter((s) => s.status === "ouverte").length ?? "…"} delay={.06} />
        <Stat label="Terminées" value={sessions.data?.filter((s) => s.status === "terminée").length ?? "…"} tone="#0EA47C" delay={.12} />
        <Stat label="Réponses évaluées" value={sessions.data?.reduce((a, s) => a + (s.evaluated || 0), 0) ?? "…"} delay={.18} />
      </div>

      <Panel title="Créer une session d'évaluation" note="choisissez les services et les participants" delay={.24}>
        <div className="launch">
          <label className="field field-inline" style={{ minWidth: 260 }}>
            <span className="field-label">Intitulé</span>
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Examen Cloud AWS — juillet" />
          </label>
          <button className="btn-signin btn-inline" onClick={create} disabled={busy === "create"}>
            {busy === "create" ? <><Loader2 size={15} className="spin" strokeWidth={2.4} />Création…</>
              : <><Plus size={15} strokeWidth={2.4} />Créer la session</>}
          </button>
        </div>

        <div className="pick-block">
          <span className="pick-label">Services couverts <em>(aucun = tous)</em></span>
          <div className="chip-row">
            {services.map((s) => (
              <button key={s} className={`chip chip-sm${form.services.includes(s) ? " chip-on" : ""}`}
                onClick={() => toggle("services", s)}>{short(s)}</button>
            ))}
          </div>
        </div>

        <div className="pick-block">
          <span className="pick-label">Participants</span>
          <div className="chip-row">
            {(people.data || []).map((p) => (
              <button key={p.user_id} className={`chip chip-sm${form.participants.includes(p.user_id) ? " chip-on" : ""}`}
                onClick={() => toggle("participants", p.user_id)}>{p.name}</button>
            ))}
          </div>
        </div>

        {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
          {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}<div>{msg.t}</div></div>}
      </Panel>

      <Panel title="Sessions" note="cliquez pour déplier" delay={.3}
        action={<button className="btn-mini" onClick={sessions.reload}><RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
        {sessions.loading ? <Loading /> : sessions.error ? <ErrorState message={sessions.error} onRetry={sessions.reload} />
          : !sessions.data.length ? <Empty>Aucune session pour l'instant.</Empty> : (
          <div className="sess-list">
            {sessions.data.map((s) => (
              <SessionCard key={s.id} s={s} expanded={open === s.id}
                onToggle={() => setOpen(open === s.id ? null : s.id)}
                onAction={act} onPdf={downloadPdf} busy={busy} reload={sessions.reload} />
            ))}
          </div>
        )}
      </Panel>
    </>
  );
}

function SessionCard({ s, expanded, onToggle, onAction, onPdf, busy, reload }) {
  const { api, token } = useCtx();
  const [live, setLive] = useState(s);

  // Suivi de la progression pendant l'évaluation
  useEffect(() => {
    setLive(s);
    if (s.status !== "évaluation en cours") return;
    const t = setInterval(async () => {
      try {
        const st = await apiFetch(api, `/api/sessions/${s.id}/status`, token);
        setLive((p) => ({ ...p, ...st }));
        if (st.status === "terminée") { clearInterval(t); reload(); }
      } catch { /* on réessaiera au tick suivant */ }
    }, 4000);
    return () => clearInterval(t);
  }, [s, api, token, reload]);

  const st = live.status;
  const pct = live.progress_total ? (live.progress_done / live.progress_total) * 100 : 0;

  return (
    <div className={`sess-card${expanded ? " open" : ""}`}>
      <button className="sess-head" onClick={onToggle} aria-expanded={expanded}>
        <div className="sess-title">
          <strong>{live.title}</strong>
          <span className="dim">#{live.id} · {live.created_at}</span>
        </div>
        <div className="sess-meta">
          <span className="tag">{live.questions} questions</span>
          <span className="tag">{live.participants.length} participant(s)</span>
          <span className={`tag status-${st.replace(/\s/g, "-")}`}>{st}</span>
        </div>
      </button>

      {st === "évaluation en cours" && (
        <div className="sess-progress">
          <div className="prog-rail"><div className="prog-fill" style={{ width: `${pct}%` }} /></div>
          <span className="mono">{live.message}</span>
        </div>
      )}

      {expanded && (
        <div className="sess-body">
          <div className="sess-actions">
            <button className="btn-act" disabled={busy === "gen"}
              onClick={() => onAction(`/api/sessions/${live.id}/generate`, { method: "POST" }, "gen")}>
              <Wand2 size={14} strokeWidth={2.2} />Générer le sujet
            </button>
            <button className="btn-act" disabled={!live.questions || busy === `pdf-${live.id}`}
              onClick={() => onPdf(live.id, live.title)}>
              <FileDown size={14} strokeWidth={2.2} />Exporter en PDF
            </button>
            <button className="btn-act" disabled={!live.questions || st === "ouverte"}
              onClick={() => onAction(`/api/sessions/${live.id}/open`, { method: "POST" }, "open")}>
              <Play size={14} strokeWidth={2.2} />Ouvrir aux participants
            </button>
            <button className="btn-act btn-act-primary" disabled={!live.answers || st === "évaluation en cours"}
              onClick={() => onAction(`/api/sessions/${live.id}/evaluate`, { method: "POST" }, "eval")}>
              <Brain size={14} strokeWidth={2.2} />Lancer les agents
            </button>
          </div>

          <div className="sess-stats">
            <span>Réponses reçues <strong>{live.answers}</strong></span>
            <span>Évaluées <strong>{live.evaluated}</strong></span>
            <span>Services <strong>{live.services?.length ? live.services.join(", ") : "tous"}</strong></span>
          </div>

          <SessionResults sid={live.id} status={st} />
        </div>
      )}
    </div>
  );
}

function SessionResults({ sid, status }) {
  const { data, error, loading, reload } = useApi(`/api/sessions/${sid}/results`, [status]);
  if (loading) return <Loading label="Chargement des réponses…" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  if (!data.length) return <Empty>Aucune réponse reçue pour l'instant.</Empty>;
  return (
    <table className="table sess-table">
      <thead><tr><th>Participant</th><th>Question</th><th>Service</th>
        <th>Exact.</th><th>Rais.</th><th>Vérif.</th><th>Score</th></tr></thead>
      <tbody>
        {data.map((r, i) => (
          <tr key={i}>
            <td><strong>{r.person}</strong></td>
            <td className="q-text">{r.question?.slice(0, 90)}{r.question?.length > 90 ? "…" : ""}</td>
            <td>{short(r.service)}</td>
            {r.evaluated ? (
              <>
                <td className="mono">{r.grader?.toFixed(1)}</td>
                <td className="mono">{r.reasoner?.toFixed(1)}</td>
                <td className="mono">{r.critic?.toFixed(1)}</td>
                <td className="mono strong" style={{ color: r.final >= 3 ? "#0EA47C" : r.final >= 2 ? "#4F46E5" : "#E0455E" }}>
                  {r.final?.toFixed(2)}/4</td>
              </>
            ) : <td colSpan={4} className="dim">en attente d'évaluation</td>}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/* ═══════════════ EXAMENS — COLLABORATEUR ═══════════════ */
function MesExamens() {
  const { api, token } = useCtx();
  const sessions = useApi("/api/sessions/me/open");
  const [active, setActive] = useState(null);

  if (sessions.loading) return <Loading label="Chargement de vos examens…" />;
  if (sessions.error) return <ErrorState message={sessions.error} onRetry={sessions.reload} />;
  if (!sessions.data.length) return <Empty>Aucun examen ne vous est assigné pour l'instant.</Empty>;

  if (active) {
    const s = sessions.data.find((x) => x.id === active);
    return <ExamRunner session={s} onBack={() => { setActive(null); sessions.reload(); }} />;
  }

  return (
    <Panel title="Mes examens" note={`${sessions.data.length} session(s)`} delay={0}>
      <div className="sess-list">
        {sessions.data.map((s, i) => {
          const done = s.answered >= s.questions && s.questions > 0;
          return (
            <div key={s.id} className="exam-card rise" style={{ animationDelay: `${0.06 * i}s` }}>
              <div className="exam-info">
                <strong>{s.title}</strong>
                <span className="dim">{s.services?.length ? s.services.join(" · ") : "tous services"} · {s.questions} questions</span>
                <div className="exam-prog">
                  <div className="prog-rail"><div className="prog-fill"
                    style={{ width: `${s.questions ? (s.answered / s.questions) * 100 : 0}%` }} /></div>
                  <span className="mono">{s.answered}/{s.questions}</span>
                </div>
              </div>
              <div className="exam-side">
                <span className={`tag status-${s.status.replace(/\s/g, "-")}`}>{s.status}</span>
                <button className="btn-signin btn-inline" onClick={() => setActive(s.id)}>
                  {s.status === "terminée" ? <><Award size={15} strokeWidth={2.2} />Voir mes résultats</>
                    : done ? <><Check size={15} strokeWidth={2.4} />Relire mes réponses</>
                    : <><Play size={15} strokeWidth={2.4} />{s.answered ? "Continuer" : "Commencer"}</>}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

function ExamRunner({ session, onBack }) {
  const { api, token } = useCtx();
  const qs = useApi(`/api/sessions/me/${session.id}/questions`);
  const results = useApi(session.status === "terminée" ? `/api/sessions/me/${session.id}/results` : null);
  const [idx, setIdx] = useState(0);
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [err, setErr] = useState("");
  const [all, setAll] = useState(false);

  useEffect(() => {
    if (qs.data?.[idx]) { setDraft(qs.data[idx].answer_text || ""); setSaved(false); setErr(""); }
  }, [qs.data, idx]);

  if (qs.loading) return <Loading label="Chargement du sujet…" />;
  if (qs.error) return <ErrorState message={qs.error} onRetry={qs.reload} />;
  if (!qs.data.length) return <Empty>Ce sujet ne contient aucune question.</Empty>;

  const q = qs.data[idx];
  const answeredCount = qs.data.filter((x) => x.answered).length;
  const locked = session.status !== "ouverte";

  const save = async () => {
    if (!draft.trim()) { setErr("Écrivez une réponse avant d'enregistrer."); return; }
    setSaving(true); setErr("");
    try {
      await apiFetch(api, "/api/sessions/me/answer", token, {
        method: "POST",
        body: JSON.stringify({ session_id: session.id, question_id: q.question_id, answer_text: draft }),
      });
      setSaved(true); qs.reload();
      setTimeout(() => { if (idx < qs.data.length - 1) setIdx(idx + 1); }, 600);
    } catch (e) { setErr(e.message); }
    setSaving(false);
  };

  // Vue résultats après évaluation
  if (session.status === "terminée") {
    return (
      <>
        <button className="btn-mini back" onClick={onBack}><ChevronLeft size={13} strokeWidth={2.4} />Retour</button>
        <Panel title={session.title} note="résultats de la session" delay={0}>
          {results.loading ? <Loading /> : !results.data?.length ? <Empty>Aucun résultat.</Empty> : (
            <div className="res-cards">
              {results.data.map((r, i) => (
                <div key={i} className="res-card rise" style={{ animationDelay: `${0.05 * i}s` }}>
                  <div className="res-q"><span className="tag">{short(r.service)}</span><p>{r.question}</p></div>
                  <div className="res-answer">{r.answer}</div>
                  {r.evaluated ? (
                    <div className="res-scores">
                      <div><span>Exactitude</span><strong className="mono">{r.grader?.toFixed(1)}/4</strong></div>
                      <div><span>Raisonnement</span><strong className="mono">{r.reasoner?.toFixed(1)}/4</strong></div>
                      <div><span>Vérification</span><strong className="mono">{r.critic?.toFixed(1)}/4</strong></div>
                      <div className="res-final" style={{ color: r.final >= 3 ? "#0EA47C" : r.final >= 2 ? "#4F46E5" : "#E0455E" }}>
                        <span>Score</span><strong className="mono">{r.final?.toFixed(2)}/4</strong></div>
                    </div>
                  ) : <div className="dim">En attente d'évaluation</div>}
                  {r.feedback && <p className="res-feedback">{r.feedback}</p>}
                </div>
              ))}
            </div>
          )}
        </Panel>
      </>
    );
  }

  return (
    <>
      <div className="exam-topbar">
        <button className="btn-mini" onClick={onBack}><ChevronLeft size={13} strokeWidth={2.4} />Retour</button>
        <div className="exam-track">
          <div className="prog-rail"><div className="prog-fill"
            style={{ width: `${(answeredCount / qs.data.length) * 100}%` }} /></div>
          <span className="mono">{answeredCount}/{qs.data.length} répondues</span>
        </div>
        <button className="btn-mini" onClick={() => setAll(!all)}>
          <ListChecks size={13} strokeWidth={2.4} />{all ? "Une à la fois" : "Tout afficher"}
        </button>
      </div>

      {all ? (
        <Panel title={session.title} note={`${qs.data.length} questions`} delay={0}>
          <div className="all-list">
            {qs.data.map((x, i) => (
              <button key={x.question_id} className={`all-item${x.answered ? " ok" : ""}${i === idx ? " cur" : ""}`}
                onClick={() => { setIdx(i); setAll(false); }}>
                <span className="all-num">{i + 1}</span>
                <span className="all-text">{x.text.slice(0, 110)}{x.text.length > 110 ? "…" : ""}</span>
                <span className="tag">{short(x.service)}</span>
                {x.answered && <Check size={14} strokeWidth={2.6} className="all-check" />}
              </button>
            ))}
          </div>
        </Panel>
      ) : (
        <Panel title={session.title} note={`Question ${idx + 1} sur ${qs.data.length}`} delay={0}>
          <div className="q-block">
            <div className="q-tags">
              <span className="tag">{short(q.service)}</span>
              <span className={`tag tag-${q.difficulty}`}>{q.difficulty}</span>
              {q.answered && <span className="tag tag-ok">déjà répondue</span>}
            </div>
            <p className="q-statement">{q.text}</p>
          </div>

          <textarea className="answer-area" value={draft} disabled={locked || q.evaluated}
            onChange={(e) => { setDraft(e.target.value); setSaved(false); }}
            placeholder="Rédigez votre réponse. Vous pouvez répondre en français ou en anglais — le système traite les deux langues." />

          <div className="answer-foot">
            <span className="dim">{draft.trim().split(/\s+/).filter(Boolean).length} mots</span>
            {err && <span className="err-inline"><AlertTriangle size={13} strokeWidth={2.4} />{err}</span>}
            {saved && <span className="ok-inline"><Check size={13} strokeWidth={2.6} />Réponse enregistrée</span>}
          </div>

          <div className="exam-nav">
            <button className="btn-act" disabled={idx === 0} onClick={() => setIdx(idx - 1)}>
              <ChevronLeft size={14} strokeWidth={2.2} />Précédent</button>
            <button className="btn-signin btn-inline" onClick={save} disabled={saving || locked || q.evaluated}>
              {saving ? <><Loader2 size={15} className="spin" strokeWidth={2.4} />Enregistrement…</>
                : <><Send size={15} strokeWidth={2.2} />Enregistrer</>}
            </button>
            <button className="btn-act" disabled={idx >= qs.data.length - 1} onClick={() => setIdx(idx + 1)}>
              Suivant<ChevronRight size={14} strokeWidth={2.2} /></button>
          </div>
        </Panel>
      )}
    </>
  );
}
