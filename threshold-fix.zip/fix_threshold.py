"""Fait lire le seuil configure par le module de recommandations.

LE SYMPTOME : le seuil de maitrise est modifiable depuis la page Configuration,
mais skills/recommendations.py conserve une constante GAP_THRESHOLD = 60.0.
Avec un seuil configure a 55 %, le graphe de competences considere VPC (58 %)
comme acquis tandis que le parcours de formation le liste encore comme lacune.
Deux ecrans, deux verites.

LA CORRECTION : la constante devient une valeur de repli ; le seuil effectif
est lu en base a chaque appel. Aucun autre comportement ne change.
"""
from pathlib import Path
import re
import sys

p = Path("skills/recommendations.py")
if not p.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

s = p.read_text(encoding="utf-8")
if "_gap_threshold" in s:
    print("Deja corrige."); sys.exit(0)

# 1) La constante devient un repli, avec une fonction de lecture
old = "GAP_THRESHOLD = 60.0        # sous 60%, la compétence est un besoin de formation"
new = '''# Valeur de repli. Le seuil effectif est configure par l'administrateur et lu
# en base : les deux vues du systeme (graphe et parcours) doivent s'accorder.
GAP_THRESHOLD = 60.0


def _gap_threshold() -> float:
    """Seuil de maitrise courant, ou valeur de repli si la table est absente."""
    try:
        from api.settings_models import get_float
        return get_float("skill_threshold")
    except Exception:
        return GAP_THRESHOLD'''

if old in s:
    s = s.replace(old, new)
    print("1. fonction de lecture ajoutee")
else:
    m = re.search(r'^GAP_THRESHOLD\s*=\s*[\d.]+.*$', s, re.M)
    if m:
        s = s[:m.start()] + new + s[m.end():]
        print("1. fonction de lecture ajoutee (motif souple)")
    else:
        print("1. ERREUR : GAP_THRESHOLD introuvable"); sys.exit(1)

# 2) Tous les usages passent par la fonction
body_start = s.index("def _gap_threshold")
body_end = s.index("\n", s.index("return GAP_THRESHOLD", body_start))
head, body = s[:body_end], s[body_end:]
body, n = re.subn(r'\bGAP_THRESHOLD\b', '_gap_threshold()', body)
s = head + body
print(f"2. {n} usage(s) redirige(s) vers le seuil configure")

p.write_text(s, encoding="utf-8")
import ast; ast.parse(s)
print("\nskills/recommendations.py corrige et valide.")
