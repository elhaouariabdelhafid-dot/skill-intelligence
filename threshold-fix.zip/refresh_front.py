"""Le frontend relit le seuil apres chaque changement de vue.

Sans cela, une modification du seuil dans la page Configuration n'apparait
qu'apres rechargement complet de la page.
"""
from pathlib import Path
import sys

p = Path("src/App.jsx")
if not p.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = p.read_text(encoding="utf-8")
if "seuil relu" in s:
    print("Deja corrige."); sys.exit(0)

old = '''function useThreshold(api) {
  const [threshold, setThreshold] = useState(THRESHOLD);
  useEffect(() => {
    let alive = true;
    fetch(`${api}/api/config/public`)'''
new = '''function useThreshold(api, tick = 0) {
  const [threshold, setThreshold] = useState(THRESHOLD);
  useEffect(() => {
    // seuil relu a chaque changement de vue : une modification faite dans la
    // page Configuration devient visible sans rechargement complet
    let alive = true;
    fetch(`${api}/api/config/public`)'''

if old in s:
    s = s.replace(old, new)
    s = s.replace("  }, [api]);\n  return threshold;\n}",
                  "  }, [api, tick]);\n  return threshold;\n}")
    print("1. hook rendu reactif")
else:
    print("1. ATTENTION : hook useThreshold non trouve")

# L'App relit a chaque changement d'etape
s = s.replace("  const threshold = useThreshold(api);",
              "  const [cfgTick, setCfgTick] = useState(0);\n"
              "  const threshold = useThreshold(api, cfgTick);")
s = s.replace('value={{ dark, token: session?.token, api, threshold }}',
              'value={{ dark, token: session?.token, api, threshold,\n'
              '                       refreshConfig: () => setCfgTick((t) => t + 1) }}')
print("2. rafraichissement branche")

# Apres modification d'un parametre, on relit
s = s.replace(
    '      setMsg(r.warning ? { ok: false, t: r.warning } : { ok: true, t: "Paramètre enregistré." });\n'
    '      setDraft((d) => { const n = { ...d }; delete n[key]; return n; });\n'
    '      list.reload();',
    '      setMsg(r.warning ? { ok: false, t: r.warning } : { ok: true, t: "Paramètre enregistré." });\n'
    '      setDraft((d) => { const n = { ...d }; delete n[key]; return n; });\n'
    '      list.reload();\n'
    '      if (key === "skill_threshold" && ctx.refreshConfig) ctx.refreshConfig();')
s = s.replace("function Configuration() {\n  const { api, token } = useCtx();",
              "function Configuration() {\n  const ctx = useCtx();\n  const { api, token } = ctx;")
print("3. la page Configuration declenche la relecture")

p.write_text(s, encoding="utf-8")
print("\nTermine. Relancez : npm run dev")
