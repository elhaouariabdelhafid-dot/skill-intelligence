#!/usr/bin/env bash
set -euo pipefail
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Backend"
cd "$HOME/skill-intelligence"
mkdir -p archive/before_fix
cp skills/recommendations.py archive/before_fix/recommendations_before_threshold.py
python3 "$P/fix_threshold.py"
python -c "from skills.recommendations import _gap_threshold; print(f'  seuil lu : {_gap_threshold()} %')"

echo ""
echo "==> Frontend"
cd "$HOME/skill-intelligence/frontend-web"
cp src/App.jsx src/App.jsx.bak9
python3 "$P/refresh_front.py"

echo ""
echo "============================================================"
echo " Relancez l'API   :  uvicorn api.main:app --port 8010"
echo " Relancez le front:  cd frontend-web && npm run dev"
echo "============================================================"
