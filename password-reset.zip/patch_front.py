"""Rend le bouton « Mot de passe oublié » fonctionnel et ajoute l'ecran admin."""
from pathlib import Path
import re, sys

APP = Path("src/App.jsx")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "MotsDePasse" in s:
    print("Deja en place."); sys.exit(0)

# ── 1. Etat du formulaire dans Login ──
s = s.replace(
    "  const [cfg, setCfg] = useState(false);\n  const [hint, setHint] = useState(false);",
    "  const [cfg, setCfg] = useState(false);\n  const [hint, setHint] = useState(false);\n"
    "  const [forgot, setForgot] = useState(false);\n"
    "  const [forgotMail, setForgotMail] = useState(\"\");\n"
    "  const [forgotState, setForgotState] = useState(\"idle\");\n\n"
    "  const askReset = async () => {\n"
    "    if (!forgotMail.trim()) return;\n"
    "    setForgotState(\"sending\");\n"
    "    try {\n"
    "      await fetch(`${api}/api/reset/request`, {\n"
    "        method: \"POST\", headers: { \"Content-Type\": \"application/json\" },\n"
    "        body: JSON.stringify({ email: forgotMail.trim().toLowerCase() }),\n"
    "      });\n"
    "      setForgotState(\"sent\");\n"
    "    } catch { setForgotState(\"sent\"); }   // reponse neutre dans tous les cas\n"
    "  };")
print("1. etat du formulaire ajoute")

# ── 2. Le bouton ouvre le formulaire ──
s = s.replace(
    '<button type="button" className="auth-link">Mot de passe oublié ?</button>',
    '<button type="button" className="auth-link"\n'
    '                onClick={() => { setForgot(!forgot); setForgotState("idle");\n'
    '                                 setForgotMail(email); }}>\n'
    '                Mot de passe oublié ?</button>')
print("2. bouton branche")

# ── 3. Le formulaire s'insere sous la ligne ──
s = s.replace(
    '            <div className="auth-slot" aria-live="polite">',
    '''            {forgot && (
              <div className="forgot-box pop">
                {forgotState === "sent" ? (
                  <div className="forgot-done">
                    <Check size={15} strokeWidth={2.6} />
                    <span>Si un compte existe pour cette adresse, l'administrateur
                      traitera votre demande et vous transmettra un mot de passe
                      provisoire.</span>
                  </div>
                ) : (
                  <>
                    <span className="forgot-label">
                      Saisissez votre adresse : l'administrateur réinitialisera
                      votre mot de passe.
                    </span>
                    <div className="forgot-row">
                      <input value={forgotMail} placeholder="prenom@cmh.ma"
                        onChange={(e) => setForgotMail(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && askReset()} />
                      <button className="btn-act btn-act-primary"
                        disabled={forgotState === "sending"} onClick={askReset}>
                        {forgotState === "sending"
                          ? <Loader2 size={14} className="spin" strokeWidth={2.4} />
                          : <Send size={14} strokeWidth={2.2} />}Envoyer
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}

            <div className="auth-slot" aria-live="polite">''')
print("3. formulaire insere")

# ── 4. Vue admin ──
block = Path("reset_views.jsx").read_text(encoding="utf-8")
anchor = "/* ═══════════════ ROUTES ═══════════════ */"
s = s.replace(anchor, block + "\n" + anchor)

s = s.replace(
    '  acces:        { label: "Demandes d\'accès",      icon: UserPlus,      view: DemandesAcces },',
    '  acces:        { label: "Demandes d\'accès",      icon: UserPlus,      view: DemandesAcces },\n'
    '  motsdepasse:  { label: "Mots de passe",         icon: KeyRound,      view: MotsDePasse },')
s = re.sub(r'  admin:\s+\[([^\]]*)\],',
           lambda m: '  admin:         ["acces", "motsdepasse",'
                     + m.group(1).replace('"acces",', '', 1).strip().lstrip(',') + '],',
           s)
print("4. vue admin et route ajoutees")

# ── 5. Icone ──
if "KeyRound" not in s.split('from "lucide-react"')[0]:
    m = re.search(r'\n\} from "lucide-react";', s)
    s = s[:m.start()] + ",\n  KeyRound" + s[m.start():]

APP.write_text(s, encoding="utf-8")

css = Path("src/styles.css")
c = css.read_text(encoding="utf-8")
if ".forgot-box" not in c:
    c += """
/* ===== mot de passe oublie ===== */
.forgot-box{padding:13px 15px;border-radius:14px;background:var(--panel);
  border:1px solid var(--line)}
.forgot-label{display:block;font-size:12px;color:var(--muted);line-height:1.55;
  margin-bottom:10px}
.forgot-row{display:flex;gap:8px}
.forgot-row input{flex:1;min-width:0;padding:10px 12px;border:1px solid var(--line-2);
  border-radius:11px;font-size:13.5px;font-family:inherit;background:var(--bg);color:var(--ink)}
.forgot-row input:focus{outline:none;border-color:#8B5CF6;
  box-shadow:0 0 0 3px rgba(139,92,246,.13)}
.forgot-row .btn-act{white-space:nowrap}
.forgot-done{display:flex;align-items:flex-start;gap:9px;font-size:12.5px;
  line-height:1.6;color:var(--ok)}
"""
    css.write_text(c, encoding="utf-8")
    print("5. styles ajoutes")

print("\nTermine. Relancez : npm run dev")
