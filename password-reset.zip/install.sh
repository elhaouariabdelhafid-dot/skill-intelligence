#!/usr/bin/env bash
set -euo pipefail
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Backend"
cd "$HOME/skill-intelligence"
cp "$P/reset_api.py" api/reset_api.py
python - << 'PYEOF'
from pathlib import Path
p = Path("api/main.py"); s = p.read_text()
if "reset_api" not in s:
    s = s.rstrip() + "\n\nfrom api.reset_api import router as reset_router\napp.include_router(reset_router)\n"
    p.write_text(s); print("  routeur ajoute")
else:
    print("  routeur deja present")
PYEOF
python -c "from api.reset_api import get_reset_db; get_reset_db().close(); print('  table password_resets prete')"
python -c "from api.main import app; print('  imports OK')"

echo ""
echo "==> Frontend"
D="$HOME/skill-intelligence/frontend-web"
cd "$D"
cp src/App.jsx src/App.jsx.bak10
cp src/styles.css src/styles.css.bak10
cp "$P/reset_views.jsx" .
python3 "$P/patch_front.py"
rm -f reset_views.jsx

echo ""
echo "============================================================"
echo " Relancez l'API   :  uvicorn api.main:app --port 8010"
echo " Relancez le front:  cd $D && npm run dev"
echo "============================================================"
