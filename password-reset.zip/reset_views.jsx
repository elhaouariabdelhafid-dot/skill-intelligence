/* ═══════════════ MOTS DE PASSE — ADMINISTRATEUR ═══════════════ */
function MotsDePasse() {
  const { api, token } = useCtx();
  const list = useApi("/api/reset/requests");
  const accounts = useApi("/api/users");
  const [filter, setFilter] = useState("en_attente");
  const [busy, setBusy] = useState(null);
  const [issued, setIssued] = useState(null);
  const [msg, setMsg] = useState(null);

  const act = async (path, label) => {
    setBusy(label); setMsg(null); setIssued(null);
    try {
      const r = await apiFetch(api, path, token, { method: "POST" });
      if (r.temp_password) {
        setIssued({ email: r.email, password: r.temp_password });
      } else {
        setMsg({ ok: true, t: r.note || "Demande traitée." });
      }
      list.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(null);
  };

  if (list.loading) return <Loading label="Chargement des demandes…" />;
  if (list.error) return <ErrorState message={list.error} onRetry={list.reload} />;

  const counts = list.data.reduce((a, r) => ({ ...a, [r.status]: (a[r.status] || 0) + 1 }), {});
  const rows = filter === "toutes" ? list.data : list.data.filter((r) => r.status === filter);

  return (
    <>
      <div className="stat-row">
        <Stat label="Demandes reçues" value={list.data.length} />
        <Stat label="En attente" value={counts.en_attente || 0}
          tone={counts.en_attente ? "#E8930C" : undefined} delay={.06} />
        <Stat label="Traitées" value={counts.traitee || 0} tone="#0EA47C" delay={.12} />
        <Stat label="Comptes" value={accounts.data?.length ?? "…"} delay={.18} />
      </div>

      {issued && (
        <div className="cred-box pop">
          <div className="cred-head">
            <span className="cred-ico"><Check size={17} strokeWidth={2.8} /></span>
            <div>
              <strong>Mot de passe réinitialisé</strong>
              <span>Transmettez-le à la personne. Il ne sera plus affiché.</span>
            </div>
            <button className="btn-mini" onClick={() => setIssued(null)}>Fermer</button>
          </div>
          <div className="cred-grid">
            <div><span>Identifiant</span><strong className="mono">{issued.email}</strong></div>
            <div><span>Mot de passe provisoire</span>
              <strong className="mono cred-pwd">{issued.password}</strong></div>
          </div>
        </div>
      )}

      {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
        {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}
        <div>{msg.t}</div></div>}

      <Panel title="Demandes de réinitialisation" note="depuis la page de connexion" delay={.24}
        action={<button className="btn-mini" onClick={list.reload}>
          <RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
        <div className="chip-row">
          {["en_attente", "traitee", "refusee", "sans_objet", "toutes"].map((f) => (
            <button key={f} className={`chip chip-sm${filter === f ? " chip-on" : ""}`}
              onClick={() => setFilter(f)}>
              {f.replace("_", " ")}{f !== "toutes" && counts[f] ? ` (${counts[f]})` : ""}
            </button>
          ))}
        </div>

        {!rows.length ? <Empty>Aucune demande dans cette catégorie.</Empty> : (
          <div className="req-list">
            {rows.map((r, i) => (
              <div key={r.id} className="req-card rise" style={{ animationDelay: `${0.05 * i}s` }}>
                <div className="req-main">
                  <div className="req-head">
                    <strong className="mono">{r.email}</strong>
                    <div className="req-tags">
                      {!r.account_exists && <span className="tag tag-warn">compte inconnu</span>}
                      <span className={`tag rstatus-${r.status === "en_attente" ? "en_attente"
                        : r.status === "traitee" ? "validée" : "refusée"}`}>
                        {r.status.replace("_", " ")}
                      </span>
                    </div>
                  </div>
                  <div className="req-meta">
                    <span className="dim mono">#{r.id} · {r.created_at}</span>
                    {r.reviewed_by && <span className="dim">
                      traitée par {r.reviewed_by.split("@")[0]} · {r.reviewed_at}</span>}
                  </div>
                </div>
                {r.status === "en_attente" && (
                  <div className="req-actions">
                    <div className="review-btns">
                      <button className="btn-act btn-act-ok" disabled={busy === `a${r.id}`}
                        onClick={() => act(`/api/reset/requests/${r.id}/approve`, `a${r.id}`)}>
                        {busy === `a${r.id}` ? <Loader2 size={14} className="spin" strokeWidth={2.4} />
                          : <KeyRound size={14} strokeWidth={2.4} />}Réinitialiser
                      </button>
                      <button className="btn-act btn-act-no" disabled={busy === `r${r.id}`}
                        onClick={() => act(`/api/reset/requests/${r.id}/reject`, `r${r.id}`)}>
                        <X size={14} strokeWidth={2.4} />Refuser
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </Panel>

      <Panel title="Réinitialisation directe" note="sans demande préalable" delay={.3}>
        <p className="panel-lead">
          Pour traiter une demande reçue par un autre canal — appel, message —
          sans attendre que la personne passe par la page de connexion.
        </p>
        {accounts.loading ? <Loading /> : (
          <table className="table">
            <thead><tr><th>Nom</th><th>Email</th><th>Rôle</th><th></th></tr></thead>
            <tbody>
              {(accounts.data || []).map((u) => (
                <tr key={u.id}>
                  <td><strong>{u.name}</strong></td>
                  <td className="mono dim">{u.email}</td>
                  <td><span className={`tag tag-role tag-${u.role}`}>
                    {ROLE_META[u.role]?.label || u.role}</span></td>
                  <td style={{ textAlign: "right" }}>
                    <button className="btn-act" disabled={busy === `d${u.id}`}
                      onClick={() => act(`/api/reset/direct/${u.id}`, `d${u.id}`)}>
                      {busy === `d${u.id}` ? <Loader2 size={13} className="spin" strokeWidth={2.4} />
                        : <KeyRound size={13} strokeWidth={2.4} />}Réinitialiser
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Panel>
    </>
  );
}
