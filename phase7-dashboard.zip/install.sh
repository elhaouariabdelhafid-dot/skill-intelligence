#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(dirname "${BASH_SOURCE[0]}")"

echo "==> Installation de Streamlit"
pip install -q streamlit pandas

echo "==> Copie du dashboard"
mkdir -p frontend
cp "$P/app.py" frontend/app.py

echo "==> Vérification"
python -c "import ast; ast.parse(open('frontend/app.py').read()); print('  Syntaxe OK')"

echo ""
echo "============================================================"
echo " Dashboard installé. Lance-le :"
echo "   streamlit run frontend/app.py"
echo ""
echo " Puis ouvre dans ton navigateur :"
echo "   http://localhost:8501"
echo "============================================================"
