#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Copie des modules"
cp "$P/settings_models.py" api/settings_models.py
cp "$P/settings_api.py"    api/settings_api.py

echo "==> Branchement du routeur"
python - << 'PYEOF'
from pathlib import Path
p = Path("api/main.py"); s = p.read_text()
if "settings_api" not in s:
    s = s.replace(
        "from api.requests_api import router as requests_router\napp.include_router(requests_router)",
        "from api.requests_api import router as requests_router\n"
        "app.include_router(requests_router)\n\n"
        "from api.settings_api import router as admin_router\n"
        "app.include_router(admin_router)")
    p.write_text(s); print("  routeur admin ajouté")
else:
    print("  routeur déjà présent")
PYEOF

echo "==> Création des tables"
python -c "from api.settings_models import get_settings_db; get_settings_db().close(); print('  app_settings / audit_log prêtes')"

echo ""
echo "============================================================"
echo " Administration installée."
echo " Relancer :  uvicorn api.main:app --reload --reload-exclude 'volumes/*' --port 8010"
echo " Tester   :  bash scripts/test_admin.sh"
echo "============================================================"
