#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Dépendance PDF"
pip install -q reportlab

echo "==> Copie des modules"
cp "$P/sessions_models.py" api/sessions_models.py
cp "$P/sessions_api.py"    api/sessions_api.py

echo "==> Branchement du routeur dans api/main.py"
python - << 'PYEOF'
from pathlib import Path
p = Path("api/main.py"); s = p.read_text()
if "sessions_api" not in s:
    s = s.replace(
        "app.include_router(auth_router)",
        "app.include_router(auth_router)\n\n"
        "from api.sessions_api import router as sessions_router\n"
        "app.include_router(sessions_router)")
    p.write_text(s)
    print("  routeur sessions ajouté")
else:
    print("  routeur déjà présent")
PYEOF

echo "==> Création des tables"
python -c "from api.sessions_models import get_sessions_db; get_sessions_db().close(); print('  tables eval_sessions / session_questions / session_answers prêtes')"

echo ""
echo "============================================================"
echo " Sessions d'évaluation installées."
echo ""
echo " Relancer l'API :"
echo "   uvicorn api.main:app --reload --reload-exclude 'volumes/*' --port 8010"
echo ""
echo " Tester le flux complet :"
echo "   bash scripts/test_sessions.sh"
echo "============================================================"
