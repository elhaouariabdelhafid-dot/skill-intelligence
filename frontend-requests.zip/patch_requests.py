"""Ajoute les vues du circuit de demandes au frontend."""
from pathlib import Path
import sys, re

APP = Path("src/App.jsx")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "MesDemandes" in s:
    print("Vues déjà présentes — rien à faire."); sys.exit(0)

block = Path("req_views.jsx").read_text(encoding="utf-8")

# 1) Icônes
m = re.search(r'\n\} from "lucide-react";', s)
s = s[:m.start()] + ",\n  MessageSquare, X, Inbox, ClipboardCheck" + s[m.start():]
print("1. icônes ajoutées")

# 2) Composants
anchor = "/* ═══════════════ ROUTES ═══════════════ */"
s = s.replace(anchor, block + "\n" + anchor)
print("2. composants insérés")

# 3) Routes
s = s.replace(
    "  mesexamens:   { label: \"Mes examens\",           icon: Award,         view: MesExamens },",
    "  mesexamens:   { label: \"Mes examens\",           icon: Award,         view: MesExamens },\n"
    "  mesdemandes:  { label: \"Demandes d'évaluation\", icon: Send,          view: MesDemandes },\n"
    "  arbitrage:    { label: \"Arbitrage des demandes\", icon: Inbox,        view: ArbitrageRH },\n"
    "  avalider:     { label: \"Demandes à planifier\",  icon: ClipboardCheck, view: DemandesValidees },")
print("3. routes déclarées")

# 4) Navigation
s = s.replace('manager:       ["equipe", "detail", "ontologie"],',
              'manager:       ["equipe", "mesdemandes", "detail", "ontologie"],')
s = s.replace('rh:            ["cartographie", "profils", "besoins", "ontologie"],',
              'rh:            ["arbitrage", "cartographie", "profils", "besoins", "ontologie"],')
s = s.replace('formateur:     ["evalsessions", "questions", "resultats"],',
              'formateur:     ["avalider", "evalsessions", "questions", "resultats"],')
s = s.replace('admin:         ["comptes", "evalsessions", "services", "ragas", "cartographie", "ontologie"],',
              'admin:         ["comptes", "arbitrage", "evalsessions", "services", "ragas", "cartographie", "ontologie"],')
print("4. navigation mise à jour")

APP.write_text(s, encoding="utf-8")

css = Path("src/styles.css")
c = css.read_text(encoding="utf-8")
if "req-card" not in c:
    css.write_text(c + "\n\n" + Path("req_extra.css").read_text(encoding="utf-8"), encoding="utf-8")
    print("5. styles ajoutés")

print("\nTerminé. Relancez : npm run dev")
