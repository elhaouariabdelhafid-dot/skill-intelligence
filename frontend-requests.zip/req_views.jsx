/* ═══════════════ DEMANDES — MANAGER ═══════════════ */
function MesDemandes() {
  const { api, token } = useCtx();
  const mine = useApi("/api/requests/mine");
  const people = useApi("/api/people");
  const questions = useApi("/api/questions");
  const [form, setForm] = useState({ title: "", justification: "", services: [], participants: [], priority: "normale" });
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  const allServices = useMemo(
    () => [...new Set((questions.data || []).map((q) => q.service))].filter(Boolean),
    [questions.data]);

  // Lacunes détectées sur l'équipe — nourrit la justification
  const gaps = useMemo(() => {
    if (!people.data?.length) return [];
    const svc = [...new Set(people.data.flatMap((p) => Object.keys(p.services || {})))];
    return svc.map((s) => {
      const vals = people.data.map((p) => p.services?.[s]).filter((v) => v != null);
      const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
      const below = people.data.filter((p) => (p.services?.[s] ?? 100) < THRESHOLD);
      return { service: s, avg, below };
    }).filter((g) => g.below.length > 0).sort((a, b) => a.avg - b.avg);
  }, [people.data]);

  const prefill = (g) => {
    setForm((f) => ({
      ...f,
      title: `Renforcement ${g.service} — équipe`,
      justification: `${g.below.length} collaborateur(s) sous le seuil de ${THRESHOLD} % sur ${g.service} `
        + `(moyenne équipe : ${g.avg.toFixed(1)} %). Concernés : ${g.below.map((p) => p.name).join(", ")}.`,
      services: [g.service],
      participants: g.below.map((p) => p.user_id),
      priority: g.avg < 45 ? "haute" : "normale",
    }));
    setMsg(null);
  };

  const toggle = (key, v) => setForm((f) => ({
    ...f, [key]: f[key].includes(v) ? f[key].filter((x) => x !== v) : [...f[key], v],
  }));

  const submit = async () => {
    if (!form.title.trim()) { setMsg({ ok: false, t: "Donnez un intitulé à la demande." }); return; }
    if (!form.participants.length) { setMsg({ ok: false, t: "Sélectionnez au moins un collaborateur." }); return; }
    setBusy(true); setMsg(null);
    try {
      await apiFetch(api, "/api/requests", token, { method: "POST", body: JSON.stringify(form) });
      setMsg({ ok: true, t: "Demande transmise aux ressources humaines." });
      setForm({ title: "", justification: "", services: [], participants: [], priority: "normale" });
      mine.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(false);
  };

  return (
    <>
      <div className="stat-row">
        <Stat label="Mes demandes" value={mine.data?.length ?? "…"} />
        <Stat label="En attente" value={mine.data?.filter((r) => r.status === "en_attente").length ?? "…"} tone="#E8930C" delay={.06} />
        <Stat label="Validées" value={mine.data?.filter((r) => ["validée", "planifiée"].includes(r.status)).length ?? "…"} tone="#0EA47C" delay={.12} />
        <Stat label="Lacunes détectées" value={gaps.length || "…"} sub="sur l'équipe" delay={.18} />
      </div>

      {gaps.length > 0 && (
        <Panel title="Besoins détectés sur votre équipe" note="cliquez pour préparer une demande" delay={.24}>
          <p className="panel-lead">
            Ces compétences sont sous le seuil pour au moins un collaborateur. Le
            système propose une demande pré-remplie à partir des mesures.
          </p>
          <div className="gap-cards">
            {gaps.slice(0, 4).map((g, i) => (
              <button key={g.service} className="gap-card rise" style={{ animationDelay: `${0.05 * i}s` }}
                onClick={() => prefill(g)}>
                <div className="gap-head">
                  <strong>{short(g.service)}</strong>
                  <span className="mono" style={{ color: BAND_COLOR[band(g.avg)] }}>{g.avg.toFixed(0)}%</span>
                </div>
                <span className="gap-sub">{g.below.length} collaborateur(s) concerné(s)</span>
                <span className="gap-cta"><Plus size={12} strokeWidth={2.6} />Préparer la demande</span>
              </button>
            ))}
          </div>
        </Panel>
      )}

      <Panel title="Soumettre une demande d'évaluation" note="transmise aux RH pour arbitrage" delay={.3}>
        <div className="launch">
          <label className="field field-inline" style={{ minWidth: 280 }}>
            <span className="field-label">Intitulé</span>
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Renforcement IAM — équipe Cloud" />
          </label>
          <label className="field field-inline" style={{ minWidth: 150 }}>
            <span className="field-label">Priorité</span>
            <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
              <option value="basse">Basse</option>
              <option value="normale">Normale</option>
              <option value="haute">Haute</option>
            </select>
          </label>
        </div>

        <label className="field" style={{ marginTop: 14 }}>
          <span className="field-label">Justification du besoin</span>
          <textarea className="answer-area" style={{ minHeight: 100 }} value={form.justification}
            onChange={(e) => setForm({ ...form, justification: e.target.value })}
            placeholder="Expliquez pourquoi cette évaluation est nécessaire — appuyez-vous sur les niveaux mesurés." />
        </label>

        <div className="pick-block">
          <span className="pick-label">Compétences à évaluer</span>
          <div className="chip-row">
            {allServices.map((s) => (
              <button key={s} className={`chip chip-sm${form.services.includes(s) ? " chip-on" : ""}`}
                onClick={() => toggle("services", s)}>{short(s)}</button>
            ))}
          </div>
        </div>

        <div className="pick-block">
          <span className="pick-label">Collaborateurs concernés</span>
          <div className="chip-row">
            {(people.data || []).map((p) => (
              <button key={p.user_id} className={`chip chip-sm${form.participants.includes(p.user_id) ? " chip-on" : ""}`}
                onClick={() => toggle("participants", p.user_id)}>
                {p.name} <span className="mono">{p.overall.toFixed(0)}%</span>
              </button>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 16 }}>
          <button className="btn-signin btn-inline" onClick={submit} disabled={busy}>
            {busy ? <><Loader2 size={15} className="spin" strokeWidth={2.4} />Envoi…</>
              : <><Send size={15} strokeWidth={2.2} />Transmettre aux RH</>}
          </button>
        </div>
        {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
          {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}<div>{msg.t}</div></div>}
      </Panel>

      <Panel title="Suivi de mes demandes" delay={.36}
        action={<button className="btn-mini" onClick={mine.reload}><RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
        {mine.loading ? <Loading /> : mine.error ? <ErrorState message={mine.error} onRetry={mine.reload} />
          : !mine.data.length ? <Empty>Vous n'avez soumis aucune demande.</Empty>
          : <RequestList rows={mine.data} />}
      </Panel>
    </>
  );
}

function RequestList({ rows, actions }) {
  return (
    <div className="req-list">
      {rows.map((r, i) => (
        <div key={r.id} className="req-card rise" style={{ animationDelay: `${0.05 * i}s` }}>
          <div className="req-main">
            <div className="req-head">
              <strong>{r.title}</strong>
              <div className="req-tags">
                <span className={`tag prio-${r.priority}`}>{r.priority}</span>
                <span className={`tag rstatus-${r.status}`}>{r.status.replace("_", " ")}</span>
              </div>
            </div>
            {r.justification && <p className="req-just">{r.justification}</p>}
            <div className="req-meta">
              <span><Users size={12} strokeWidth={2.2} />{r.participants.map((p) => p.name).join(", ")}</span>
              {r.services?.length > 0 && <span><Target size={12} strokeWidth={2.2} />{r.services.map(short).join(", ")}</span>}
              <span className="dim mono">#{r.id} · {r.created_at}</span>
            </div>
            {r.review_comment && (
              <div className="req-review">
                <MessageSquare size={12} strokeWidth={2.2} />
                <span><strong>RH</strong> — {r.review_comment}</span>
              </div>
            )}
            {r.session_id && (
              <div className="req-linked"><CalendarClock size={12} strokeWidth={2.2} />
                Session d'évaluation #{r.session_id} créée</div>
            )}
          </div>
          {actions && <div className="req-actions">{actions(r)}</div>}
        </div>
      ))}
    </div>
  );
}

/* ═══════════════ ARBITRAGE — RH ═══════════════ */
function ArbitrageRH() {
  const { api, token } = useCtx();
  const all = useApi("/api/requests");
  const [filter, setFilter] = useState("en_attente");
  const [comment, setComment] = useState({});
  const [busy, setBusy] = useState(null);
  const [msg, setMsg] = useState(null);

  const decide = async (rid, decision) => {
    setBusy(rid); setMsg(null);
    try {
      await apiFetch(api, `/api/requests/${rid}/review`, token, {
        method: "POST",
        body: JSON.stringify({ decision, comment: comment[rid] || "" }),
      });
      setMsg({ ok: true, t: `Demande #${rid} ${decision}.` });
      setComment((c) => ({ ...c, [rid]: "" }));
      all.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(null);
  };

  const rows = (all.data || []).filter((r) => filter === "toutes" || r.status === filter);
  const counts = (all.data || []).reduce((a, r) => ({ ...a, [r.status]: (a[r.status] || 0) + 1 }), {});

  return (
    <>
      <div className="stat-row">
        <Stat label="Demandes reçues" value={all.data?.length ?? "…"} />
        <Stat label="En attente d'arbitrage" value={counts.en_attente || 0} tone="#E8930C" delay={.06} />
        <Stat label="Validées" value={(counts["validée"] || 0) + (counts["planifiée"] || 0)} tone="#0EA47C" delay={.12} />
        <Stat label="Refusées" value={counts["refusée"] || 0} delay={.18} />
      </div>

      <Panel title="File des demandes" note="arbitrage des besoins de formation" delay={.24}
        action={<button className="btn-mini" onClick={all.reload}><RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
        <div className="chip-row">
          {["en_attente", "validée", "planifiée", "refusée", "toutes"].map((f) => (
            <button key={f} className={`chip chip-sm${filter === f ? " chip-on" : ""}`} onClick={() => setFilter(f)}>
              {f.replace("_", " ")}{f !== "toutes" && counts[f] ? ` (${counts[f]})` : ""}
            </button>
          ))}
        </div>

        {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
          {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}<div>{msg.t}</div></div>}

        {all.loading ? <Loading /> : all.error ? <ErrorState message={all.error} onRetry={all.reload} />
          : !rows.length ? <Empty>Aucune demande dans cette catégorie.</Empty>
          : <RequestList rows={rows} actions={(r) => r.status === "en_attente" ? (
              <div className="review-box">
                <textarea className="review-comment" placeholder="Motif de la décision (facultatif)"
                  value={comment[r.id] || ""} onChange={(e) => setComment({ ...comment, [r.id]: e.target.value })} />
                <div className="review-btns">
                  <button className="btn-act btn-act-ok" disabled={busy === r.id}
                    onClick={() => decide(r.id, "validée")}>
                    {busy === r.id ? <Loader2 size={14} className="spin" strokeWidth={2.4} /> : <Check size={14} strokeWidth={2.4} />}
                    Valider</button>
                  <button className="btn-act btn-act-no" disabled={busy === r.id}
                    onClick={() => decide(r.id, "refusée")}>
                    <X size={14} strokeWidth={2.4} />Refuser</button>
                </div>
              </div>
            ) : (
              <span className="req-done">
                {r.reviewed_by ? `Traitée par ${r.reviewed_by.split("@")[0]}` : ""}
                {r.reviewed_at ? ` · ${r.reviewed_at}` : ""}
              </span>
            )} />}
      </Panel>
    </>
  );
}

/* ═══════════════ DEMANDES VALIDÉES — FORMATEUR ═══════════════ */
function DemandesValidees() {
  const { api, token } = useCtx();
  const list = useApi("/api/requests");
  const [busy, setBusy] = useState(null);
  const [msg, setMsg] = useState(null);

  const plan = async (rid) => {
    setBusy(rid); setMsg(null);
    try {
      const r = await apiFetch(api, `/api/requests/${rid}/plan`, token, { method: "POST" });
      setMsg({ ok: true, t: `Session #${r.session_id} créée. Rendez-vous dans « Sessions d'évaluation » pour générer le sujet.` });
      list.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(null);
  };

  const pending = (list.data || []).filter((r) => r.status === "validée");
  const planned = (list.data || []).filter((r) => r.status === "planifiée");

  return (
    <>
      <div className="stat-row">
        <Stat label="À planifier" value={pending.length} tone={pending.length ? "#E8930C" : undefined} />
        <Stat label="Déjà planifiées" value={planned.length} tone="#0EA47C" delay={.06} />
        <Stat label="Collaborateurs concernés"
          value={[...new Set(pending.flatMap((r) => r.participants.map((p) => p.id)))].length} delay={.12} />
        <Stat label="Compétences visées"
          value={[...new Set(pending.flatMap((r) => r.services || []))].length} delay={.18} />
      </div>

      <Panel title="Demandes validées à planifier" note="arbitrées par les RH" delay={.24}
        action={<button className="btn-mini" onClick={list.reload}><RefreshCw size={13} strokeWidth={2.4} />Actualiser</button>}>
        {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
          {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}<div>{msg.t}</div></div>}

        {list.loading ? <Loading /> : list.error ? <ErrorState message={list.error} onRetry={list.reload} />
          : !pending.length ? <Empty>Aucune demande en attente de planification.</Empty>
          : <RequestList rows={pending} actions={(r) => (
              <button className="btn-act btn-act-primary" disabled={busy === r.id} onClick={() => plan(r.id)}>
                {busy === r.id ? <Loader2 size={14} className="spin" strokeWidth={2.4} /> : <CalendarClock size={14} strokeWidth={2.2} />}
                Créer la session</button>
            )} />}
      </Panel>

      {planned.length > 0 && (
        <Panel title="Demandes déjà planifiées" delay={.3}>
          <RequestList rows={planned} />
        </Panel>
      )}
    </>
  );
}
