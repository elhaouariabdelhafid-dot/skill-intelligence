#!/usr/bin/env bash
set -euo pipefail
D="$HOME/skill-intelligence/frontend-web"
[ -d "$D" ] || { echo "Dossier $D introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$D"
cp "$P/req_views.jsx" "$P/req_extra.css" .
python3 "$P/patch_requests.py"
rm -f req_views.jsx req_extra.css
echo ""
echo "Relancez le frontend :  cd $D && npm run dev"
