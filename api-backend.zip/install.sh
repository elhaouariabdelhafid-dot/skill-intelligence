#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Dépendances API"
pip install -q fastapi "uvicorn[standard]" python-multipart

echo "==> Installation des fichiers"
cp "$P/main.py" api/main.py
mkdir -p scripts
cp "$P/link_profiles.py" scripts/link_profiles.py
cp "$P/test_api.sh" scripts/test_api.sh
chmod +x scripts/test_api.sh

echo "==> Liaison des comptes aux profils métier"
python scripts/link_profiles.py

echo ""
echo "============================================================"
echo " API installée."
echo ""
echo " Lancer :   uvicorn api.main:app --reload --port 8000"
echo " Docs   :   http://localhost:8000/docs"
echo " Tester :   bash scripts/test_api.sh   (dans un autre terminal)"
echo "============================================================"
