"""Exclut les collaborateurs non evalues des moyennes et des statistiques.

LE BIAIS : depuis que /api/people renvoie aussi les collaborateurs sans
evaluation — necessaire pour qu'un nouvel arrivant soit selectionnable dans une
session — leur niveau de 0 % entre dans les moyennes. Avec quatre personnes
autour de 45 % et une non evaluee, la moyenne affichee tombe a 35,6 %.

LA CORRECTION : les moyennes, les graphiques et la detection des lacunes ne
portent que sur les personnes disposant d'au moins une evaluation. Les autres
restent visibles, comptees a part, avec la mention « en attente d'evaluation ».
"""
from pathlib import Path
import sys

p = Path("src/App.jsx")
if not p.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = p.read_text(encoding="utf-8")
if "const evalues" in s:
    print("Deja corrige."); sys.exit(0)

# ══════════════ 1. Cartographie (RH) ══════════════
old = '''  const services = [...new Set(data.flatMap((p) => Object.keys(p.services || {})))];
  const avg = data.reduce((a, p) => a + p.overall, 0) / data.length;

  return (
    <>
      <div className="stat-row">
        <Stat label="Collaborateurs évalués" value={data.length} />
        <Stat label="Niveau moyen" value={`${avg.toFixed(1)}%`} delay={.06} />
        <Stat label="Services couverts" value={services.length} delay={.12} />
        <Stat label="Réponses évaluées" value={data.reduce((a, p) => a + (p.n_evaluations || 0), 0)} delay={.18} />
      </div>'''
new = '''  const services = [...new Set(data.flatMap((p) => Object.keys(p.services || {})))];
  // Les collaborateurs sans evaluation fausseraient la moyenne : ils comptent
  // pour 0 % alors qu'ils n'ont simplement pas encore ete evalues.
  const evalues = data.filter((p) => (p.n_evaluations || 0) > 0);
  const attente = data.length - evalues.length;
  const avg = evalues.length
    ? evalues.reduce((a, p) => a + p.overall, 0) / evalues.length : 0;

  return (
    <>
      <div className="stat-row">
        <Stat label="Collaborateurs évalués" value={evalues.length}
          sub={attente ? `${attente} en attente` : undefined} />
        <Stat label="Niveau moyen" value={`${avg.toFixed(1)}%`}
          sub="sur les collaborateurs évalués" delay={.06} />
        <Stat label="Services couverts" value={services.length} delay={.12} />
        <Stat label="Réponses évaluées" value={data.reduce((a, p) => a + (p.n_evaluations || 0), 0)} delay={.18} />
      </div>'''
if old in s:
    s = s.replace(old, new); print("1. Cartographie corrigee")
else:
    print("1. ATTENTION : bloc Cartographie non trouve")

# La grille distingue les non evalues
old_cell = '''                {services.map((s) => {
                  const v = p.services?.[s];
                  return v == null
                    ? <div key={s} className="hm-cell hm-na">—</div>'''
new_cell = '''                {services.map((s) => {
                  const v = (p.n_evaluations || 0) > 0 ? p.services?.[s] : null;
                  return v == null
                    ? <div key={s} className="hm-cell hm-na">—</div>'''
if old_cell in s:
    s = s.replace(old_cell, new_cell); print("   grille : non evalues affiches en tiret")

# ══════════════ 2. Vue equipe (manager) ══════════════
old_eq = '''  const chart = data.map((p) => ({ name: p.name, niveau: p.overall }));
  const allServices = [...new Set(data.flatMap((p) => Object.keys(p.services || {})))];
  const avgByService = allServices.map((s) => {
    const vals = data.map((p) => p.services?.[s]).filter((v) => v != null);
    return { service: short(s), moyenne: +(vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) };
  }).sort((a, b) => a.moyenne - b.moyenne);
  const worst = avgByService[0];
  const avg = data.reduce((a, p) => a + p.overall, 0) / data.length;

  return (
    <>
      <div className="stat-row">
        <Stat label="Collaborateurs suivis" value={data.length} />
        <Stat label="Niveau moyen" value={`${avg.toFixed(1)}%`} delay={.06} />'''
new_eq = '''  // Seuls les collaborateurs evalues entrent dans les statistiques
  const evalues = data.filter((p) => (p.n_evaluations || 0) > 0);
  const attente = data.length - evalues.length;
  const chart = evalues.map((p) => ({ name: p.name, niveau: p.overall }));
  const allServices = [...new Set(evalues.flatMap((p) => Object.keys(p.services || {})))];
  const avgByService = allServices.map((s) => {
    const vals = evalues.map((p) => p.services?.[s]).filter((v) => v != null);
    return { service: short(s),
             moyenne: vals.length ? +(vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) : 0 };
  }).sort((a, b) => a.moyenne - b.moyenne);
  const worst = avgByService[0] || { service: "—", moyenne: 0 };
  const avg = evalues.length
    ? evalues.reduce((a, p) => a + p.overall, 0) / evalues.length : 0;

  return (
    <>
      <div className="stat-row">
        <Stat label="Collaborateurs suivis" value={data.length}
          sub={attente ? `dont ${attente} non évalué(s)` : undefined} />
        <Stat label="Niveau moyen" value={`${avg.toFixed(1)}%`}
          sub="sur les collaborateurs évalués" delay={.06} />'''
if old_eq in s:
    s = s.replace(old_eq, new_eq); print("2. Vue equipe corrigee")
else:
    print("2. ATTENTION : bloc Vue equipe non trouve")

s = s.replace(
    '        <Stat label="Évaluations" value={data.reduce((a, p) => a + (p.n_evaluations || 0), 0)} delay={.18} />',
    '        <Stat label="Évaluations" value={data.reduce((a, p) => a + (p.n_evaluations || 0), 0)} delay={.18} />')

# ══════════════ 3. Besoins de formation (RH) ══════════════
old_be = '''  const services = [...new Set(data.flatMap((p) => Object.keys(p.services || {})))];
  const rows = services.map((s) => {
    const vals = data.map((p) => p.services?.[s]).filter((v) => v != null);'''
new_be = '''  // Une personne non evaluee n'est pas une lacune : elle n'a pas encore ete mesuree
  const evalues = data.filter((p) => (p.n_evaluations || 0) > 0);
  const services = [...new Set(evalues.flatMap((p) => Object.keys(p.services || {})))];
  const rows = services.map((s) => {
    const vals = evalues.map((p) => p.services?.[s]).filter((v) => v != null);'''
if old_be in s:
    s = s.replace(old_be, new_be); print("3. Besoins de formation corriges")
else:
    print("3. ATTENTION : bloc Besoins non trouve")

# ══════════════ 4. Profils : mention explicite ══════════════
old_pr = '''            <div><strong>{p.name}</strong><span className="dim">{p.n_evaluations} évaluations</span></div>'''
new_pr = '''            <div><strong>{p.name}</strong><span className="dim">
              {(p.n_evaluations || 0) > 0 ? `${p.n_evaluations} évaluations`
                                          : "en attente d'évaluation"}</span></div>'''
if old_pr in s:
    s = s.replace(old_pr, new_pr); print("4. Profils : mention ajoutee")

p.write_text(s, encoding="utf-8")
print("\nTermine. Relancez : npm run dev")
