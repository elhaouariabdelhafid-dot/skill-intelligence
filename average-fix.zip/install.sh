#!/usr/bin/env bash
set -euo pipefail
D="$HOME/skill-intelligence/frontend-web"
[ -d "$D" ] || { echo "Dossier $D introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$D"
cp src/App.jsx src/App.jsx.bak11
echo "Sauvegarde : src/App.jsx.bak11"
python3 "$P/fix_avg.py"
echo ""
echo "Relancez :  cd $D && npm run dev"
