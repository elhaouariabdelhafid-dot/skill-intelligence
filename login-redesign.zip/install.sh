#!/usr/bin/env bash
set -euo pipefail
D="$HOME/skill-intelligence/frontend-web"
[ -d "$D" ] || { echo "Dossier $D introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$D"
cp src/App.jsx src/App.jsx.bak3
cp src/styles.css src/styles.css.bak3
echo "Sauvegardes : src/App.jsx.bak3 · src/styles.css.bak3"
cp "$P/login_new.jsx" "$P/login_new.css" .
python3 "$P/patch_login.py"
rm -f login_new.jsx login_new.css
echo ""
echo "Relancez :  cd $D && npm run dev"
