/* ═══════════════ CONNEXION ═══════════════ */
function Login({ onSuccess, dark, toggleDark, api, setApi, onBack }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [status, setStatus] = useState("idle");
  const [msg, setMsg] = useState("");
  const [ripples, setRipples] = useState([]);
  const [cfg, setCfg] = useState(false);
  const [hint, setHint] = useState(false);

  const submit = useCallback(async (e) => {
    if (e?.clientX && e.currentTarget) {
      const r = e.currentTarget.getBoundingClientRect(), id = Date.now();
      setRipples((p) => [...p, { id, x: e.clientX - r.left, y: e.clientY - r.top }]);
      setTimeout(() => setRipples((p) => p.filter((x) => x.id !== id)), 700);
    }
    if (status === "loading") return;
    if (!email || !password) {
      setMsg("Saisissez votre email et votre mot de passe.");
      setStatus("error"); setTimeout(() => setStatus("idle"), 2600); return;
    }
    setStatus("loading");
    try {
      const data = await apiFetch(api, "/auth/login", null, {
        method: "POST",
        body: JSON.stringify({ email: email.trim().toLowerCase(), password }),
      });
      setStatus("success");
      setTimeout(() => onSuccess({
        token: data.access_token, role: data.role,
        name: data.full_name, email: email.trim().toLowerCase(),
      }), 950);
    } catch (err) {
      const offline = err.message === "Failed to fetch" || err.message.includes("NetworkError");
      setMsg(offline
        ? "Serveur injoignable. Vérifiez que l'API est démarrée."
        : "Email ou mot de passe incorrect.");
      setStatus("error");
      setTimeout(() => setStatus("idle"), 3400);
    }
  }, [email, password, status, api, onSuccess]);

  return (
    <div className="auth">
      {/* décor */}
      <div className="auth-bg" aria-hidden="true">
        <span className="auth-blob b1" />
        <span className="auth-blob b2" />
        <span className="auth-blob b3" />
        <Particles count={22} />
      </div>

      <div className="auth-top">
        {onBack && (
          <button className="auth-back" onClick={onBack}>
            <ChevronLeft size={14} strokeWidth={2.4} />Accueil
          </button>
        )}
        <button className="auth-theme" onClick={toggleDark}
          aria-label={dark ? "Passer en mode clair" : "Passer en mode sombre"}>
          <span className="th-track"><span className={`th-knob${dark ? " on" : ""}`}>
            {dark ? <Moon size={12} strokeWidth={2.5} /> : <Sun size={12} strokeWidth={2.5} />}
          </span></span>
        </button>
      </div>

      <main className="auth-main">
        <header className="auth-head">
          <img src="/cmh-logo.png" alt="Cloud Marketing Hub" className="auth-logo" />
          <h1 className="auth-title">Bienvenue sur Cloud Marketing Hub</h1>
          <p className="auth-lead">
            Évaluez, développez et certifiez vos compétences grâce à
            l'intelligence artificielle.
          </p>
          <span className="auth-orbit" aria-hidden="true">
            <span className="orbit-ring" />
            <span className="orbit-core"><Bot size={17} strokeWidth={2} /></span>
          </span>
        </header>

        <section className="auth-card">
          <div className="auth-card-head">
            <h2>Welcome back <span className="hand" role="img" aria-label="salut">👋</span></h2>
            <p>Connexion à EvaSmart</p>
          </div>

          <div className="auth-fields">
            <div className={`ffield${email ? " filled" : ""}`}>
              <Mail className="ff-ico" size={16} strokeWidth={2} />
              <input id="lg-email" type="email" value={email} autoComplete="username"
                placeholder=" " onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submit(e)} />
              <label htmlFor="lg-email">Adresse email</label>
            </div>

            <div className={`ffield${password ? " filled" : ""}`}>
              <Lock className="ff-ico" size={16} strokeWidth={2} />
              <input id="lg-pwd" type={show ? "text" : "password"} value={password}
                autoComplete="current-password" placeholder=" "
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submit(e)} />
              <label htmlFor="lg-pwd">Mot de passe</label>
              <button type="button" className="ff-eye" onClick={() => setShow(!show)}
                aria-label={show ? "Masquer" : "Afficher"}>
                {show ? <EyeOff size={16} strokeWidth={2} /> : <Eye size={16} strokeWidth={2} />}
              </button>
            </div>

            <div className="auth-row">
              <label className="auth-check">
                <input type="checkbox" checked={remember}
                  onChange={(e) => setRemember(e.target.checked)} />
                <span className="ac-box"><Check size={11} strokeWidth={3.4} /></span>
                <span>Se souvenir de moi</span>
              </label>
              <button type="button" className="auth-link">Mot de passe oublié ?</button>
            </div>

            <div className="auth-slot" aria-live="polite">
              {status === "error" && (
                <div className="auth-alert err shake">
                  <AlertTriangle size={15} strokeWidth={2.4} />{msg}
                </div>
              )}
              {status === "success" && (
                <div className="auth-alert ok pop">
                  <span className="tick"><Check size={13} strokeWidth={3.2} /></span>
                  Connexion réussie
                </div>
              )}
            </div>

            <button className="auth-submit" onClick={submit}
              disabled={status === "loading" || status === "success"}>
              {ripples.map((r) => (
                <span key={r.id} className="auth-ripple" style={{ left: r.x, top: r.y }} />
              ))}
              {status === "loading"
                ? <><Loader2 className="spin" size={17} strokeWidth={2.4} />Connexion…</>
                : status === "success"
                ? <><Check size={17} strokeWidth={2.6} />Connecté</>
                : <>Se connecter<ArrowRight size={17} strokeWidth={2.4} className="sub-arrow" /></>}
            </button>

            <div className="auth-tools">
              <button className="auth-tool" onClick={() => setHint(!hint)}>
                Accès de démonstration
              </button>
              <span className="auth-dot" />
              <button className="auth-tool" onClick={() => setCfg(!cfg)}>
                <Settings size={11} strokeWidth={2.4} />Serveur
              </button>
            </div>

            {hint && (
              <div className="auth-hint pop">
                {[["Administration", "admin@cmh.ma", "Admin@2026"],
                  ["Ressources humaines", "rh@cmh.ma", "Rh@2026"],
                  ["Management", "manager@cmh.ma", "Manager@2026"],
                  ["Formation", "formateur@cmh.ma", "Formateur@2026"],
                  ["Collaborateur", "hafid@cmh.ma", "Hafid@2026"]].map(([r, m, p]) => (
                  <button key={m} className="hint-row"
                    onClick={() => { setEmail(m); setPassword(p); setHint(false); setStatus("idle"); }}>
                    <span>{r}</span><span className="mono">{m}</span>
                  </button>
                ))}
              </div>
            )}

            {cfg && (
              <div className="ffield cfg pop">
                <input value={api} onChange={(e) => setApi(e.target.value)}
                  placeholder=" " />
                <label>Adresse du serveur</label>
              </div>
            )}
          </div>
        </section>

        <footer className="auth-foot">
          <span>© 2026 Cloud Marketing Hub</span>
          <span className="auth-dot" />
          <span>Powered by EvaSmart AI</span>
        </footer>
      </main>
    </div>
  );
}
