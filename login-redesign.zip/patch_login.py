"""Remplace la page de connexion par une version centree."""
from pathlib import Path
import sys, re

APP, CSS = Path("src/App.jsx"), Path("src/styles.css")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "auth-card" in s:
    print("Nouvelle page deja en place."); sys.exit(0)

new = Path("login_new.jsx").read_text(encoding="utf-8")

start = s.find("/* ═══════════════ CONNEXION ═══════════════ */")
end = s.find("/* ═══════════════ CHARGEMENT ═══════════════ */")
if start == -1 or end == -1 or end < start:
    print("ERREUR : bornes du composant Login introuvables"); sys.exit(1)

s = s[:start] + new + "\n" + s[end:]
print("1. composant Login remplace")

# Icone AlertTriangle requise
if "AlertTriangle" not in s.split("from \"lucide-react\"")[0]:
    m = re.search(r'\n\} from "lucide-react";', s)
    s = s[:m.start()] + ",\n  AlertTriangle" + s[m.start():]
    print("2. icone AlertTriangle ajoutee")

APP.write_text(s, encoding="utf-8")

c = CSS.read_text(encoding="utf-8")
if ".auth-card" not in c:
    CSS.write_text(c + Path("login_new.css").read_text(encoding="utf-8"), encoding="utf-8")
    print("3. styles ajoutes")

print("\nTermine. Relancez : npm run dev")
