"""Ajoute l'ecran RH des arrivees et l'accueil des nouveaux collaborateurs."""
from pathlib import Path
import re, sys

APP, CSS = Path("src/App.jsx"), Path("src/styles.css")
if not APP.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence/frontend-web"); sys.exit(1)

s = APP.read_text(encoding="utf-8")
if "function Arrivees(" in s:
    print("Deja en place."); sys.exit(0)

block = Path("onboard_views.jsx").read_text(encoding="utf-8")
anchor = "/* ═══════════════ ROUTES ═══════════════ */"
s = s.replace(anchor, block + "\n" + anchor)
print("1. composants inseres")

# Route + navigation RH
s = s.replace(
    '  cartographie: { label: "Cartographie",          icon: Grid3x3,       view: Cartographie },',
    '  cartographie: { label: "Cartographie",          icon: Grid3x3,       view: Cartographie },\n'
    '  arrivees:     { label: "Arrivées",              icon: UserPlus,      view: Arrivees },')
s = s.replace(
    '  rh:            ["arbitrage", "cartographie", "profils", "besoins", "ontologie"],',
    '  rh:            ["arbitrage", "arrivees", "cartographie", "profils", "besoins", "ontologie"],')
print("2. route Arrivees ajoutee au RH")

# Les trois vues collaborateur affichent l'accueil si aucune evaluation
s = s.replace(
    '  if (loading) return <Loading label="Chargement de votre profil…" />;\n'
    '  if (error) return <ErrorState message={error} onRetry={reload} />;\n',
    '  if (loading) return <Loading label="Chargement de votre profil…" />;\n'
    '  if (error) return <ErrorState message={error} onRetry={reload} />;\n'
    '  if (data.new_member || !data.n_evaluations) return <NouveauCollaborateur name={data.name} />;\n')

s = s.replace(
    '  if (plan.loading || profile.loading) return <Loading label="Construction de votre parcours…" />;\n'
    '  if (plan.error) return <ErrorState message={plan.error} onRetry={plan.reload} />;\n',
    '  if (plan.loading || profile.loading) return <Loading label="Construction de votre parcours…" />;\n'
    '  if (plan.error) return <ErrorState message={plan.error} onRetry={plan.reload} />;\n'
    '  if (profile.data?.new_member) return <NouveauCollaborateur name={profile.data.name} />;\n')

s = s.replace(
    '  if (loading) return <Loading label="Chargement de vos évaluations…" />;\n'
    '  if (error) return <ErrorState message={error} onRetry={reload} />;\n',
    '  if (loading) return <Loading label="Chargement de vos évaluations…" />;\n'
    '  if (error) return <ErrorState message={error} onRetry={reload} />;\n'
    '  if (!data.length) return <NouveauCollaborateur />;\n')
print("3. accueil affiche pour les nouveaux collaborateurs")

# Icone
if "UserPlus" not in s.split('from "lucide-react"')[0]:
    m = re.search(r'\n\} from "lucide-react";', s)
    s = s[:m.start()] + ",\n  UserPlus" + s[m.start():]

APP.write_text(s, encoding="utf-8")

c = CSS.read_text(encoding="utf-8")
if ".welcome-step" not in c:
    CSS.write_text(c + Path("onboard.css").read_text(encoding="utf-8"), encoding="utf-8")
    print("4. styles ajoutes")

print("\nTermine. Relancez : npm run dev")
