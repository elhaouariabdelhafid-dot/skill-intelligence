/* ═══════════════ ARRIVÉES — RH ═══════════════ */
function Arrivees() {
  const { api, token } = useCtx();
  const people = useApi("/api/people");
  const orphans = useApi("/api/people/unlinked");
  const [form, setForm] = useState({ full_name: "", email: "", role: "collaborateur" });
  const [busy, setBusy] = useState(null);
  const [issued, setIssued] = useState(null);
  const [msg, setMsg] = useState(null);

  const declare = async () => {
    if (!form.full_name.trim() || !form.email.trim()) {
      setMsg({ ok: false, t: "Renseignez le nom et l'adresse email." }); return;
    }
    setBusy("new"); setMsg(null); setIssued(null);
    try {
      const r = await apiFetch(api, "/api/people/onboard", token, {
        method: "POST", body: JSON.stringify(form),
      });
      setIssued(r);
      setForm({ full_name: "", email: "", role: "collaborateur" });
      people.reload(); orphans.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(null);
  };

  const repair = async (id) => {
    setBusy(id);
    try {
      await apiFetch(api, `/api/people/${id}/link`, token, { method: "POST" });
      setMsg({ ok: true, t: "Profil créé et rattaché au compte." });
      orphans.reload(); people.reload();
    } catch (e) { setMsg({ ok: false, t: e.message }); }
    setBusy(null);
  };

  return (
    <>
      <div className="stat-row">
        <Stat label="Collaborateurs déclarés" value={people.data?.length ?? "…"} />
        <Stat label="Comptes incomplets" value={orphans.data?.length ?? "…"}
          tone={orphans.data?.length ? "#E8930C" : "#0EA47C"} delay={.06} />
        <Stat label="Créés ensemble" value="compte + profil" sub="opération unique" delay={.12} />
        <Stat label="Évaluations" value={people.data?.reduce((a, p) => a + (p.n_evaluations || 0), 0) ?? "…"} delay={.18} />
      </div>

      {issued && (
        <div className="cred-box pop">
          <div className="cred-head">
            <span className="cred-ico"><Check size={17} strokeWidth={2.8} /></span>
            <div>
              <strong>{issued.full_name} est déclaré</strong>
              <span>
                {issued.linked_existing
                  ? "Rattaché à un profil déjà évalué — son historique est conservé."
                  : "Compte et profil créés. Transmettez ces identifiants."}
              </span>
            </div>
            <button className="btn-mini" onClick={() => setIssued(null)}>Fermer</button>
          </div>
          <div className="cred-grid">
            <div><span>Identifiant</span><strong className="mono">{issued.email}</strong></div>
            <div><span>Mot de passe provisoire</span>
              <strong className="mono cred-pwd">{issued.temp_password}</strong></div>
          </div>
        </div>
      )}

      {msg && <div className={`notice pop${msg.ok ? "" : " notice-err"}`}>
        {msg.ok ? <Check size={15} strokeWidth={2.6} /> : <AlertTriangle size={15} strokeWidth={2.4} />}
        <div>{msg.t}</div></div>}

      <Panel title="Déclarer une arrivée" note="le compte et le profil sont créés ensemble" delay={.24}>
        <p className="panel-lead">
          Le collaborateur devient immédiatement évaluable : il peut être invité à
          une session et disposera d'un profil dès sa première évaluation.
        </p>
        <div className="launch">
          <label className="field field-inline" style={{ minWidth: 220 }}>
            <span className="field-label">Nom complet</span>
            <input value={form.full_name} placeholder="Prénom Nom"
              onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
          </label>
          <label className="field field-inline" style={{ minWidth: 220 }}>
            <span className="field-label">Email professionnel</span>
            <input value={form.email} placeholder="prenom@cmh.ma"
              onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </label>
          <button className="btn-signin btn-inline" onClick={declare} disabled={busy === "new"}>
            {busy === "new" ? <><Loader2 size={15} className="spin" strokeWidth={2.4} />Création…</>
              : <><UserPlus size={15} strokeWidth={2.2} />Déclarer</>}
          </button>
        </div>
      </Panel>

      {orphans.data?.length > 0 && (
        <Panel title="Comptes à compléter" note="créés sans profil métier" delay={.3}>
          <p className="panel-lead">
            Ces comptes peuvent se connecter mais n'ont pas de profil : ils ne sont
            ni évaluables, ni sélectionnables dans une session.
          </p>
          <table className="table">
            <thead><tr><th>Nom</th><th>Email</th><th></th></tr></thead>
            <tbody>
              {orphans.data.map((o) => (
                <tr key={o.id}>
                  <td><strong>{o.full_name}</strong></td>
                  <td className="mono dim">{o.email}</td>
                  <td style={{ textAlign: "right" }}>
                    <button className="btn-act btn-act-primary" disabled={busy === o.id}
                      onClick={() => repair(o.id)}>
                      {busy === o.id ? <Loader2 size={13} className="spin" strokeWidth={2.4} />
                        : <Check size={13} strokeWidth={2.4} />}Créer le profil
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      )}

      <Panel title="Collaborateurs" note={`${people.data?.length ?? 0} déclarés`} delay={.36}>
        {people.loading ? <Loading /> : !people.data?.length ? <Empty>Aucun collaborateur.</Empty> : (
          <table className="table">
            <thead><tr><th>Nom</th><th>Évaluations</th><th>Niveau</th></tr></thead>
            <tbody>
              {people.data.map((p) => (
                <tr key={p.user_id}>
                  <td><div className="cell-user"><span className="avatar">{p.name.charAt(0)}</span>
                    <strong>{p.name}</strong></div></td>
                  <td className="mono">{p.n_evaluations || 0}</td>
                  <td>{p.n_evaluations
                    ? <span className="mono strong" style={{ color: BAND_COLOR[band(p.overall)] }}>
                        {p.overall.toFixed(1)}%</span>
                    : <span className="tag">en attente d'évaluation</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Panel>
    </>
  );
}

/* Écran d'accueil pour un collaborateur sans évaluation */
function NouveauCollaborateur({ name }) {
  return (
    <div className="welcome rise">
      <span className="welcome-ico"><Sparkles size={24} strokeWidth={1.9} /></span>
      <h2>Bienvenue{name ? `, ${name.split(" ")[0]}` : ""}.</h2>
      <p>
        Vous n'avez pas encore passé d'évaluation. Votre profil de compétences,
        vos points forts et votre parcours de formation apparaîtront ici dès votre
        première session terminée.
      </p>
      <div className="welcome-steps">
        {[["Une session vous sera assignée", "Votre formateur programme l'évaluation."],
          ["Vous répondez aux questions", "Depuis l'onglet « Mes examens », à votre rythme."],
          ["Votre profil se construit", "Trois agents évaluent chaque réponse."]].map(([t, d], i) => (
          <div key={t} className="welcome-step">
            <span className="ws-n">{i + 1}</span>
            <div><strong>{t}</strong><span>{d}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}
