"""Branche l'onboarding et fait passer l'approbation d'acces par le meme chemin."""
from pathlib import Path
import re, sys

ROOT = Path.cwd()
if not (ROOT / "api").exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

# ── 1. Routeur ──
p = ROOT / "api" / "main.py"; s = p.read_text(encoding="utf-8")
if "onboarding" not in s:
    s = s.rstrip() + (
        "\n\nfrom api.onboarding import router as onboarding_router\n"
        "app.include_router(onboarding_router)\n")
    p.write_text(s, encoding="utf-8")
    print("1. routeur onboarding branche")
else:
    print("1. routeur deja present")

# ── 2. L'approbation d'une demande cree aussi le profil metier ──
p = ROOT / "api" / "access_api.py"; s = p.read_text(encoding="utf-8")
old = '''        temp_pwd = _temp_password()
        account = AuthUser(email=r.email, password_hash=hash_password(temp_pwd),
                           full_name=r.full_name, role=role, org_id=org.id)
        asess.add(account); asess.commit()
        r.created_account_id = account.id
        asess.close()
        log_action(user["email"], "creation de compte",
                   f"{r.email} · role {role} · via demande #{r.id}")'''
new = '''        asess.close()
        # Meme chemin que l'onboarding RH : compte ET profil metier
        from api.onboarding import create_member
        created = create_member(r.full_name, r.email, role, user["email"])
        temp_pwd = created["temp_password"]
        r.created_account_id = created["account_id"]
        log_action(user["email"], "creation de compte",
                   f"{r.email} · role {role} · via demande #{r.id}")'''
if old in s:
    s = s.replace(old, new)
    p.write_text(s, encoding="utf-8")
    print("2. approbation d'acces cree desormais le profil metier")
else:
    print("2. ATTENTION : bloc d'approbation non trouve")

# ── 3. Message d'accueil au lieu d'une erreur technique ──
p = ROOT / "api" / "main.py"; s = p.read_text(encoding="utf-8")
old_err = '''    if au is None or au.profile_user_id is None:
        raise HTTPException(404, "Aucun profil métier lié à ce compte. "
                                 "Lancez scripts/link_profiles.py")
    return _profile_payload(au.profile_user_id)'''
new_err = '''    if au is None or au.profile_user_id is None:
        # Compte sans profil : etat transitoire, pas une erreur
        return {"user_id": None, "n_evaluations": 0, "overall": 0.0,
                "skills": {}, "services": {}, "gaps": [],
                "name": au.full_name if au else "", "new_member": True}
    payload = _profile_payload(au.profile_user_id)
    payload["new_member"] = payload.get("n_evaluations", 0) == 0
    return payload'''
if old_err in s:
    s = s.replace(old_err, new_err)
    p.write_text(s, encoding="utf-8")
    print("3. /api/me/profile renvoie un profil vide au lieu d'une erreur")
else:
    print("3. ATTENTION : bloc /api/me/profile non trouve")

# ── 4. Meme traitement pour le plan et les evaluations ──
s = p.read_text(encoding="utf-8")
for endpoint, empty in (("my_plan", "{\"gaps\": [], \"new_member\": True}"),
                        ("my_evaluations", "[]")):
    pat = re.compile(
        r'(def ' + endpoint + r'\(.*?\n(?:.*?\n)*?)'
        r'    if au is None or au\.profile_user_id is None:\n'
        r'        raise HTTPException\(404, "Aucun profil métier lié à ce compte\."\)',
        re.M)
    s2, n = pat.subn(lambda m: m.group(1) +
                     "    if au is None or au.profile_user_id is None:\n"
                     f"        return {empty}", s)
    if n:
        s = s2
        print(f"4. {endpoint} : retour vide au lieu d'une erreur")
p.write_text(s, encoding="utf-8")

print("\nBackend corrige.")
