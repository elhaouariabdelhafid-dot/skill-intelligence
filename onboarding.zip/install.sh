#!/usr/bin/env bash
set -euo pipefail
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Backend"
cd "$HOME/skill-intelligence"
cp api/main.py api/main.py.bak
cp api/access_api.py api/access_api.py.bak
cp "$P/onboarding.py" api/onboarding.py
python3 "$P/patch_backend.py"
python -c "from api.main import app; print('  imports OK')"

echo ""
echo "==> Reparation des comptes existants sans profil"
python - << 'PYEOF'
import sys; sys.path.insert(0, ".")
from auth.auth_models import AuthUser, get_auth_session
from db.models import User, get_session
a = get_auth_session(); core = get_session()
n = 0
for acc in a.query(AuthUser).filter(AuthUser.profile_user_id.is_(None)).all():
    if acc.role != "collaborateur":
        continue
    u = core.query(User).filter(User.name == acc.full_name).first()
    if not u:
        u = User(name=acc.full_name, role=acc.role)
        core.add(u); core.commit()
    acc.profile_user_id = u.id
    a.commit(); n += 1
    print(f"  {acc.email} -> profil #{u.id}")
a.close(); core.close()
print(f"  {n} compte(s) repare(s)")
PYEOF

echo ""
echo "==> Frontend"
D="$HOME/skill-intelligence/frontend-web"
cd "$D"
cp src/App.jsx src/App.jsx.bak6
cp src/styles.css src/styles.css.bak6
cp "$P/onboard_views.jsx" "$P/onboard.css" .
python3 "$P/patch_front.py"
rm -f onboard_views.jsx onboard.css

echo ""
echo "============================================================"
echo " Relancez l'API   :  uvicorn api.main:app --port 8010"
echo " Relancez le front:  cd $D && npm run dev"
echo "============================================================"
