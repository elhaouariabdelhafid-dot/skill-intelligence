#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Copie des modules"
cp "$P/requests_models.py" api/requests_models.py
cp "$P/requests_api.py"    api/requests_api.py

echo "==> Branchement du routeur"
python - << 'PYEOF'
from pathlib import Path
p = Path("api/main.py"); s = p.read_text()
if "requests_api" not in s:
    s = s.replace(
        "from api.sessions_api import router as sessions_router\napp.include_router(sessions_router)",
        "from api.sessions_api import router as sessions_router\n"
        "app.include_router(sessions_router)\n\n"
        "from api.requests_api import router as requests_router\n"
        "app.include_router(requests_router)")
    p.write_text(s); print("  routeur demandes ajouté")
else:
    print("  routeur déjà présent")
PYEOF

echo "==> Création de la table"
python -c "from api.requests_models import get_requests_db; get_requests_db().close(); print('  table eval_requests prête')"

echo ""
echo "============================================================"
echo " Circuit de demandes installé."
echo ""
echo " Relancer l'API :"
echo "   uvicorn api.main:app --reload --reload-exclude 'volumes/*' --port 8010"
echo ""
echo " Tester le circuit :  bash scripts/test_requests.sh"
echo "============================================================"
