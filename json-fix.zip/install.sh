#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/skill-intelligence" || { echo "Projet introuvable"; exit 1; }
P="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p archive/before_fix
cp llm/client.py archive/before_fix/client_before_json.py
echo "Sauvegarde : archive/before_fix/client_before_json.py"
python3 "$P/fix_json.py"
cp "$P/test_json.py" scripts/test_json.py
echo ""
echo "Test :  python scripts/test_json.py"
