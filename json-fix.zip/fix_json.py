"""Fiabilise la sortie structuree des petits modeles.

LE PROBLEME OBSERVE : le prompt systeme se termine par "SCHEMA: {...}". Un
modele de 8 milliards de parametres voit un objet JSON juste apres la consigne
"reponds en JSON" et le recopie tel quel. La validation echoue alors sur
"Field required" pour tous les champs, cinq fois de suite.

TROIS MESURES :
  1. un EXEMPLE de sortie, genere depuis le schema, montre ce qu'on attend
  2. la description des champs est presentee en clair, pas en JSON Schema brut
  3. le cas pathologique est detecte et la relance porte une consigne ciblee
"""
from pathlib import Path
import sys

p = Path("llm/client.py")
if not p.exists():
    print("ERREUR : lancer depuis ~/skill-intelligence"); sys.exit(1)

s = p.read_text(encoding="utf-8")
if "_schema_example" in s:
    print("Deja applique."); sys.exit(0)

helper = '''

def _schema_example(schema) -> str:
    """Construit un exemple de sortie a partir du schema Pydantic.

    Montrer une reponse plutot que le schema : un petit modele imite ce qu'il
    voit. Lui presenter un objet JSON de description l'incite a le recopier.
    """
    props = schema.model_json_schema().get("properties", {})
    example = {}
    for name, spec in props.items():
        t = spec.get("type")
        if t == "integer":
            example[name] = 2
        elif t == "number":
            example[name] = 2.0
        elif t == "boolean":
            example[name] = False
        elif t == "array":
            example[name] = ["..."]
        else:
            example[name] = "..."
    return json.dumps(example, ensure_ascii=False)


def _schema_fields(schema) -> str:
    """Decrit les champs en clair : nom, type, role."""
    props = schema.model_json_schema().get("properties", {})
    required = set(schema.model_json_schema().get("required", []))
    lines = []
    for name, spec in props.items():
        t = spec.get("type", "string")
        if t == "array":
            t = "array of " + spec.get("items", {}).get("type", "string")
        desc = spec.get("description", "")
        mark = "" if name in required else " (optional)"
        lines.append(f"- {name} ({t}){mark}: {desc}")
    return "\\n".join(lines)


def _looks_like_schema(raw: str) -> bool:
    """Detecte le cas ou le modele a renvoye le schema au lieu d'une reponse."""
    lowered = raw.lower()
    return ('"properties"' in lowered or '"$schema"' in lowered
            or '"type": "object"' in lowered)
'''

# 1) Inserer les helpers avant complete_json
anchor = "def complete_json(prompt: str, schema: Type[T]"
if anchor not in s:
    print("ERREUR : complete_json introuvable"); sys.exit(1)
s = s.replace(anchor, helper.strip() + "\n\n\n" + anchor, 1)
print("1. helpers ajoutes")

# 2) Remplacer la construction du systeme
old_sys = '''    schema_json = json.dumps(schema.model_json_schema(), ensure_ascii=False)
    full_system = (
        (system + "\\n\\n" if system else "")
        + "You MUST reply with a single valid JSON object matching this schema.\\n"
        + "No markdown fences, no preamble, no explanation. JSON only.\\n"
        + f"SCHEMA: {schema_json}"
    )'''
new_sys = '''    full_system = (
        (system + "\\n\\n" if system else "")
        + "Reply with ONE JSON object and nothing else. "
        + "No markdown fences, no preamble, no explanation.\\n\\n"
        + "FIELDS TO FILL:\\n" + _schema_fields(schema) + "\\n\\n"
        + "SHAPE OF YOUR REPLY (replace the placeholder values with your own "
        + "analysis, keep the same keys):\\n" + _schema_example(schema) + "\\n\\n"
        + "Never reply with a schema, a type description or the word "
        + "'properties'. Reply with the filled object only."
    )'''
if old_sys in s:
    s = s.replace(old_sys, new_sys)
    print("2. systeme reecrit : exemple au lieu du schema brut")
else:
    print("2. ATTENTION : bloc systeme non trouve, verifiez le fichier")

# 3) Detecter le cas pathologique et relancer avec une consigne ciblee
old_try = '''            raw = complete(
                prompt if attempt == 0
                else f"{prompt}\\n\\nPrevious attempt failed: {last_error}\\nReply with valid JSON only.",
                system=full_system,
                temperature=temperature + 0.1 * attempt,  # varier si blocage
                max_tokens=max_tokens,
            )
            return schema.model_validate_json(_extract_json(raw))'''
new_try = '''            raw = complete(
                prompt if attempt == 0
                else f"{prompt}\\n\\nPrevious attempt failed: {last_error}\\n{retry_hint}",
                system=full_system,
                temperature=temperature + 0.1 * attempt,  # varier si blocage
                max_tokens=max_tokens,
            )
            if _looks_like_schema(raw):
                # Le modele a recopie le schema : on le lui dit explicitement
                retry_hint = ("You replied with the schema instead of the answer. "
                              "Reply with the FILLED object: "
                              + _schema_example(schema))
                raise ValueError("schema echoed instead of answer")
            return schema.model_validate_json(_extract_json(raw))'''
if old_try in s:
    s = s.replace(old_try, new_try)
    # Initialiser retry_hint
    s = s.replace('    last_error = ""\n    for attempt in range(MAX_RETRIES):',
                  '    last_error = ""\n'
                  '    retry_hint = "Reply with valid JSON only."\n'
                  '    for attempt in range(MAX_RETRIES):')
    print("3. detection du schema recopie + relance ciblee")
else:
    print("3. ATTENTION : bloc de tentative non trouve")

p.write_text(s, encoding="utf-8")
import ast; ast.parse(s)
print("\nllm/client.py corrige et valide.")
